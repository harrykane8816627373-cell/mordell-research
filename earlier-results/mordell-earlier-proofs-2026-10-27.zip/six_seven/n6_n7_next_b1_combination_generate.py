"""Look for short saturation-free identities forcing c=d=0 on e3=1."""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'cas_runtime'))
import sympy as s
c,d,e=s.symbols('c d e')
j=json.loads((HERE/'n6_n7_next_b1_equations.json').read_text())
E=[s.Poly(s.sympify(q),c,d,e) for q in j['E']]
D=s.sympify(j['delta'])
weights=[2,1,0,2]
targets={'c':(c*D,1),'d':(d*D,2),'q':((25*e**2-17*e+1)*D,0)}
start=time.monotonic();output={}
for name,(target,weight) in targets.items():
    target=s.Poly(target,c,d,e)
    for bound in range(1,7):
        mon=[(i,k,l) for total in range(bound+1) for i in range(total+1) for k in range(total-i+1) for l in [total-i-k]]
        maps=[];columns=[]
        for idx,q in enumerate(E):
            for a,b,f in mon:
                if (a+2*b+weights[idx])%3!=weight:continue
                columns.append({(i+a,k+b,l+f):v for (i,k,l),v in q.terms()})
                maps.append((idx,a,b,f))
        rows=sorted(set(target.monoms()).union(*(col.keys() for col in columns)))
        A=s.Matrix([[col.get(row,0) for col in columns] for row in rows]);v=s.Matrix([target.coeff_monomial(row) for row in rows])
        print(name,'bound',bound,'shape',A.shape,'elapsed',time.monotonic()-start,flush=True)
        try:sol,params=A.gauss_jordan_solve(v)
        except ValueError:continue
        sol=sol.subs({q:0 for q in params})
        coeff=[s.expand(sum(sol[k]*c**a*d**b*e**f for k,(idx,a,b,f) in enumerate(maps) if idx==j)) for j in range(4)]
        if s.expand(sum(a*q.as_expr() for a,q in zip(coeff,E))-target.as_expr())!=0:raise ArithmeticError('Identity failed')
        output[name]={'target':str(target.as_expr()),'coefficient_degree_bound':bound,'A':[str(q) for q in coeff]}
        print('found',name,[str(s.factor(q)) for q in coeff],flush=True)
        (HERE/'n6_n7_next_b1_combinations.json').write_text(json.dumps(output,indent=2)+'\n')
        break
    else:print('Not found',name,flush=True)
print('Done',list(output),'elapsed',time.monotonic()-start,flush=True)
