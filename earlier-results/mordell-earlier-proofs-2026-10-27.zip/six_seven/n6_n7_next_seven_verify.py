"""Offline exact n7 e2=e3=0 coefficient-chart coverage certificate.

Reconstructs original resultant coefficients at a degree-determining
Cartesian grid, then formally verifies discriminant combinations. Uses
standard-library rational arithmetic from the n6 checker as a library;
it does not call that checker's main routine or read its certificates.
"""
from pathlib import Path
from fractions import Fraction as F
import itertools,json
import n6_n7_next_special_verify as arithmetic

ROOT=Path(__file__).resolve().parent
require=arithmetic.require
pdiv=arithmetic.pdiv;pmul=arithmetic.pmul;inverse=arithmetic.inverse

def coefficients(a,b,c,d):
    pint=[d,c,b,a,0,0,0,1];dpint=[c,2*b,3*a,0,0,0,7]
    delta=arithmetic.resultant(pint,dpint)
    require(delta!=0,'Singular n7 reconstruction sample')
    p=list(map(F,pint));dp=list(map(F,dpint));ddp=list(map(F,[2*b,6*a,0,0,0,42]))
    g=pdiv(pmul(ddp,inverse(dp,p)),p)[1]
    power=[F(1)];S={};m={};rootsums=[7,0,0,0,-4*a,-5*b,-6*c]
    def trace(q):return sum(v*rootsums[j] for j,v in enumerate(q))
    for k in range(1,7):
        power=pdiv(pmul(power,g),p)[1]
        S[k]=trace(power);m[k]=trace(pdiv([F(0)]+power,p)[1])
    require(S[1]==0 and m[1]==42,'Universal n7 force trace identity failed')
    q2=-S[2]/2;q3=-S[3]/3;q4=(S[2]**2/2-S[4])/4;q5=q2*q3-S[5]/5
    E=[m[2],m[3]+22*q2,m[4]+q2*m[2]+30*q3,m[5]+q2*m[3]+q3*m[2]+36*q4,m[6]+q2*m[4]+q3*m[3]+q4*m[2]+40*q5]
    return delta,[delta*v for v in E]

def verify_mode(mode,variables,expected_p,sample_ranges,root_parameters):
    arithmetic.VARS=variables;arithmetic.ZERO=(0,)*len(variables)
    data=json.loads((ROOT/('n6_n7_next_'+mode+'_equations.json')).read_text())
    require(data['n']==7 and data['p']==expected_p,'Unexpected n7 polynomial convention')
    delta=arithmetic.poly(data['delta']);E=list(map(arithmetic.poly,data['E']))
    require(len(E)==5,'Five original n7 necessary equations required')
    limits=[13]*(len(variables)-1)+[7]
    for q in [delta]+E:require(all(all(k<=bound for k,bound in zip(m,limits)) for m in q),'n7 parameter degree bound failed')
    samples=0
    for point in itertools.product(*sample_ranges):
        actual_delta,actual_E=coefficients(*root_parameters(point))
        require(arithmetic.evaluate(delta,*point)==actual_delta,'n7 resultant formula mismatch')
        require(all(arithmetic.evaluate(q,*point)==v for q,v in zip(E,actual_E)),'n7 necessary resultant coefficient mismatch')
        samples+=1
    combination_file=ROOT/('n6_n7_next_'+mode+'_combination.json')
    if combination_file.exists():
        certificate=json.loads(combination_file.read_text());A=certificate['A']
        require(len(A)==5,'Five n7 combination multipliers required')
        identity={}
        for a,q in zip(A,E):identity=arithmetic.add(identity,arithmetic.mul(arithmetic.poly(a),q))
        require(arithmetic.add(identity,{m:-v for m,v in delta.items()})=={},'Formal n7 discriminant identity failed')
        identity_verified=True
    else:
        require(mode=='seven_b0','Missing discriminant combination certificate')
        require(E[0]==arithmetic.poly('29647548*c*d**5'),'Final sparse-chart product identity mismatch')
        identity_verified=False
    print('Verified',mode,'exact samples',samples,'discriminant combination',identity_verified,flush=True)
    return {'mode':mode,'Cartesian_grid':[len(r) for r in sample_ranges],'exact_samples':samples,'coefficient_formulas_reconstructed':True,'formal_discriminant_identity':identity_verified}

def run():
    rows=[]
    rows.append(verify_mode('seven_a1',('b','c','d'),'X**7 + X**3 + X**2*b + X*c + d',(range(1,15),range(1,15),range(101,109)),lambda point:(1,)+point))
    rows.append(verify_mode('seven_b1',('c','d'),'X**7 - X**2 + X*c + d',(range(1,15),range(101,109)),lambda point:(0,-1)+point))
    rows.append(verify_mode('seven_b0',('c','d'),'X**7 + X*c + d',(range(1,15),range(101,109)),lambda point:(0,0)+point))
    require(7**14>6**15,'Center-hexagon versus heptagon comparison failed')
    output={'independent_of_author_classification':True,'uses_CAS':False,'uses_floating_point':False,'formula_reconstructions':rows,'exact_samples_total':sum(row['exact_samples'] for row in rows),'scope':'All collision-free physical stationary n7 shapes with e2=e3=0 are center hexagon or regular heptagon, up to complex scaling and permutation.','value_comparison':{'center_hexagon':'7^21/6^15','regular_heptagon':'7^7','strict_integer_comparison':[7**14,6**15]}}
    (ROOT/'n6_n7_next_seven_verification.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print('Independent n7 sparse-chart verification passed:',json.dumps(output),flush=True)

if __name__=='__main__':run()
