"""Package the bounded first-e4 algorithm experiment with a hash manifest."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
NAMES=[
 'n6_n7_next_eight_first4_linear_notes.md',
 'n6_n7_next_eight_first4_linear.py',
 'n6_n7_next_eight_first4_linear_checkpoint.json',
 'n6_n7_next_eight_first4_partial.json',
 'n6_n7_next_eight_first4_equations.json',
 'n6_n7_next_eight_first4_combination.py',
 'n6_n7_next_eight_first4_b_checkpoint.json',
 'n6_n7_next_eight_first4_d_checkpoint.json',
 'n6_n7_next_bounded_run.py',
 'n6_n7_next_special_verify.py',
 'n6_n7_next_eight_first4_spotcheck.py',
 'n6_n7_next_eight_first4_spotcheck.json',
 'n6_n7_next_eight_first4_degree8_verify.py',
 'n6_n7_next_eight_first4_degree8_verification.json',
 'n6_n7_next_eight_first4_pack.py',
]
manifest={'scope':'Exact first-e4 resultant generation and finite degree-8 nonmembership; no physical chart coverage theorem.','files':[]}
for name in NAMES:
    raw=(ROOT/name).read_bytes()
    manifest['files'].append({'path':name,'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
manifest_path=ROOT/'n6_n7_next_eight_first4_manifest.json'
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
archive=ROOT/'n6_n7_next_eight_first4_bundle.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name in NAMES:z.write(ROOT/name,name)
    z.write(manifest_path,manifest_path.name)
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None:raise ArithmeticError('Archive CRC failure')
    for row in manifest['files']:
        raw=z.read(row['path'])
        if len(raw)!=row['size'] or hashlib.sha256(raw).hexdigest()!=row['sha256']:raise ArithmeticError('Archive manifest mismatch')
raw=archive.read_bytes()
print(json.dumps({'archive':str(archive),'bytes':len(raw),'files':len(NAMES)+1,'sha256':hashlib.sha256(raw).hexdigest(),'CRC_and_manifest_verified':True},indent=2))
