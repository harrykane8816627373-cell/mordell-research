# 新增七点稀疏图区独立证书

本包独立闭合整个七点 `e2=e3=0` 必要覆盖，并给出两剩余构型的精确目标比较。完整证明是 `n6_n7_next_seven_independent.tex`；审计说明为 `n6_n7_next_seven_notes.md`。

离线运行：

```text
python -B -S -O verify_manifest.py
python -B -S -O n6_n7_next_seven_verify.py
```

验证只需Python标准库，测试环境为Python3.12。`n6_n7_next_special_verify.py` 在此仅作为基础有理多项式/Bareiss算术库导入，不运行六点检查，也不读取六点数据。

验证独立重建全部原始七点必要方程：1792个精确笛卡尔网格点（1568+112+112），每一点的integer resultant均非零；严格参数次数界使这些点足够证明整个 coefficient polynomial identity。随后两个判别式组合证书被作为正式稀疏有理多项式展开检查。

结论：首非零e4和首非零e5图全部排空无碰撞候选；剩余图区的必要方程强制 `c*d=0`，仅有 `X^7+1`（正七边形）和 `X^7+X`（中心加正六边形）。在moment7下后者值为 `7^21/6^15`，严格大于前者 `7^7`。

全过程没有CAS/第三方包、浮点决定、作者组件输入或网络访问。验证器会重写 `n6_n7_next_seven_verification.json`。在重放前检查SHA；不同操作系统的换行转换可能改变重写结果的字节哈希。

仅此稀疏区域的覆盖是本包独立重建的，其他七点系数区域仍使用既有覆盖输入。
