"""Bounded search for exact n7 sparse-chart discriminant combinations."""
from pathlib import Path
import sys,json,time,itertools
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'cas_runtime'))
import sympy as s
b,c,d=s.symbols('b c d');mode=sys.argv[1]
if mode=='seven_a1':variables=(b,c,d);modulus=4;vweights=(1,2,3)
elif mode=='seven_b1':variables=(c,d);modulus=5;vweights=(1,2)
else:raise ValueError(mode)
j=json.loads((HERE/('n6_n7_next_'+mode+'_equations.json')).read_text())
E=[s.Poly(s.sympify(q),*variables) for q in j['E']];D=s.Poly(s.sympify(j['delta']),*variables)
weights=[(42-r)%modulus for r in range(1,6)]
start=time.monotonic()
for bound in range(1,10):
    mon=[m for m in itertools.product(range(bound+1),repeat=len(variables)) if sum(m)<=bound]
    columns=[];maps=[]
    for idx,q in enumerate(E):
        for m in mon:
            if (sum(k*w for k,w in zip(m,vweights))+weights[idx])%modulus!=42%modulus:continue
            columns.append({tuple(i+k for i,k in zip(n,m)):v for n,v in q.terms()});maps.append((idx,m))
    rows=sorted(set(D.monoms()).union(*(col.keys() for col in columns)))
    A=s.Matrix([[col.get(row,0) for col in columns] for row in rows]);v=s.Matrix([D.coeff_monomial(row) for row in rows])
    print(mode,'bound',bound,'shape',A.shape,'elapsed',time.monotonic()-start,flush=True)
    try:sol,params=A.gauss_jordan_solve(v)
    except ValueError:continue
    sol=sol.subs({q:0 for q in params})
    coeff=[s.expand(sum(sol[k]*s.prod(x**i for x,i in zip(variables,m)) for k,(idx,m) in enumerate(maps) if idx==j)) for j in range(5)]
    if s.expand(sum(a*q.as_expr() for a,q in zip(coeff,E))-D.as_expr())!=0:raise ArithmeticError('Identity failed')
    out={'identity':'delta=sum_i Ai Ei','coefficient_degree_bound':bound,'variables':[str(x) for x in variables],'A':[str(q) for q in coeff]}
    (HERE/('n6_n7_next_'+mode+'_combination.json')).write_text(json.dumps(out,indent=2)+'\n')
    print('FOUND',mode,'bound',bound,'elapsed',time.monotonic()-start,flush=True)
    for i,a in enumerate(coeff,1):print('A'+str(i),s.factor(a),flush=True)
    break
else:print('No delta identity through multiplier degree 9',flush=True)
