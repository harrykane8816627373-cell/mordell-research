"""Replay a finite QQ nonmembership result by a full-rank modular minor.

For the saved first-e4 E polynomials, neither b*delta nor d*delta is a
combination with multiplier total degree at most eight. This is not an
unbounded ideal nonmembership claim, nor a physical configuration result.
Uses only standard-library sparse arithmetic.
"""
from pathlib import Path
import itertools,json,math
import n6_n7_next_special_verify as arithmetic
ROOT=Path(__file__).resolve().parent;require=arithmetic.require
PRIME=1000003;VWEIGHTS=(1,2,3,0)

def run():
    require(all(PRIME%q for q in range(2,math.isqrt(PRIME)+1)),'Modulus is not prime')
    arithmetic.VARS=('b','c','d','u');arithmetic.ZERO=(0,0,0,0)
    data=json.loads((ROOT/'n6_n7_next_eight_first4_equations.json').read_text())
    E=list(map(arithmetic.poly,data['E']));delta=arithmetic.poly(data['delta'])
    require(len(E)==6,'Expected six polynomials')
    weights=[(-r)%4 for r in range(1,7)]
    for q,w in zip(E,weights):
        require(all(sum(a*v for a,v in zip(m,VWEIGHTS))%4==w for m in q),'Fourth-root homogeneity failed')
    require(all(sum(a*v for a,v in zip(m,VWEIGHTS))%4==0 for m in delta),'Discriminant fourth-root homogeneity failed')
    require(all(v.denominator==1 for q in E+[delta] for v in q.values()),'Integer coefficients needed')
    mon=[m for m in itertools.product(range(9),repeat=4) if sum(m)<=8]
    results=[]
    for target,shift,tw in [('b',(1,0,0,0),1),('d',(0,0,1,0),3)]:
        pivots={};columns=0
        def reduce(vec):
            while vec:
                lead=max(vec)
                if lead not in pivots:return vec
                scale=vec[lead]
                for m,v in pivots[lead].items():
                    value=(vec.get(m,0)-scale*v)%PRIME
                    if value:vec[m]=value
                    else:vec.pop(m,None)
            return vec
        for idx,q in enumerate(E):
            for m in mon:
                if (sum(a*v for a,v in zip(m,VWEIGHTS))+weights[idx])%4!=tw:continue
                columns+=1
                col={tuple(a+k for a,k in zip(n,m)):int(v)%PRIME for n,v in q.items() if int(v)%PRIME}
                col=reduce(col)
                require(bool(col),'Columns do not have full modular rank; QQ inference unavailable')
                lead=max(col);inv=pow(col[lead],-1,PRIME)
                pivots[lead]={n:v*inv%PRIME for n,v in col.items()}
        target_poly={tuple(a+k for a,k in zip(n,shift)):int(v)%PRIME for n,v in delta.items() if int(v)%PRIME}
        remainder=reduce(target_poly)
        require(bool(remainder),'Target belongs to modular column span; claimed nonmembership unavailable')
        row={'target':target+'*delta','multiplier_total_degree_at_most':8,'columns':columns,'modular_column_rank':len(pivots),'modular_augmented_rank':len(pivots)+1,'target_remainder_terms':len(remainder),'QQ_nonmembership_in_this_finite_span':True}
        results.append(row)
        print('Verified degree-8 QQ finite-span nonmembership:',json.dumps(row),flush=True)
    output={'uses_CAS':False,'prime':PRIME,'fourth_root_homogeneity_checked':True,'proof':'The coefficient matrix has full column rank modulo a prime and its augmentation has rank one greater. The same ranks over QQ force inconsistency. Fourth-root weight projection reduces any multiplier of total degree <=8 to the tested columns.','results':results,'scope':'Only finite multiplier-degree nonmembership for the displayed six polynomials; no statement about higher-degree ideal membership or physical solutions.'}
    (ROOT/'n6_n7_next_eight_first4_degree8_verification.json').write_text(json.dumps(output,indent=2)+'\n')

if __name__=='__main__':run()
