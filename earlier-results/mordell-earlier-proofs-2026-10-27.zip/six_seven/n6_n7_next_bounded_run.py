"""Run one symbolic worker with a hard 120-second wall-clock limit."""
from pathlib import Path
import subprocess, sys

root=Path(__file__).resolve().parent
worker=root/(sys.argv[2] if len(sys.argv)>2 else 'n6_n7_next_special_generate.py')
if worker.resolve().parent!=root.resolve(): raise ValueError('Worker must be in work directory')
mode=sys.argv[1]
limit=int(sys.argv[3]) if len(sys.argv)>3 else 120
if not 0<limit<=120:raise ValueError('Worker time limit must be between 1 and 120 seconds')
try:
    done=subprocess.run([sys.executable,str(worker),mode],capture_output=True,text=True,timeout=limit)
    print(done.stdout,end='')
    if done.stderr: print(done.stderr,end='',file=sys.stderr)
    if done.returncode: raise SystemExit(done.returncode)
except subprocess.TimeoutExpired as exc:
    if exc.stdout:
        if isinstance(exc.stdout,bytes):sys.stdout.buffer.write(exc.stdout)
        else:print(exc.stdout,end='')
    if exc.stderr:
        if isinstance(exc.stderr,bytes):sys.stderr.buffer.write(exc.stderr)
        else:print(exc.stderr,end='',file=sys.stderr)
    print('Worker exceeded '+str(limit)+' seconds and was terminated.',flush=True)
    raise SystemExit(124)
