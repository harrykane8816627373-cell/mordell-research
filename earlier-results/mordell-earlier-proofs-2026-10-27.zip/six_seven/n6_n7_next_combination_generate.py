"""Find an explicit rational identity delta = sum A_i E_i on c=1."""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'cas_runtime'))
import sympy as s
d,e=s.symbols('d e')
j=json.loads((HERE/'n6_n7_next_c1_equations.json').read_text())
E=[s.Poly(s.sympify(q),d,e) for q in j['E']]
D=s.Poly(s.sympify(j['delta']),d,e)
started=time.monotonic()
for bound in range(1,8):
    mon=[(i,k) for total in range(bound+1) for i in range(total+1) for k in [total-i]]
    columns=[]
    for q in E:
        for a,b in mon:
            columns.append({(i+a,k+b):v for (i,k),v in q.terms()})
    rows=sorted(set(D.monoms()).union(*(col.keys() for col in columns)))
    M=s.polys.matrices.DomainMatrix.from_Matrix(s.Matrix([[col.get(row,0) for col in columns] for row in rows]+[]))
    A=M.to_Matrix();v=s.Matrix([D.coeff_monomial(row) for row in rows])
    print('bound',bound,'shape',A.shape,'elapsed',time.monotonic()-started,flush=True)
    try:
        sol,params=A.gauss_jordan_solve(v)
    except ValueError:
        continue
    sol=sol.subs({q:0 for q in params})
    coeff=[s.expand(sum(sol[i*len(mon)+k]*d**a*e**b for k,(a,b) in enumerate(mon))) for i in range(4)]
    residual=s.expand(sum(a*q.as_expr() for a,q in zip(coeff,E))-D.as_expr())
    if residual!=0:raise ArithmeticError('Combination verification failed')
    out={'identity':'delta = sum_i A_i E_i','coefficient_degree_bound':bound,'A':[str(q) for q in coeff]}
    (HERE/'n6_n7_next_c1_combination.json').write_text(json.dumps(out,indent=2)+'\n')
    for i,a in enumerate(coeff,1):print('A'+str(i),s.factor(a),flush=True)
    print('combination exact; elapsed',time.monotonic()-started,flush=True)
    break
else:raise ArithmeticError('No combination within chosen degree limit')
