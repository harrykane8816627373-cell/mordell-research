"""Independent standard-library proof of the entire n6 e2=0 chart coverage.

The displayed resultant coefficients are reconstructed on a Cartesian
grid large enough for a polynomial identity, using exact quotient-ring
traces and an integer Sylvester determinant. No archived classification
component, floating-point operation, or CAS is used. Run python -B -S -O.
"""
import ast
from fractions import Fraction as F
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
VARS=('d','e');ZERO=(0,0)

def require(flag,message):
    if not flag:raise ArithmeticError(message)

def add(a,b):
    out=dict(a)
    for m,v in b.items():out[m]=out.get(m,F(0))+v
    return {m:v for m,v in out.items() if v}

def mul(a,b):
    out={}
    for m,v in a.items():
        for n,w in b.items():
            key=tuple(i+j for i,j in zip(m,n))
            out[key]=out.get(key,F(0))+v*w
    return {m:v for m,v in out.items() if v}

def parse(node):
    if isinstance(node,ast.Constant) and type(node.value) is int:return {ZERO:F(node.value)} if node.value else {}
    if isinstance(node,ast.Name) and node.id in VARS:return {tuple(int(name==node.id) for name in VARS):F(1)}
    if isinstance(node,ast.UnaryOp) and isinstance(node.op,ast.USub):return {m:-v for m,v in parse(node.operand).items()}
    if isinstance(node,ast.BinOp):
        a=parse(node.left)
        if isinstance(node.op,ast.Pow):
            require(isinstance(node.right,ast.Constant) and type(node.right.value) is int and 0<=node.right.value<=30,'Bad power')
            r={ZERO:F(1)}
            for _ in range(node.right.value):r=mul(r,a)
            return r
        b=parse(node.right)
        if isinstance(node.op,ast.Add):return add(a,b)
        if isinstance(node.op,ast.Sub):return add(a,{m:-v for m,v in b.items()})
        if isinstance(node.op,ast.Mult):return mul(a,b)
        if isinstance(node.op,ast.Div):
            require(set(b)=={ZERO},'Nonconstant division')
            return {m:v/b[ZERO] for m,v in a.items()}
    raise ValueError(ast.dump(node))

def poly(text):return parse(ast.parse(text,mode='eval').body)
def evaluate(p,*values):
    out=F(0)
    for m,v in p.items():
        for x,k in zip(values,m):v*=x**k
        out+=v
    return out

DELTA1='-3125*d**6+22500*d**4*e-43200*d**2*e**2-256*d**2+46656*e**5+13824*e**3+1024*e'
E1=[
    '-4*d*(9375*d**4-72000*d**2*e-291600*e**4+120960*e**2-256)',
    '64*(5625*d**4-21600*d**2*e+58320*e**4+10368*e**2+256)',
    '-720*d*(25*d**2-96*e)*(135*e**2+4)',
    '96*(84375*d**4*e-378000*d**2*e**2+3200*d**2+259200*e**3-10752*e)',
]
A=['d/96','-(175*d**2-768*e)/23040','-d*e/96','-(27*e**2+4)/8640']
DELTA0='-3125*d**6+46656*e**5'
E0=['1166400*d*e**4','0','-2430000*d**3*e**2','8100000*d**4*e']

def trim(a):
    a=list(a)
    while a and not a[-1]:a.pop()
    return a

def padd(a,b):
    out=[F(0)]*max(len(a),len(b))
    for j,v in enumerate(a):out[j]+=v
    for j,v in enumerate(b):out[j]+=v
    return trim(out)

def pmul(a,b):
    out=[F(0)]*max(0,len(a)+len(b)-1)
    for j,v in enumerate(a):
        for k,w in enumerate(b):out[j+k]+=v*w
    return trim(out)

def pdiv(a,b):
    a=trim(a);b=trim(b)
    require(bool(b),'Polynomial division by zero')
    out=[F(0)]*max(0,len(a)-len(b)+1)
    while len(a)>=len(b):
        k=len(a)-len(b);v=a[-1]/b[-1];out[k]+=v
        for j,w in enumerate(b):a[j+k]-=v*w
        a=trim(a)
    return trim(out),a

def inverse(a,p):
    oldr,r=p,a;oldv,v=[],[F(1)]
    while r:
        q,newr=pdiv(oldr,r)
        oldr,r=r,newr
        oldv,v=v,padd(oldv,[-w for w in pmul(q,v)])
    require(len(oldr)==1 and bool(oldr[0]),'Singular quotient sample')
    return pdiv([w/oldr[0] for w in oldv],p)[1]

def det_bareiss(matrix):
    a=[list(row) for row in matrix];n=len(a);previous=1;sign=1
    for k in range(n-1):
        if not a[k][k]:
            candidates=[j for j in range(k+1,n) if a[j][k]]
            if not candidates:return 0
            j=candidates[0];a[k],a[j]=a[j],a[k];sign=-sign
        pivot=a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                numerator=pivot*a[i][j]-a[i][k]*a[k][j]
                require(numerator%previous==0,'Bareiss division not exact')
                a[i][j]=numerator//previous
            a[i][k]=0
        previous=pivot
    return sign*a[-1][-1]

def resultant(p,q):
    pd=list(reversed(p));qd=list(reversed(q));n=len(pd)-1;m=len(qd)-1
    rows=[]
    for j in range(m):rows.append([0]*j+pd+[0]*(m-1-j))
    for j in range(n):rows.append([0]*j+qd+[0]*(n-1-j))
    return det_bareiss(rows)

def exact_coefficients(c,d,e,b=0):
    pint=[e,d,c,b,0,0,1];dpint=[d,2*c,3*b,0,0,6]
    delta=resultant(pint,dpint)
    require(delta!=0,'Grid has a singular sample')
    p=list(map(F,pint));dp=list(map(F,dpint));ddp=list(map(F,[2*c,6*b,0,0,30]))
    g=pdiv(pmul(ddp,inverse(dp,p)),p)[1]
    power=[F(1)];S={};m={};rootsums=[6,0,0,-3*b,-4*c,-5*d]
    def trace(q):return sum(v*rootsums[j] for j,v in enumerate(q))
    for k in range(1,6):
        power=pdiv(pmul(power,g),p)[1]
        S[k]=trace(power);m[k]=trace(pdiv([F(0)]+power,p)[1])
    require(S[1]==0 and m[1]==30,'Universal force trace identity failed')
    q2=-S[2]/2;q3=-S[3]/3;q4=(S[2]**2/2-S[4])/4
    E=[delta*m[2],delta*(m[3]+18*q2),delta*(m[4]+q2*m[2]+24*q3),delta*(m[5]+q2*m[3]+q3*m[2]+28*q4)]
    return delta,E

def run():
    global VARS,ZERO
    rows=[]
    for c,delta_text,E_text in ((1,DELTA1,E1),(0,DELTA0,E0)):
        delta=poly(delta_text);equations=list(map(poly,E_text))
        # Replace (Y+TX)p'-p'' by Yp'-p''+T(Xp'-6p), without
        # changing the resultant, since p is monic. The second polynomial
        # now has degree at most five, hence an 11x11 Sylvester matrix.
        # Degree in d is at most 11. Degree in e is at most 6: five
        # copies of p plus at most one first-variation entry containing e.
        for q in [delta]+equations:
            require(all(i<=11 and j<=6 for i,j in q),'Displayed formula exceeds determinant degree bounds')
        samples=0
        for d in range(1,13):
            for e in range(101,108):
                actual_delta,actual_E=exact_coefficients(c,d,e)
                require(evaluate(delta,d,e)==actual_delta,'Resultant coefficient formula mismatch')
                require(all(evaluate(q,d,e)==v for q,v in zip(equations,actual_E)),'Necessary equation formula mismatch')
                samples+=1
        rows.append({'c':c,'Cartesian_grid':[12,7],'d_samples':[1,12],'e_samples':[101,107],'exact_samples':samples,'all_resultant_coefficient_formulas_verified':True})
    combination={}
    for a,q in zip(map(poly,A),map(poly,E1)):combination=add(combination,mul(a,q))
    require(add(combination,{m:-v for m,v in poly(DELTA1).items()})=={},'Formal discriminant combination identity failed')
    # Independently close the e2=0, e3=1 chart. Its displayed data were
    # generated from the resultants, not from any author component list.
    VARS=('c','d','e');ZERO=(0,0,0)
    data=json.loads((ROOT/'n6_n7_next_b1_equations.json').read_text())
    require(data['p']=='X**6 - X**3 + X**2*c + X*d + e','Unexpected e3=1 root polynomial')
    delta=poly(data['delta']);equations=list(map(poly,data['E']))
    require(len(equations)==4,'Four original necessary equations required')
    for q in [delta]+equations:
        require(all(i<=11 and j<=11 and k<=6 for i,j,k in q),'Three-variable formula exceeds degree bounds')
    samples=0
    for c in range(1,13):
        for d in range(1,13):
            for e in range(101,108):
                actual_delta,actual_E=exact_coefficients(c,d,e,b=-1)
                require(evaluate(delta,c,d,e)==actual_delta,'Three-variable resultant formula mismatch')
                require(all(evaluate(q,c,d,e)==v for q,v in zip(equations,actual_E)),'Three-variable necessary equation mismatch')
                samples+=1
    rows.append({'b':-1,'Cartesian_grid':[12,12,7],'c_samples':[1,12],'d_samples':[1,12],'e_samples':[101,107],'exact_samples':samples,'all_resultant_coefficient_formulas_verified':True})
    identities=json.loads((ROOT/'n6_n7_next_b1_combinations.json').read_text())
    expected={'c':mul(poly('c'),delta),'d':mul(poly('d'),delta),'q':mul(poly('25*e**2-17*e+1'),delta)}
    for name,target in expected.items():
        identity={}
        require(len(identities[name]['A'])==4,'Four combination multipliers required')
        for a,q in zip(identities[name]['A'],equations):identity=add(identity,mul(poly(a),q))
        require(add(identity,{m:-v for m,v in target.items()})=={},'Formal saturation identity failed: '+name)
    output={'independent_of_archived_classification':True,'uses_CAS':False,'uses_floating_point':False,'formula_reconstructions':rows,'discriminant_combination_identity':True,'e3_1_saturation_identities':['c*delta','d*delta','(25*e**2-17*e+1)*delta'],'coverage_scope':'All collision-free stationary n6 coefficient shapes with e2=0: e3=1 has c=d=0 and 25e^2-17e+1=0; e3=0,e4!=0 impossible; e3=e4=0 implies d*e=0, yielding center pentagon or regular hexagon.'}
    (ROOT/'n6_n7_next_special_verification.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print('Exact exceptional-chart verification passed:',json.dumps(output))

if __name__=='__main__':run()
