# 八点稀疏驻点图区独立证书

本包独立闭合整个八点物理驻点区域 `e2=e3=e4=0` 的必要候选覆盖，并精确比较剩余两个构型。完整证明为 `n6_n7_next_eight_independent.tex`；审计说明为 `n6_n7_next_eight_notes.md`。

离线运行：

```text
python -B -S -O verify_manifest.py
python -B -S -O n6_n7_next_eight_verify.py
```

只需Python标准库，已在Python3.12成功运行。`n6_n7_next_special_verify.py` 仅作为基础有理多项式/Bareiss算术库导入，不运行六点main，不读取六点JSON或作者组件。

验证以2592个精确网格点（2304+144+144）按严格参数次数界独立重建六个原始resultant方程，每一点均由整数判别式确认无碰撞。随后两个判别式组合证书按稀疏有理多项式正式展开验证。

首非零e5/e6图全部排空无碰撞候选；剩余 `p=X^8+cX+d` 的必要方程强制 `c*d=0`，仅剩中心加正七边形和正八边形。在moment8下前者值 `8^28/7^21` 严格大于后者 `8^8`。

范围严格限于原始moment问题的物理驻点 `e2=e3=e4=0` 区域。没有证明八点全局最大构型必在该区，也没有对带额外系数约束的所有非驻点配置给出最大值。

无CAS/第三方包、浮点决定、作者组件或网络输入。验证器重写 `n6_n7_next_eight_verification.json`。先检查SHA；不同操作系统的换行转换可能改变重写结果的字节哈希。
