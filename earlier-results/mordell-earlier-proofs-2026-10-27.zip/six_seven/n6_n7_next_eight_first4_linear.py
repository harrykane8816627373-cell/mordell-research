"""One bounded first-variation attempt, with no formal T polynomial.

For degree-eight p and degree-seven q0, the 15x15 Sylvester matrix has
seven p rows and eight q0 rows. Differentiate by replacing each of the
eight q0 rows by q1=Xp'-8p, then sum their exact determinants.
"""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'cas_runtime'))
import sympy as s
from sympy.polys.matrices import DomainMatrix
X,Y=s.symbols('X Y');b,c,d,u=s.symbols('b c d u')
start=time.monotonic();mode=sys.argv[1]
if mode!='eight_first4':raise ValueError(mode)
p=X**8+X**4+b*X**3+c*X**2+d*X+u
dp=s.diff(p,X);ddp=s.diff(dp,X)
q0=Y*dp-ddp;q1=X*dp-8*p
pd=s.Poly(p,X).all_coeffs();qd=s.Poly(q0,X).all_coeffs()
vd=[s.Poly(q1,X).nth(k) for k in range(7,-1,-1)]
rows=[]
for j in range(7):rows.append([0]*j+pd+[0]*(6-j))
for j in range(8):rows.append([0]*j+qd+[0]*(7-j))
K=s.ZZ.poly_ring(b,c,d,u,Y)
Rt=K.zero;contributions=[]
print('start first variation: eight row-replacement determinants',flush=True)
for j in range(8):
    replacement=[0]*j+vd+[0]*(7-j)
    matrix=list(rows);matrix[7+j]=replacement
    M=DomainMatrix.from_Matrix(s.Matrix(matrix)).convert_to(K).to_dense()
    det=M.det();Rt+=det
    contributions.append(str(K.to_sympy(det)))
    checkpoint={'algorithm':'8 second-row replacement determinants; no T variable','p':str(p),'completed_rows':len(contributions),'total_rows':8,'contributions':contributions,'elapsed':time.monotonic()-start}
    (HERE/'n6_n7_next_eight_first4_linear_checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
    print('row',j,'done',time.monotonic()-start,flush=True)
Rt=s.Poly(K.to_sympy(Rt),Y)
previous=json.loads((HERE/'n6_n7_next_eight_first4_partial.json').read_text())
delta=s.sympify(previous['delta']);R0=s.Poly(s.sympify(previous['R0']),Y)
if Rt.nth(7)!=0 or s.expand(Rt.nth(6)-56*delta)!=0:raise ArithmeticError('First-variation leading identities failed')
E=[Rt.nth(5)]+[Rt.nth(6-r)-(8-r)*(7-r)*R0.nth(8-r) for r in range(2,7)]
data={'mode':'eight_first4','n':8,'p':str(p),'delta':str(delta),'R0':str(R0.as_expr()),'Rt':str(Rt.as_expr()),'algorithm':'sum of 8 exact rowreplacement determinants at T=0','E':[str(s.factor(q)) for q in E]}
(HERE/'n6_n7_next_eight_first4_equations.json').write_text(json.dumps(data,indent=2)+'\n')
print('SUCCESS exact first variation, elapsed',time.monotonic()-start,flush=True)
