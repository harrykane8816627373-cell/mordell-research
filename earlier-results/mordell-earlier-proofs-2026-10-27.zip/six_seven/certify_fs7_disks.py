"""Rational Rouché certificate for the physically relevant seven-vortex charts.

The coverage input is Faugere--Svartz ISSAC 2012, section 7 / Figure 4.
The degree-356 chart is declared physically empty there, and is absent from
the archived symbolic-data file. We do not recompute that decomposition.

Generating centers uses mpmath/NumPy. Verification uses only the standard
library and explicit exact tests, so python -S -O --verify is supported.
"""
import argparse, hashlib, json, math, sys
from functools import lru_cache
from fractions import Fraction as F
from pathlib import Path
from parse_fs7_exact import get_components, triangular
from certify_fs6_disks import Z,ga,gn,gs,gm,scale,conj,normup,normlo,normsq,deriv,peval,taylor,pack,unpack,rounded,roundg,rouche,disjoint,variation_derivative
sys.set_int_max_str_digits(20000)
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'archivepolsys_vortices_N7.txt'
CERT=ROOT/'fs7_disk_certificate.json'
EXPECTED_SHA='d8cd0bc601071a7b4c0f7e9124c613eca9e3902cc58b29d8871686d541e73530'
def charts():
    comps,sha=get_components()
    if sha!=EXPECTED_SHA:raise ArithmeticError('Archived symbolic source hash mismatch')
    rows=[triangular(c) for c in comps]
    degrees=[1 if r['minimal'] is None else max(map(int,r['minimal'])) for r in rows]
    if degrees!=[1,1,2,6,18,82,64]:raise ArithmeticError('Author chart structure mismatch')
    return rows
def polynomial(q):return {int(k):F(c) for k,c in q.items()}
@lru_cache(maxsize=None)
def integer_form(key):
    p=dict(key)
    if not p:return (),1
    den=math.lcm(*(c.denominator for c in p.values()))
    a=tuple(int(p.get(k,F(0))*den) for k in range(max(p)+1))
    return a,den
def exact_eval_real(p,c):
    """Evaluate at a Gaussian rational with one final gcd per coordinate."""
    a,coefden=integer_form(tuple(sorted(p.items())))
    if not a:return Z
    den=math.lcm(c[0].denominator,c[1].denominator)
    cr=int(c[0]*den);ci=int(c[1]*den)
    ar=a[-1];ai=0;dpow=1
    for v in reversed(a[:-1]):
        ar,ai=ar*cr-ai*ci,ar*ci+ai*cr
        dpow*=den;ar+=v*dpow
    denominator=coefden*dpow
    return F(ar,denominator),F(ai,denominator)
def derivative_majorant(p,B,order=1):
    """Sum |a_k| (k)_order B^(k-order), with integer B>=0."""
    a,den=integer_form(tuple(sorted(p.items())))
    total=0
    for k in range(len(a)-1,order-1,-1):
        total=total*B+abs(a[k])*math.prod(range(k-order+1,k+1))
    return F(total,den)
def parameter_rouche(p,c,r):
    B=-((-((normup(c)+r).numerator))//(normup(c)+r).denominator)
    # Explicit ceiling without floating-point conversion.
    if F(B)<normup(c)+r:raise ArithmeticError('Majorant radius rounding failed')
    d={k-1:k*v for k,v in p.items() if k}
    lhs=normup(exact_eval_real(p,c))+r*r*derivative_majorant(p,B,2)/2
    rhs=normlo(exact_eval_real(d,c))*r
    if not lhs<rhs:raise ArithmeticError('Parameter Rouché inequality failed')
def coefficient_disks(row,b,rb):
    p={7:(F(1),F(0)),6:Z};errors={}
    for j in range(2,8):
        name='e'+str(j)
        if row['parameter']==name:v=b;variation=rb
        else:
            q=polynomial(row['coordinates'][name]);v=exact_eval_real(q,b)
            upper=normup(b)+rb;B=-((-upper.numerator)//upper.denominator)
            variation=rb*derivative_majorant(q,B,1)
        center=roundg(v);degree=7-j
        p[degree]=center if j%2==0 else gn(center)
        errors[degree]=variation+normup(gs(v,center))
    return p,errors
def force_exclusion(p,errors,z,r):
    q0=sum(normsq(c) for c in z);eq=sum(2*normup(c)*r+r*r for c in z)
    dp=deriv(p);ddp=deriv(dp)
    for i,c in enumerate(z):
        v1=peval(dp,c);v2=peval(ddp,c)
        residual=gs(scale(v2,q0),scale(gm(conj(c),v1),42))
        ev1=variation_derivative(p,errors,c,r,1);ev2=variation_derivative(p,errors,c,r,2)
        bound=eq*normup(v2)+(q0+eq)*ev2+42*(r*normup(v1)+(normup(c)+r)*ev1)
        if normlo(residual)>bound:return i
    return None
def delta_upper(z,r):
    q0=sum(normsq(c) for c in z);eq=sum(2*normup(c)*r+r*r for c in z)
    if q0<=eq:raise ArithmeticError('Nonpositive moment lower bound')
    product=F(1)
    for i,c in enumerate(z):
        for d in z[:i]:
            cd=gs(c,d);product*=normsq(cd)+4*normup(cd)*r+4*r*r
    return (F(7)/(q0-eq))**21*product
def generate():
    from screen_fs7_numerical import mp,parameter_roots,screen
    mp.mp.dps=500
    rows=charts();records=[]
    rb=F(1,10**250);rz=F(1,10**10)
    for idx,row in enumerate(rows,1):
        row=dict(row);row['component']=idx
        for b in parameter_roots(row,500):
            bc=tuple(rounded(F(mp.nstr(x,400)),300) for x in (b.real,b.imag))
            screening=screen(row,b)
            z=[tuple(rounded(F(x),45) for x in w) for w in screening['roots']]
            records.append({'component':idx,'parameter_center':pack(bc),'root_centers':[pack(w) for w in z]})
        print('Generated component',idx,flush=True)
    data={'source_sha256':EXPECTED_SHA,'parameter_radius':str(rb),'root_radius':str(rz),'records':records}
    CERT.write_text(json.dumps(data,indent=2))
    print('Generated',len(records),'parameter/root records',flush=True)
def verify(selected=None):
    data=json.loads(CERT.read_text());rows=charts()
    if data['source_sha256']!=EXPECTED_SHA:raise ArithmeticError('Certificate source hash mismatch')
    rb=F(data['parameter_radius']);rz=F(data['root_radius'])
    if rb<=0 or rz<=0:raise ArithmeticError('Nonpositive radius')
    records=data['records'];results=[];C7=F(7**21,6**15)
    if len(records)!=174 or any(r['component'] not in range(1,8) for r in records):raise ArithmeticError('Expected 174 chart solutions')
    for idx,row in enumerate(rows,1):
        if selected is not None and idx not in selected:continue
        rr=[r for r in records if r['component']==idx]
        pp=None if row['minimal'] is None else polynomial(row['minimal'])
        if len(rr)!=(1 if pp is None else max(pp)):raise ArithmeticError('Parameter root count mismatch')
        bc=[unpack(r['parameter_center']) for r in rr]
        if pp:
            disjoint(bc,rb)
            for b in bc:parameter_rouche(pp,b,rb)
        for rec,b in zip(rr,bc):
            p,errors=coefficient_disks(row,b,rb)
            z=[unpack(w) for w in rec['root_centers']]
            if len(z)!=7:raise ArithmeticError('Seven point roots required')
            disjoint(z,rz)
            for c in z:rouche(p,c,rz,errors)
            excluded=force_exclusion(p,errors,z,rz)
            if excluded is not None:
                result={'component':idx,'status':'excluded_by_force','root':excluded}
            elif idx==2:
                expected={7:(F(1),F(0)),6:Z,5:Z,4:Z,3:Z,2:Z,1:(F(1),F(0)),0:Z}
                if p!=expected or any(errors.values()):raise ArithmeticError('Center-hexagon polynomial mismatch')
                result={'component':idx,'status':'exact_center_hexagon','delta':str(C7)}
            elif idx==1:
                expected={7:(F(1),F(0)),6:Z,5:Z,4:Z,3:Z,2:Z,1:Z,0:(F(-1),F(0))}
                if p!=expected or any(errors.values()):raise ArithmeticError('Regular-heptagon polynomial mismatch')
                if not F(7**7)<C7:raise ArithmeticError('Heptagon strict comparison failed')
                result={'component':idx,'status':'strictly_below_C7','exact_delta':str(7**7),'integer_upper':7**7}
            else:
                upper=delta_upper(z,rz)
                bound=-((-upper.numerator)//upper.denominator)
                if not upper<C7 or not F(bound)<C7:raise ArithmeticError('Strict objective comparison failed')
                result={'component':idx,'status':'strictly_below_C7','integer_upper':bound}
            results.append(result)
        print('Certified component',idx,'roots',len(rr),flush=True)
    output={'source_sha256':EXPECTED_SHA,'certificate_sha256':hashlib.sha256(CERT.read_bytes()).hexdigest(),
            'external_coverage_input':'Faugere-Svartz ISSAC2012 section7 Figure4; archived physical-chart symbolic data',
            'checked_components':selected if selected is not None else list(range(1,8)),
            'algebraic_solutions_checked':len(results),'force_excluded':sum(r['status']=='excluded_by_force' for r in results),
            'strictly_below':sum(r['status']=='strictly_below_C7' for r in results),'center_hexagon':sum(r['status']=='exact_center_hexagon' for r in results),
            'target_C7':str(C7),'results':results}
    suffix='' if selected is None else '_'+ '_'.join(map(str,selected))
    (ROOT/('fs7_disk_verification_result'+suffix+'.json')).write_text(json.dumps(output,indent=2))
    print('EXACT verification passed:',{k:v for k,v in output.items() if k!='results'},flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--generate',action='store_true');ap.add_argument('--verify',action='store_true');ap.add_argument('--components',nargs='+',type=int)
    args=ap.parse_args()
    if args.generate:generate()
    if args.verify or not args.generate:verify(args.components)
