"""Independent exact spot checks of the n8 first-e4 resultant equations.

This uses only the Python standard library. Sixteen points are not a
degree-determining grid, so this is a diagnostic check, not a complete
certificate of four-parameter coefficient formulas or chart coverage.
"""
from pathlib import Path
from fractions import Fraction as F
import itertools,json
import n6_n7_next_special_verify as arithmetic
ROOT=Path(__file__).resolve().parent
require=arithmetic.require
pdiv=arithmetic.pdiv;pmul=arithmetic.pmul;inverse=arithmetic.inverse

def reconstruct(b,c,d,u):
    pint=[u,d,c,b,1,0,0,0,1];dpint=[d,2*c,3*b,4,0,0,0,8]
    delta=arithmetic.resultant(pint,dpint)
    require(delta!=0,'Singular first-e4 sample')
    p=list(map(F,pint));dp=list(map(F,dpint));ddp=list(map(F,[2*c,6*b,12,0,0,0,56]))
    g=pdiv(pmul(ddp,inverse(dp,p)),p)[1]
    power=[F(1)];S={};m={};rootsums=[8,0,0,0,-4,-5*b,-6*c,-7*d]
    def trace(q):return sum(v*rootsums[j] for j,v in enumerate(q))
    for k in range(1,8):
        power=pdiv(pmul(power,g),p)[1]
        S[k]=trace(power);m[k]=trace(pdiv([F(0)]+power,p)[1])
    require(S[1]==0 and m[1]==56,'Universal n8 trace identities failed')
    q2=-S[2]/2;q3=-S[3]/3;q4=(S[2]**2/2-S[4])/4;q5=q2*q3-S[5]/5
    q6=(-S[6]-q2*S[4]-q3*S[3]-q4*S[2])/6
    E=[m[2],m[3]+26*q2,m[4]+q2*m[2]+36*q3,m[5]+q2*m[3]+q3*m[2]+44*q4,m[6]+q2*m[4]+q3*m[3]+q4*m[2]+50*q5,m[7]+q2*m[5]+q3*m[4]+q4*m[3]+q5*m[2]+54*q6]
    return delta,[delta*v for v in E]

def run():
    arithmetic.VARS=('b','c','d','u');arithmetic.ZERO=(0,0,0,0)
    data=json.loads((ROOT/'n6_n7_next_eight_first4_equations.json').read_text())
    require(data['n']==8 and data['p']=='X**8 + X**4 + X**3*b + X**2*c + X*d + u','Unexpected polynomial convention')
    delta=arithmetic.poly(data['delta']);E=list(map(arithmetic.poly,data['E']))
    points=list(itertools.product((0,1),(0,1),(0,1),(201,202)))
    for point in points:
        actual_delta,actual_E=reconstruct(*point)
        require(arithmetic.evaluate(delta,*point)==actual_delta,'Exact first-e4 resultant spot check failed')
        require(all(arithmetic.evaluate(q,*point)==v for q,v in zip(E,actual_E)),'Exact first-e4 force coefficient spot check failed')
    result={'uses_CAS':False,'uses_floating_point':False,'exact_points':[list(q) for q in points],'equations_checked':6,'all_points_passed':True,'scope':'Diagnostic exact spot checks, not a degree-determining formula certificate and not a proof of physical chart coverage.'}
    (ROOT/'n6_n7_next_eight_first4_spotcheck.json').write_text(json.dumps(result,indent=2)+'\n')
    print('First-e4 independent rational spot checks passed:',len(points),'points, six equations per point',flush=True)

if __name__=='__main__':run()
