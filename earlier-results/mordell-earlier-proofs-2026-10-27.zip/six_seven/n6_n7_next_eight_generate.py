"""Generate six original n8 necessary resultant equations on sparse charts."""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'cas_runtime'))
import sympy as s
X,Y,T=s.symbols('X Y T');b,c,d,u=s.symbols('b c d u')
mode=sys.argv[1]
if mode=='eight_a1':p=X**8-X**3+b*X**2+c*X+d
elif mode=='eight_b1':p=X**8+X**2+c*X+d
elif mode=='eight_b0':p=X**8+c*X+d
elif mode=='eight_first4':p=X**8+X**4+b*X**3+c*X**2+d*X+u
else:raise ValueError(mode)
start=time.monotonic();print('start',mode,flush=True)
dp=s.diff(p,X);ddp=s.diff(dp,X)
delta=s.resultant(p,dp,X);print('delta done',time.monotonic()-start,flush=True)
if mode=='eight_first4':
    (HERE/'n6_n7_next_eight_first4_partial.json').write_text(json.dumps({'n':8,'p':str(p),'delta':str(delta),'phase':'before R0; no E or combination certificate'},indent=2)+'\n')
R0=s.resultant(p,Y*dp-ddp,X);print('R0 done',time.monotonic()-start,flush=True)
if mode=='eight_first4':
    (HERE/'n6_n7_next_eight_first4_partial.json').write_text(json.dumps({'n':8,'p':str(p),'delta':str(delta),'R0':str(R0),'phase':'before Rt; no E or combination certificate'},indent=2)+'\n')
Rt=s.diff(s.resultant(p,Y*dp-ddp+T*(X*dp-8*p),X),T).expand().subs(T,0).expand()
print('Rt done',time.monotonic()-start,flush=True)
R0=s.Poly(R0,Y);Rt=s.Poly(Rt,Y)
E=[]
for r in range(1,7):
    v=Rt.nth(6-r)
    if r>=2:v-=(8-r)*(7-r)*R0.nth(8-r)
    E.append(v)
data={'mode':mode,'n':8,'p':str(p),'delta':str(s.factor(delta)),'E':[str(s.factor(q)) for q in E]}
(HERE/('n6_n7_next_'+mode+'_equations.json')).write_text(json.dumps(data,indent=2)+'\n')
print('delta',s.factor(delta),flush=True)
for j,q in enumerate(E,1):print('E'+str(j),s.factor(q),flush=True)
print('elapsed',time.monotonic()-start,flush=True)
