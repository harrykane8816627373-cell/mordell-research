"""Bounded exploratory generation of n6 exceptional coefficient equations.

No archived classification polynomials are input. Worker calls should be
limited to 120 seconds by the invoking parent process.
"""
from pathlib import Path
import json, sys, time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'cas_runtime'))
import sympy as s

X,Y,T=s.symbols('X Y T')
c,d,e=s.symbols('c d e')
mode=sys.argv[1] if len(sys.argv)>1 else 'c1'
if mode=='c1': p=X**6+X**2+d*X+e
elif mode=='c0': p=X**6+d*X+e
elif mode=='d1': p=X**6-X+e
elif mode=='b1': p=X**6-X**3+c*X**2+d*X+e
else: raise ValueError(mode)
start=time.monotonic()
print('start',mode,flush=True)
dp=s.diff(p,X); ddp=s.diff(dp,X)
delta=s.resultant(p,dp,X)
print('delta',s.factor(delta),time.monotonic()-start,flush=True)
R0=s.resultant(p,Y*dp-ddp,X)
print('R0 done',time.monotonic()-start,flush=True)
# Use the determinant's first variation only; the extra formal variable
# need not be retained to high degree.
Rt=s.diff(s.resultant(p,(Y+T*X)*dp-ddp,X),T).subs(T,0).expand()
print('Rt done',time.monotonic()-start,flush=True)
R0=s.Poly(R0,Y);Rt=s.Poly(Rt,Y)
E=[Rt.nth(3),Rt.nth(2)-12*R0.nth(4),Rt.nth(1)-6*R0.nth(3),Rt.nth(0)-2*R0.nth(2)]
data={'mode':mode,'p':str(p),'delta':str(s.factor(delta)), 'E':[str(s.factor(q)) for q in E]}
(HERE/('n6_n7_next_'+mode+'_equations.json')).write_text(json.dumps(data,indent=2)+'\n')
for j,q in enumerate(E,1): print('E'+str(j),s.factor(q),flush=True)
print('elapsed',time.monotonic()-start,flush=True)
