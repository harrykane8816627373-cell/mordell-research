"""Read the author-supplied N=7 triangular bases with exact stdlib arithmetic.

This parses published data; it does not recompute their decomposition.
"""
import ast, hashlib, json, sys
from fractions import Fraction as F
from pathlib import Path
sys.set_int_max_str_digits(20000)
ROOT = Path(__file__).resolve().parent
VARS = ['e2', 'e3', 'e4', 'e5', 'e6', 'e7']
ZERO = (0,) * len(VARS)
def add(a, b):
    r = dict(a)
    for m, c in b.items():
        r[m] = r.get(m, F(0)) + c
        if not r[m]: del r[m]
    return r
def mul(a, b):
    r = {}
    for m, c in a.items():
        for n, d in b.items():
            k = tuple(x+y for x,y in zip(m,n))
            r[k] = r.get(k, F(0)) + c*d
    return {m:c for m,c in r.items() if c}
def parse(node):
    if isinstance(node, ast.Constant): return {ZERO:F(node.value)}
    if isinstance(node, ast.Name):
        m=list(ZERO);m[VARS.index(node.id)]=1
        return {tuple(m):F(1)}
    if isinstance(node, ast.UnaryOp):
        p=parse(node.operand)
        return p if isinstance(node.op,ast.UAdd) else {m:-c for m,c in p.items()}
    if isinstance(node,ast.BinOp):
        a=parse(node.left)
        if isinstance(node.op,ast.Pow):
            r={ZERO:F(1)}
            for _ in range(node.right.value): r=mul(r,a)
            return r
        b=parse(node.right)
        if isinstance(node.op,ast.Add): return add(a,b)
        if isinstance(node.op,ast.Sub): return add(a,{m:-c for m,c in b.items()})
        if isinstance(node.op,ast.Mult): return mul(a,b)
        if isinstance(node.op,ast.Div):
            if set(b)!={ZERO}: raise ValueError('nonconstant denominator')
            return {m:c/b[ZERO] for m,c in a.items()}
    raise ValueError(ast.dump(node))
def univar(p,j):
    if any(any(k for i,k in enumerate(m) if i!=j) for m in p):
        raise ValueError('not univariate')
    return {m[j]:c for m,c in p.items()}
def get_components():
    data=(ROOT/'archivepolsys_vortices_N7.txt').read_bytes()
    src=''.join(x for x in data.decode().splitlines() if not x.startswith('#')).replace('^','**').rstrip(';')
    tree=ast.parse(src,mode='eval')
    return [[parse(p) for p in comp.elts] for comp in tree.body.elts], hashlib.sha256(data).hexdigest()
def triangular(comp):
    candidates=[]
    for p in comp:
        for j in range(len(VARS)):
            try:
                q=univar(p,j)
                if max(q)>1: candidates.append((max(q),j,q))
            except ValueError: pass
    if not candidates:
        # All coordinates are rational constants.
        par=None;minimal=None
    else:
        _,par,minimal=max(candidates)
    coord={}
    for j in range(len(VARS)):
        if j==par: continue
        unit=list(ZERO);unit[j]=1;unit=tuple(unit)
        for p in comp:
            a=p.get(unit)
            if not a: continue
            rem=dict(p);del rem[unit]
            try:
                q=univar(rem,par) if par is not None else {0:rem.get(ZERO,F(0))}
            except ValueError: continue
            if par is None and any(m!=ZERO for m in rem): continue
            coord[VARS[j]]={str(k):str(-c/a) for k,c in q.items()}
            break
        if VARS[j] not in coord: raise ValueError(f'No triangular coordinate {VARS[j]}')
    return {'parameter':None if par is None else VARS[par],
            'minimal':None if minimal is None else {str(k):str(c) for k,c in minimal.items()},
            'coordinates':coord}
def main():
    comps,sha=get_components();rows=[]
    for i,comp in enumerate(comps,1):
        row=triangular(comp);row['component']=i;rows.append(row)
        deg=1 if row['minimal'] is None else max(map(int,row['minimal']))
        coefficients=[F(v) for q in row['coordinates'].values() for v in q.values()]
        maxbits=max(max(abs(c.numerator).bit_length(),c.denominator.bit_length()) for c in coefficients)
        print('component',i,'parameter',row['parameter'],'degree',deg,'coordinate terms',sum(len(q) for q in row['coordinates'].values()),'max coefficient bits',maxbits)
    result={'source_sha256':sha,'components':rows}
    (ROOT/'fs7_parsed_exact.json').write_text(json.dumps(result,separators=(',',':')))
    print('total parameter roots',sum(1 if r['minimal'] is None else max(map(int,r['minimal'])) for r in rows),'sha256',sha)
if __name__=='__main__': main()
