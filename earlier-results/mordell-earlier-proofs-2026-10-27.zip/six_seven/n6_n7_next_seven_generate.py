"""Generate n7 sparse first-nonzero coefficient chart equations from scratch."""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'cas_runtime'))
import sympy as s
X,Y,T=s.symbols('X Y T');b,c,d=s.symbols('b c d')
mode=sys.argv[1]
if mode=='seven_a1':p=X**7+X**3+b*X**2+c*X+d
elif mode=='seven_b1':p=X**7-X**2+c*X+d
elif mode=='seven_b0':p=X**7+c*X+d
else:raise ValueError(mode)
start=time.monotonic();print('start',mode,flush=True)
dp=s.diff(p,X);ddp=s.diff(dp,X)
delta=s.resultant(p,dp,X);print('delta done',time.monotonic()-start,flush=True)
R0=s.resultant(p,Y*dp-ddp,X);print('R0 done',time.monotonic()-start,flush=True)
# The monic reduction keeps the second polynomial's X-degree at most 6.
q=Y*dp-ddp+T*(X*dp-7*p)
Rt=s.diff(s.resultant(p,q,X),T).expand().subs(T,0).expand()
print('Rt done',time.monotonic()-start,flush=True)
R0=s.Poly(R0,Y);Rt=s.Poly(Rt,Y)
E=[Rt.nth(4),Rt.nth(3)-20*R0.nth(5),Rt.nth(2)-12*R0.nth(4),Rt.nth(1)-6*R0.nth(3),Rt.nth(0)-2*R0.nth(2)]
data={'mode':mode,'n':7,'p':str(p),'delta':str(s.factor(delta)),'E':[str(s.factor(q)) for q in E]}
(HERE/('n6_n7_next_'+mode+'_equations.json')).write_text(json.dumps(data,indent=2)+'\n')
print('delta',s.factor(delta),flush=True)
for j,q in enumerate(E,1):print('E'+str(j),s.factor(q),flush=True)
print('elapsed',time.monotonic()-start,flush=True)
