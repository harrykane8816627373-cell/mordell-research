# Eight-point first-e4 chart: exact first variation obtained

The chart is

`p(X)=X^8+X^4+b X^3+c X^2+d X+u`.

This chart has e2=e3=0 and its nonzero e4 coefficient has been normalized.
It contains genuine two-square configurations. No discriminant exclusion of
the whole chart is asserted.

## Successful calculation

Set `q0=Y p'-p''` and `q1=Xp'-8p`. The resultant
`R(Y,T)=Res_X(p,q0+Tq1)` has a 15 by 15 Sylvester matrix. For p of degree 8
and q0 of degree 7, the matrix has **seven p rows and eight q0 rows**.
Only the eight q0 rows depend on T. Multilinearity gives exactly

`Rt(Y)=sum_(j=0)^7 det(S with q0-row j replaced by the corresponding q1 row)`.

All determinants are over `ZZ[b,c,d,u,Y]`, and there is no T variable to
expand. The eight determinants finished in 10.14 seconds; constructing and
saving Rt and the six E polynomials finished in 13.92 seconds, below the
120-second worker cap. This remedies the previous algorithmic obstacle
(expanding the complete T resultant did not finish in the bounded runs).

The saved file `n6_n7_next_eight_first4_equations.json` contains p, delta,
R0, Rt, and all six necessary equations, 53,860 bytes. Here

`delta=Res(p,p')`, `R0=R(Y,0)`, `Rt=partial_T R(Y,0)`.

The leading checks `[Y^7]Rt=0` and `[Y^6]Rt=56 delta` passed exactly.
The six polynomials are

`E1=[Y^5]Rt`,

`Er=[Y^(6-r)]Rt-(8-r)(7-r)[Y^(8-r)]R0`, for r=2,...,6.

They follow from the existing exact necessary identity `Rt=R0''` for the
double-force equation. Generating them does not itself classify their
collision-free zeros, and the physical conjugate pairing still has to be
imposed on any algebraic solutions.

## Independent checks and the finite negative result

The standard-library checker `n6_n7_next_eight_first4_spotcheck.py` rebuilt
delta as an integer resultant and all six E values using exact rational
quotient-ring traces. All 16 Cartesian test points
`(b,c,d,u) in {0,1}^3 x {201,202}` passed under `python -B -S -O`.
These are **diagnostic checks**, not a degree-determining four-parameter
grid or a full coefficient-formula certificate. Formula generation is
the exact symbolic determinant algorithm above.

The finite multiplier searches tested b delta and d delta through total
multiplier degree 9, using the residual fourth-root grading with weights
`(b,c,d,u)=(1,2,3,0) mod 4`. They finished in 15.92 and 16.52 seconds and
produced no identity. At degree 9 the modular coefficient matrices have
rank deficiencies, so the modular obstruction there does **not** prove
nonmembership over QQ or in the unbounded polynomial ideal.

There is a rigorous, independently replayed **degree-at-most-eight** result
for the saved exact E polynomials. The coefficient matrices modulo the
prime 1,000,003 have full column ranks:

| Target | Columns | Rank | Rank after adjoining target |
|---|---:|---:|---:|
| b delta | 741 | 741 | 742 |
| d delta | 744 | 744 | 745 |

Consequently they have full column rank over QQ as well, while the
augmentation has larger rank. Thus neither target admits an identity
`target=sum Ai Ei` with all multiplier total degrees at most eight.
The grading projection ensures that omitting mismatched-weight monomials
does not omit any possible QQ identity within that degree bound.
`n6_n7_next_eight_first4_degree8_verify.py` verifies the prime, every
grading, and these ranks using only the standard library. This result
identifies a concrete limit of the previous low-degree combination
method. It does not imply that b or d can be nonzero in a physical
stationary configuration, nor that higher-degree identities are absent.

No c delta search, physical exclusion, root classification, or unrestricted
eight-point global maximum is claimed. The previously delivered eight-point
e2=e3=e4=0 proof fragment and its certificate bundle remain unchanged.

## Reproduction

From the workspace root, with the bundled Python executable (or any
compatible Python) assigned to a task-specific variable `$taskPython`, run:

```powershell
& $taskPython work\n6_n7_next_bounded_run.py eight_first4 n6_n7_next_eight_first4_linear.py 120
& $taskPython -B -S -O work\n6_n7_next_eight_first4_spotcheck.py
& $taskPython -B -S -O work\n6_n7_next_eight_first4_degree8_verify.py
```

The generator uses local SymPy in `work/cas_runtime` and the saved
`n6_n7_next_eight_first4_partial.json` for delta and R0. The two independent
checks use no CAS and no network. Their reusable arithmetic library is
`n6_n7_next_special_verify.py`; importing it does not run its six-point
checks or require the six-point JSON certificates.

The optional heuristic degree-nine screening runs are:

```powershell
& $taskPython work\n6_n7_next_bounded_run.py eight_first4_b n6_n7_next_eight_first4_combination.py 120
& $taskPython work\n6_n7_next_bounded_run.py eight_first4_d n6_n7_next_eight_first4_combination.py 120
```
