"""Verify the archived N=6 component equations using rational arithmetic only.

This is a containment check, not an independent completeness computation.
The first eight components use the independently generated resultant E input.
The three e2=0 components use direct trace identities for P''/P'.
"""
import ast
import json
from fractions import Fraction as Q
from verify_fs6_dual_standard import ROOT, components, parse, Ring, evaluate_sparse, trim, pdiv


def padd(a,b):
    c=[Q(0)]*max(len(a),len(b))
    for i,x in enumerate(a):c[i]+=x
    for i,x in enumerate(b):c[i]+=x
    return trim(c)


def pmul(a,b):
    c=[Q(0)]*max(0,len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):c[i+j]+=x*y
    return trim(c)


def inv(R,a):
    oldr,r=R.f,trim(a); olds,s=[],[Q(1)]
    while r:
        q,newr=pdiv(oldr,r)
        oldr,r=r,newr
        olds,s=s,padd(olds,[-x for x in pmul(q,s)])
    if len(oldr)!=1:raise ValueError('Noninvertible coefficient')
    return R.reduce([x/oldr[0] for x in olds])


def gcd_degree(a,b):
    while b:a,b=b,pdiv(a,b)[1]
    return len(a)-1


def zeroq(q):return not any(q[0]) and not any(q[1])


def require(condition,message):
    """Keep certificate decisions active under Python -O."""
    if not condition:raise ArithmeticError(message)


def run():
    source=json.loads((ROOT/'fs6_resultant_data.json').read_text())
    eqs=[parse(ast.parse(s,mode='eval').body,['b','c','d','e']) for s in source['E']]
    delta=parse(ast.parse(source['delta'],mode='eval').body,['b','c','d','e'])
    raw=(ROOT/'archivepolsys_vortices_N6.txt').read_text()
    raw='\n'.join(s for s in raw.splitlines() if not s.startswith('#'))
    blocks=ast.parse(raw.strip().rstrip(';').replace('^','**'),mode='eval').body.elts
    results=[]
    for j,(F,C,K,E) in enumerate(components()):
        R=Ring(F);b=(R.zero,R.one);c=(R.univ(C),R.zero)
        k=(R.univ(K),R.zero);e=(R.univ(E),R.zero);d=R.qmul(b,k)
        values=[b,c,d,e]
        flags=[zeroq(evaluate_sparse(q,R,values)) for q in eqs]
        D=evaluate_sparse(delta,R,values)
        require(not any(D[1]),'Unexpected quadratic discriminant coefficient')
        gd=gcd_degree(R.f,trim(D[0]))
        sf=gcd_degree(R.f,trim([i*x for i,x in enumerate(R.f)][1:]))
        row={'component':j+1,'exact_E_zero':flags,'discriminant_gcd_degree':gd,'eliminant_squarefree_gcd_degree':sf}
        print(row,flush=True);results.append(row)
        require(all(flags) and gd==0 and sf==0,'Generic component identity or squarefreeness failed')
    # Two rational points, b=-e3 and d=-e5.
    for j,sgn in ((5,1),(6,-1)):
        R=Ring([Q(0),Q(1)])
        vals=[Q(-sgn*8,3),Q(3),Q(sgn*8,3),Q(19,9)]
        values=[(R.univ([x]),R.zero) for x in vals]
        flags=[zeroq(evaluate_sparse(q,R,values)) for q in eqs]
        D=evaluate_sparse(delta,R,values)
        row={'component':j+1,'exact_E_zero':flags,'discriminant_nonzero':not zeroq(D)}
        print(row,flush=True);results.append(row)
        require(all(flags) and not zeroq(D),'Rational component identity or discriminant failed')
    # Component 8: b=d=0; its remaining coefficient c is the parameter.
    polys=[parse(node,['e2','e3','e4','e5','e6']) for node in blocks[7].elts]
    fh=polys[-1];F=[Q(0)]*(1+max(e[2] for e in fh))
    for ee,v in fh.items():F[ee[2]]=v
    e6=polys[1];key=(0,0,0,0,1);lead=e6[key]
    Ec=[Q(0)]*(1+max(ee[2] for ee in e6 if ee!=key))
    for ee,v in e6.items():
        if ee!=key:Ec[ee[2]]=-v/lead
    R=Ring(F);values=[(R.zero,R.zero),(R.B,R.zero),(R.zero,R.zero),(R.univ(Ec),R.zero)]
    flags=[zeroq(evaluate_sparse(q,R,values)) for q in eqs]
    D=evaluate_sparse(delta,R,values)
    require(not any(D[1]),'Unexpected even-chart discriminant coefficient')
    gd=gcd_degree(R.f,trim(D[0]))
    row={'component':8,'exact_E_zero':flags,'discriminant_gcd_degree':gd}
    print(row,flush=True);results.append(row)
    require(all(flags) and gd==0,'Even-chart component identity or discriminant failed')
    # Component 9: p=x^6-x^3+e, 25e^2-17e+1=0.
    # Introduce t=x^3, t^2-t+e=0, and use g=P''/P'
    # = 2(5t-1)/(x(2t-1)). The 3-fold rotational symmetry makes
    # m2,m3,m5,S2,S4 zero, leaving only m4=8S3.
    R=Ring([Q(1),Q(-17),Q(25)]); e=R.B
    Z=R.zero;O=R.one
    def add(a,b):return R.add(a,b)
    def neg(a):return R.neg(a)
    def scale(a,v):return [v*x for x in a]
    def tadd(a,b):return (add(a[0],b[0]),add(a[1],b[1]))
    def tmul(a,b):
        bb=R.mul(a[1],b[1])
        return (add(R.mul(a[0],b[0]),neg(R.mul(e,bb))),add(add(R.mul(a[0],b[1]),R.mul(a[1],b[0])),bb))
    def tinv(a):
        # Conjugate t -> 1-t; norm is in the e coefficient field.
        conj=(add(a[0],a[1]),neg(a[1]))
        norm=tmul(a,conj)
        require(not any(norm[1]),'Quadratic-extension norm failed')
        norminv=inv(R,norm[0])
        return (R.mul(conj[0],norminv),R.mul(conj[1],norminv))
    def tpow(a,k):
        out=(O,Z)
        for _ in range(k):out=tmul(out,a)
        return out
    def tr(a):return add(scale(a[0],Q(2)),a[1])
    t=(Z,O);u=(scale(O,Q(-2)),scale(O,Q(10)))
    v=(neg(O),scale(O,Q(2)))
    u_over_v=tmul(u,tinv(v))
    g3=tmul(tpow(u_over_v,3),tinv(t))
    xg4=tmul(tpow(u_over_v,4),tinv(t))
    residual=add(tr(xg4),neg(scale(tr(g3),Q(8))))
    require(not any(residual),'Threefold-chart trace identity failed')
    row={'component':9,'exact_moment_residual_zero':True,'other_moment_equations':'zero by 3-fold rotation'}
    print(row,flush=True);results.append(row)
    # Components 10 and 11: p=x(x^5-1) and p=x^6+1.
    # g(0)=0, g(x)=6/x on outer fifth roots in component 10;
    # g(x)=5/x on sixth roots in component 11. The sums of all
    # nontrivial roots-of-unity powers appearing in m2..m5,S2..S4
    # vanish exactly; m1=30 in both cases.
    for j,order in ((10,5),(11,6)):
        require(all((1-k)%order for k in range(2,6)),'Mixed roots-of-unity sum failed')
        require(all(k%order for k in range(2,5)),'Pure roots-of-unity sum failed')
        row={'component':j,'exact_moment_residual_zero':True,'proof':'roots-of-unity power sums'}
        print(row,flush=True);results.append(row)
    (ROOT/'fs6_exact_component_checks.json').write_text(json.dumps(results,indent=2))
    print('All eleven components satisfy the necessary double-force coefficient equations exactly.',flush=True)


if __name__=='__main__':run()
