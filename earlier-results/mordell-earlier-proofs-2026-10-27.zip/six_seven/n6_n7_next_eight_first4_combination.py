"""Finite exact multiplier search for b*delta or d*delta on first-e4 chart.

Use the residual fourth-root homogeneity to omit impossible coefficients.
A sparse column-span calculation modulo a prime screens degrees before the
exact rational solve. The screen alone does not certify nonexistence over QQ
(ranks can drop at the prime). Success is only recorded after expansion
of the rational polynomial identity in characteristic zero.
"""
from pathlib import Path
import sys, json, time, itertools
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'cas_runtime'))
import sympy as s
b,c,d,u=s.symbols('b c d u'); variables=(b,c,d,u)
mode=sys.argv[1]
if mode=='eight_first4_b': target=b; target_weight=1
elif mode=='eight_first4_d': target=d; target_weight=3
else: raise ValueError(mode)
started=time.monotonic(); prime=1000003
j=json.loads((HERE/'n6_n7_next_eight_first4_equations.json').read_text())
E=[s.Poly(s.sympify(q),*variables) for q in j['E']]
D=s.Poly(target*s.sympify(j['delta']),*variables)
vweights=(1,2,3,0); weights=[(-r)%4 for r in range(1,7)]
terms=[q.terms() for q in E]; all_columns=[]; maps=[]; pivots={}

def residue(col):
    return {m:int(v)%prime for m,v in col.items() if int(v)%prime}

def reduce_col(vec):
    while vec:
        lead=max(vec)
        if lead not in pivots: return vec
        scale=vec[lead]
        for m,v in pivots[lead].items():
            q=(vec.get(m,0)-scale*v)%prime
            if q: vec[m]=q
            else: vec.pop(m,None)
    return vec

for bound in range(10):
    mon=[m for m in itertools.product(range(bound+1),repeat=4) if sum(m)==bound]
    for idx,qterms in enumerate(terms):
        for m in mon:
            if (sum(k*w for k,w in zip(m,vweights))+weights[idx])%4!=target_weight: continue
            col={tuple(i+k for i,k in zip(n,m)):v for n,v in qterms}
            all_columns.append(col); maps.append((idx,m))
            vec=reduce_col(residue(col))
            if vec:
                lead=max(vec); inv=pow(vec[lead],-1,prime)
                pivots[lead]={n:v*inv%prime for n,v in vec.items()}
    rem=reduce_col(residue(dict(D.terms())))
    status={'target':str(target)+'*delta','bound':bound,'columns':len(all_columns),'modular_rank':len(pivots),'modular_remainder_terms':len(rem),'elapsed':time.monotonic()-started}
    (HERE/('n6_n7_next_'+mode+'_checkpoint.json')).write_text(json.dumps(status,indent=2)+'\n')
    print(mode,'degree',bound,'columns',len(all_columns),'rank',len(pivots),'remainder',len(rem),'elapsed',time.monotonic()-started,flush=True)
    if rem: continue
    rows=sorted(set(D.monoms()).union(*(q.keys() for q in all_columns)))
    A=s.Matrix([[col.get(row,0) for col in all_columns] for row in rows])
    rhs=s.Matrix([D.coeff_monomial(row) for row in rows])
    print('exact rational solve',A.shape,flush=True)
    try: sol,params=A.gauss_jordan_solve(rhs)
    except ValueError: continue
    sol=sol.subs({q:0 for q in params})
    coeff=[s.expand(sum(sol[k]*s.prod(x**i for x,i in zip(variables,m)) for k,(idx,m) in enumerate(maps) if idx==j)) for j in range(6)]
    if s.expand(sum(a*q.as_expr() for a,q in zip(coeff,E))-D.as_expr())!=0: raise ArithmeticError('Exact identity failed')
    out={'identity':str(target)+'*delta=sum_i Ai Ei','coefficient_degree_bound':bound,'variables':[str(x) for x in variables],'A':[str(q) for q in coeff],'exact_check':'polynomial expansion over QQ gives zero','elapsed':time.monotonic()-started}
    (HERE/('n6_n7_next_'+mode+'_combination.json')).write_text(json.dumps(out,indent=2)+'\n')
    print('FOUND',mode,'degree',bound,'elapsed',time.monotonic()-started,flush=True)
    break
else: print('No identity found through multiplier total degree 9; modular screening is not a proof of nonexistence over QQ',flush=True)
