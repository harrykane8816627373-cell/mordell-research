"""Offline independent n8 e2=e3=e4=0 sparse-chart coverage certificate.

Reconstructs all six original resultant equations on a degree-determining
Cartesian grid, then formally verifies discriminant combinations. Uses
only standard-library rational arithmetic from the n6 checker as a library.
"""
from pathlib import Path
from fractions import Fraction as F
import itertools,json
import n6_n7_next_special_verify as arithmetic

ROOT=Path(__file__).resolve().parent
require=arithmetic.require
pdiv=arithmetic.pdiv;pmul=arithmetic.pmul;inverse=arithmetic.inverse

def coefficients(a,b,c,d):
    pint=[d,c,b,a,0,0,0,0,1];dpint=[c,2*b,3*a,0,0,0,0,8]
    delta=arithmetic.resultant(pint,dpint)
    require(delta!=0,'Singular n8 reconstruction sample')
    p=list(map(F,pint));dp=list(map(F,dpint));ddp=list(map(F,[2*b,6*a,0,0,0,0,56]))
    g=pdiv(pmul(ddp,inverse(dp,p)),p)[1]
    power=[F(1)];S={};m={};rootsums=[8,0,0,0,0,-5*a,-6*b,-7*c]
    def trace(q):return sum(v*rootsums[j] for j,v in enumerate(q))
    for k in range(1,8):
        power=pdiv(pmul(power,g),p)[1]
        S[k]=trace(power);m[k]=trace(pdiv([F(0)]+power,p)[1])
    require(S[1]==0 and m[1]==56,'Universal n8 force trace identity failed')
    q2=-S[2]/2;q3=-S[3]/3;q4=(S[2]**2/2-S[4])/4;q5=q2*q3-S[5]/5
    q6=(-S[6]-q2*S[4]-q3*S[3]-q4*S[2])/6
    E=[m[2],m[3]+26*q2,m[4]+q2*m[2]+36*q3,m[5]+q2*m[3]+q3*m[2]+44*q4,m[6]+q2*m[4]+q3*m[3]+q4*m[2]+50*q5,m[7]+q2*m[5]+q3*m[4]+q4*m[3]+q5*m[2]+54*q6]
    return delta,[delta*v for v in E]

def verify_mode(mode,variables,expected_p,sample_ranges,root_parameters):
    arithmetic.VARS=variables;arithmetic.ZERO=(0,)*len(variables)
    data=json.loads((ROOT/('n6_n7_next_'+mode+'_equations.json')).read_text())
    require(data['n']==8 and data['p']==expected_p,'Unexpected n8 polynomial convention')
    delta=arithmetic.poly(data['delta']);E=list(map(arithmetic.poly,data['E']))
    require(len(E)==6,'Six original n8 necessary equations required')
    limits=[15]*(len(variables)-1)+[8]
    for q in [delta]+E:require(all(all(k<=bound for k,bound in zip(m,limits)) for m in q),'n8 parameter degree bound failed')
    samples=0
    for point in itertools.product(*sample_ranges):
        actual_delta,actual_E=coefficients(*root_parameters(point))
        require(arithmetic.evaluate(delta,*point)==actual_delta,'n8 resultant formula mismatch')
        require(all(arithmetic.evaluate(q,*point)==v for q,v in zip(E,actual_E)),'n8 necessary resultant coefficient mismatch')
        samples+=1
    if mode!='eight_b0':
        certificate=json.loads((ROOT/('n6_n7_next_'+mode+'_combination.json')).read_text());A=certificate['A']
        require(len(A)==6,'Six n8 combination multipliers required')
        identity={}
        for a,q in zip(A,E):identity=arithmetic.add(identity,arithmetic.mul(arithmetic.poly(a),q))
        require(arithmetic.add(identity,{m:-v for m,v in delta.items()})=={},'Formal n8 discriminant identity failed')
        certificate_kind='discriminant combination'
    else:
        require(E[0]==arithmetic.poly('822083584*c*d**6'),'Final n8 sparse-chart product identity mismatch')
        certificate_kind='necessary product identity'
    print('Verified',mode,'exact samples',samples,'certificate',certificate_kind,flush=True)
    return {'mode':mode,'Cartesian_grid':[len(r) for r in sample_ranges],'exact_samples':samples,'coefficient_formulas_reconstructed':True,'formal_certificate_kind':certificate_kind,'formal_certificate_verified':True}

def run():
    rows=[]
    rows.append(verify_mode('eight_a1',('b','c','d'),'X**8 - X**3 + X**2*b + X*c + d',(range(1,17),range(1,17),range(201,210)),lambda point:(-1,)+point))
    rows.append(verify_mode('eight_b1',('c','d'),'X**8 + X**2 + X*c + d',(range(1,17),range(201,210)),lambda point:(0,1)+point))
    rows.append(verify_mode('eight_b0',('c','d'),'X**8 + X*c + d',(range(1,17),range(201,210)),lambda point:(0,0)+point))
    require(8**20>7**21,'Center-heptagon versus octagon comparison failed')
    output={'independent_of_author_classification':True,'uses_CAS':False,'uses_floating_point':False,'formula_reconstructions':rows,'exact_samples_total':sum(row['exact_samples'] for row in rows),'scope':'All collision-free physical stationary n8 shapes with e2=e3=e4=0 are center heptagon or regular octagon, up to complex scaling and permutation. This is not unrestricted n8 coverage.','value_comparison':{'center_heptagon':'8^28/7^21','regular_octagon':'8^8','strict_integer_comparison':[8**20,7**21]}}
    (ROOT/'n6_n7_next_eight_verification.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print('Independent n8 sparse-chart verification passed:',json.dumps(output),flush=True)

if __name__=='__main__':run()
