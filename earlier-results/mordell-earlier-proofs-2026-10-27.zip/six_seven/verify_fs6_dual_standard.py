"""Safe exact quotient arithmetic for the archived six-vortex components.

No expressions from the data are executed. AST nodes are parsed as rational
polynomials. This verifier is independent of computer-algebra packages.
"""
import ast
import json
import sys
from fractions import Fraction as Q
from pathlib import Path
sys.setrecursionlimit(10000)
ROOT=Path(__file__).resolve().parent


def sadd(a,b):
    out=dict(a)
    for e,c in b.items(): out[e]=out.get(e,Q(0))+c
    return {e:c for e,c in out.items() if c}


def smul(a,b):
    out={}
    for e,c in a.items():
        for f,d in b.items():
            ef=tuple(x+y for x,y in zip(e,f))
            out[ef]=out.get(ef,Q(0))+c*d
    return {e:c for e,c in out.items() if c}


def parse(node,names):
    zero=(0,)*len(names)
    if isinstance(node,ast.Constant) and isinstance(node.value,int):
        return {zero:Q(node.value)} if node.value else {}
    if isinstance(node,ast.Name):
        if node.id not in names: raise ValueError(node.id)
        e=[0]*len(names); e[names.index(node.id)]=1
        return {tuple(e):Q(1)}
    if isinstance(node,ast.UnaryOp) and isinstance(node.op,ast.USub):
        return {e:-c for e,c in parse(node.operand,names).items()}
    if isinstance(node,ast.BinOp):
        a=parse(node.left,names)
        if isinstance(node.op,ast.Pow):
            if not isinstance(node.right,ast.Constant): raise ValueError('Power')
            k=node.right.value
            if not isinstance(k,int) or k<0 or k>100: raise ValueError(k)
            out={zero:Q(1)}
            for _ in range(k): out=smul(out,a)
            return out
        b=parse(node.right,names)
        if isinstance(node.op,ast.Add): return sadd(a,b)
        if isinstance(node.op,ast.Sub): return sadd(a,{e:-c for e,c in b.items()})
        if isinstance(node.op,ast.Mult): return smul(a,b)
        if isinstance(node.op,ast.Div) and list(b)==[zero]:
            return {e:c/b[zero] for e,c in a.items()}
    raise ValueError(ast.dump(node)[:100])


def trim(a):
    a=list(a)
    while a and not a[-1]: a.pop()
    return a


def pdiv(a,b):
    a=trim(a);b=trim(b)
    if not b: raise ZeroDivisionError()
    out=[Q(0)]*max(0,len(a)-len(b)+1)
    while len(a)>=len(b):
        j=len(a)-len(b);c=a[-1]/b[-1];out[j]=c
        for k,d in enumerate(b):a[j+k]-=c*d
        a=trim(a)
    return trim(out),a


def real_root_count(f):
    f=trim(f)
    seq=[f,trim([i*f[i] for i in range(1,len(f))])]
    while seq[-1]:
        r=pdiv(seq[-2],seq[-1])[1]
        if not r: break
        seq.append([-c for c in r])
    def variations(signs):
        return sum(a!=b for a,b in zip(signs,signs[1:]))
    pos=[1 if a[-1]>0 else -1 for a in seq]
    neg=[v*((-1)**(len(a)-1)) for v,a in zip(pos,seq)]
    return variations(neg)-variations(pos)


def components():
    source=(ROOT/'archivepolsys_vortices_N6.txt').read_text()
    source='\n'.join(line for line in source.splitlines() if not line.startswith('#'))
    tree=ast.parse(source.strip().rstrip(';').replace('^','**'),mode='eval').body
    names=['e2','e3','e4','e5','e6']
    out=[]
    for block in tree.elts[:5]:
        polys=[parse(node,names) for node in block.elts]
        fh=polys[-1]
        if any(any(e[j] for j in (0,2,3,4)) or e[1]%2 for e in fh):
            raise ValueError('Unexpected even eliminant')
        deg=max(e[1]//2 for e in fh)
        F=[Q(0)]*(deg+1)
        for e,c in fh.items():F[e[1]//2]=c
        solved={}
        for j in (2,3,4):
            key=tuple(int(k==j) for k in range(5))
            poly=next(p for p in polys if key in p)
            lead=poly[key]
            rest={e:-c/lead for e,c in poly.items() if e!=key}
            expected_parity=int(j==3)
            if any(any(e[k] for k in (0,2,3,4)) or e[1]%2!=expected_parity for e in rest):
                raise ValueError('Unexpected triangular coefficient')
            vec=[Q(0)]*(1+max((e[1]//2 for e in rest),default=0))
            for e,c in rest.items():vec[e[1]//2]=c
            solved[j]=vec
        out.append((F,solved[2],solved[3],solved[4]))
    return out


class Ring:
    def __init__(self,F,p=None):
        self.p=p
        conv=lambda x:(x.numerator*pow(x.denominator,-1,p))%p if p else Q(x)
        f=[conv(x) for x in F]
        lead=f[-1]
        inv=pow(lead,-1,p) if p else 1/lead
        self.f=[self.scalar(x*inv) for x in f]
        self.d=len(F)-1
        self.zero=[self.scalar(0)]*self.d
        self.one=list(self.zero);self.one[0]=self.scalar(1)
        self.B=list(self.zero)
        if self.d>1:self.B[1]=self.scalar(1)
        else:self.B[0]=self.scalar(-self.f[0])
    def scalar(self,x): return x%self.p if self.p else Q(x)
    def convert(self,x):
        if self.p:return (x.numerator*pow(x.denominator,-1,self.p))%self.p
        return Q(x)
    def reduce(self,a):
        a=list(a)+[self.scalar(0)]*max(0,self.d-len(a))
        for j in range(len(a)-1,self.d-1,-1):
            if a[j]:
                for k in range(self.d):
                    a[j-self.d+k]=self.scalar(a[j-self.d+k]-a[j]*self.f[k])
        return a[:self.d]
    def univ(self,a):return self.reduce([self.convert(x) for x in a])
    def add(self,a,b):return [self.scalar(x+y) for x,y in zip(a,b)]
    def neg(self,a):return [self.scalar(-x) for x in a]
    def mul(self,a,b):
        out=[self.scalar(0)]*(2*self.d-1)
        for i,x in enumerate(a):
            if x:
                for j,y in enumerate(b):
                    if y:out[i+j]=self.scalar(out[i+j]+x*y)
        return self.reduce(out)
    def qadd(self,a,b):return (self.add(a[0],b[0]),self.add(a[1],b[1]))
    def qneg(self,a):return (self.neg(a[0]),self.neg(a[1]))
    def qmul(self,a,b):
        return (self.add(self.mul(a[0],b[0]),self.mul(self.B,self.mul(a[1],b[1]))),
                self.add(self.mul(a[0],b[1]),self.mul(a[1],b[0])))
    def qscale(self,a,c):
        c=self.convert(c)
        return ([self.scalar(c*x) for x in a[0]],[self.scalar(c*x) for x in a[1]])
    def qpow(self,a,k):
        out=(self.one,self.zero)
        for _ in range(k):out=self.qmul(out,a)
        return out


def evaluate_sparse(poly,ring,values):
    powers=[]
    for j,value in enumerate(values):
        degree=max((e[j] for e in poly),default=0)
        arr=[(ring.one,ring.zero)]
        for _ in range(degree):arr.append(ring.qmul(arr[-1],value))
        powers.append(arr)
    out=(ring.zero,ring.zero)
    for e,c in poly.items():
        term=(ring.one,ring.zero)
        for j,k in enumerate(e):
            if k:term=ring.qmul(term,powers[j][k])
        out=ring.qadd(out,ring.qscale(term,c))
    return out


def check(index,branch,data,p=None):
    F,C,K,E=branch
    R=Ring(F,p)
    b=(R.zero,R.one);c=(R.univ(C),R.zero)
    k=(R.univ(K),R.zero);e=(R.univ(E),R.zero);d=R.qmul(b,k)
    values=[b,c,d,e]
    delta=evaluate_sparse(data['delta'],R,values)
    rs={j:evaluate_sparse(data[j],R,values) for j in range(5)}
    r0,r1,r2,r3,r4=(rs[j] for j in range(5))
    B=(R.B,R.zero)
    checks=[R.qadd(R.qmul(delta,R.qpow(r3,2)),R.qneg(R.qmul(B,R.qpow(r4,3)))),
            R.qadd(R.qmul(delta,r2),R.qneg(R.qmul(c,R.qpow(r4,2)))),
            R.qadd(R.qmul(delta,r1),R.qneg(R.qmul(k,R.qmul(r4,r3)))),
            R.qadd(R.qmul(R.qpow(delta,2),r0),R.qneg(R.qmul(e,R.qpow(r4,3))))]
    flags=[not any(a) and not any(b) for a,b in checks]
    print('branch',index,'prime',p,'dual identity flags',flags,flush=True)
    return flags


if __name__=='__main__':
    branches=components()
    source=json.loads((ROOT/'fs6_resultant_data.json').read_text())
    delta=parse(ast.parse(source['delta'],mode='eval').body,['b','c','d','e'])
    raw=parse(ast.parse(source['R0'],mode='eval').body,['b','c','d','e','Y'])
    data={'delta':delta}
    for j in range(5): data[j]={e[:4]:c for e,c in raw.items() if e[4]==j}
    for i,(F,*_) in enumerate(branches):
        print('branch',i,'B degree',len(F)-1,'distinct real roots',real_root_count(F),flush=True)
    exact='--exact' in sys.argv
    for p in ([None] if exact else [1000003,1000033]):
        for i,branch in enumerate(branches): check(i,branch,data,p)
