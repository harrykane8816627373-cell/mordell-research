"""Offline SHA-256 integrity check; all checks remain active under -O."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / 'SHA256_manifest.json').read_text(encoding='utf-8'))
for name, expected in manifest['files'].items():
    relative = Path(name)
    if relative.is_absolute() or '..' in relative.parts:
        raise ArithmeticError('Unsafe manifest file name: ' + name)
    actual = hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()
    if actual != expected:
        raise ArithmeticError('SHA-256 mismatch: ' + name)
print('SHA-256 verification passed:', len(manifest['files']), 'files')
