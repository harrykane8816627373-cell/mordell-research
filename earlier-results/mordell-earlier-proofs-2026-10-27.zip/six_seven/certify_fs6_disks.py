"""Exact complex-disk certificate for the archived six-vortex lex bases.

The published Faugere--Svartz decomposition is the completeness input.
All subsequent root coverage, force exclusions and discriminant bounds use
integer/rational arithmetic. Decimal/NumPy are used only to generate centers.

python certify_fs6_disks.py --generate
python -O certify_fs6_disks.py --verify
"""
import argparse, ast, hashlib, json, math
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'archivepolsys_vortices_N6.txt'
CERT=ROOT/'fs6_disk_certificate.json'
VARS=['e2','e3','e4','e5','e6'];ZERO=(0,)*5
def madd(a,b):
    r=dict(a)
    for m,c in b.items():
        r[m]=r.get(m,F(0))+c
        if not r[m]:del r[m]
    return r
def mmul(a,b):
    r={}
    for m,c in a.items():
        for n,d in b.items():
            k=tuple(x+y for x,y in zip(m,n));r[k]=r.get(k,F(0))+c*d
    return {m:c for m,c in r.items() if c}
def parse(node):
    if isinstance(node,ast.Constant):return {ZERO:F(node.value)}
    if isinstance(node,ast.Name):
        k=list(ZERO);k[VARS.index(node.id)]=1;return {tuple(k):F(1)}
    if isinstance(node,ast.UnaryOp):
        p=parse(node.operand)
        return p if isinstance(node.op,ast.UAdd) else {m:-c for m,c in p.items()}
    if isinstance(node,ast.BinOp):
        a=parse(node.left)
        if isinstance(node.op,ast.Pow):
            k=node.right.value;r={ZERO:F(1)}
            for _ in range(k):r=mmul(r,a)
            return r
        b=parse(node.right)
        if isinstance(node.op,ast.Add):return madd(a,b)
        if isinstance(node.op,ast.Sub):return madd(a,{m:-c for m,c in b.items()})
        if isinstance(node.op,ast.Mult):return mmul(a,b)
        if isinstance(node.op,ast.Div):
            if set(b)!={ZERO}:raise ValueError('Nonconstant division')
            return {m:c/b[ZERO] for m,c in a.items()}
    raise ValueError(ast.dump(node))
def univar(p,j):
    out={}
    for m,c in p.items():
        if any(k for i,k in enumerate(m) if i!=j):raise ValueError('Not univariate')
        out[m[j]]=c
    return out
def components():
    text=''.join(x for x in SOURCE.read_text().splitlines() if not x.startswith('#'))
    tree=ast.parse(text.replace('^','**').rstrip(';'),mode='eval')
    out=[[parse(p) for p in comp.elts] for comp in tree.body.elts]
    if len(out)!=11 or any(len(c)!=5 for c in out):raise ArithmeticError('Author-basis structure mismatch')
    def expected(text):return parse(ast.parse(text,mode='eval').body)
    for idx,ps in enumerate(out,1):
        fixed={0:'e2-1'} if idx<=8 else {0:'e2'}
        if idx==8:fixed.update({2:'e5',3:'e3'})
        elif idx==9:fixed.update({1:'e3-1',2:'e5',3:'e4'})
        elif idx==10:fixed.update({1:'e3',2:'e4',3:'e6',4:'e5-1'})
        elif idx==11:fixed.update({1:'e3',2:'e4',3:'e6-1',4:'e5'})
        for j,text in fixed.items():
            if ps[j]!=expected(text):raise ArithmeticError('Fixed chart polynomial mismatch')
    return out
# A Gaussian rational is a pair (real, imaginary).
Z=(F(0),F(0))
def ga(a,b):return (a[0]+b[0],a[1]+b[1])
def gn(a):return (-a[0],-a[1])
def gs(a,b):return ga(a,gn(b))
def gm(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def scale(a,t):return (a[0]*t,a[1]*t)
def conj(a):return (a[0],-a[1])
def normup(a):return abs(a[0])+abs(a[1])
def normlo(a):return max(abs(a[0]),abs(a[1]))
def normsq(a):return a[0]**2+a[1]**2
def realpoly(p):return {k:(v,F(0)) for k,v in p.items()}
def peval(p,z):
    acc=Z
    for k in range(max(p),-1,-1):acc=ga(gm(acc,z),p.get(k,Z))
    return acc
def deriv(p):return {k-1:scale(v,k) for k,v in p.items() if k}
def taylor(p,z):
    out=[];k=0
    while p:
        out.append(scale(peval(p,z),F(1,math.factorial(k))))
        p=deriv(p);k+=1
    return out
def pack(z):return [str(z[0]),str(z[1])]
def unpack(z):return (F(z[0]),F(z[1]))
def rounded(x,digits=45):
    den=10**digits;return F((x.numerator*den)//x.denominator,den)
def roundg(z):return (rounded(z[0]),rounded(z[1]))
def rouche(p,c,r,uncertainty=None):
    tt=taylor(p,c)
    lhs=normup(tt[0])+sum(normup(v)*r**k for k,v in enumerate(tt) if k>=2)
    if uncertainty:
        lhs+=sum(v*(normup(c)+r)**k for k,v in uncertainty.items())
    rhs=normlo(tt[1])*r
    if not lhs<rhs:raise ArithmeticError('Rouche inequality failed')
    return lhs/rhs
def coefficient_disks(idx,ps,b,rb):
    """Return rounded P coefficients and rigorous coefficient error radii."""
    p={6:(F(1),F(0)),5:Z};err={}
    if idx<=7:
        p[4]=(F(1),F(0));p[3]=gn(b);err[3]=rb
        for j in [2,3,4]:
            f=dict(ps[5-j]);m=list(ZERO);m[j]=1;m=tuple(m);a=f.pop(m)
            f=univar(f,1);v=scale(peval(realpoly(f),b),-1/a)
            q=roundg(v)
            # j=2 -> degree2; j=3 -> degree1; j=4 -> degree0.
            k=4-j
            p[k]=q
            if j==3:p[k]=gn(q)
            upper=normup(b)
            variation=sum(abs(cc)*((upper+rb)**kk-upper**kk) for kk,cc in f.items())/abs(a)
            err[k]=variation+normup(gs(v,q))
    elif idx==8:
        p[4]=(F(1),F(0));p[3]=Z;p[2]=b;p[1]=Z;err[2]=rb
        f=dict(ps[1]);m=list(ZERO);m[4]=1;m=tuple(m);a=f.pop(m);f=univar(f,2)
        v=scale(peval(realpoly(f),b),-1/a);q=roundg(v);p[0]=q
        upper=normup(b)
        err[0]=sum(abs(cc)*((upper+rb)**kk-upper**kk) for kk,cc in f.items())/abs(a)+normup(gs(v,q))
    elif idx==9:
        p.update({4:Z,3:(F(-1),F(0)),2:Z,1:Z,0:b});err[0]=rb
    elif idx==10:p.update({4:Z,3:Z,2:Z,1:(F(-1),F(0)),0:Z})
    elif idx==11:p.update({4:Z,3:Z,2:Z,1:Z,0:(F(1),F(0))})
    return p,err
def parameter_poly(idx,ps):
    if idx<=7:return realpoly(univar(ps[-1],1))
    if idx==8:return realpoly(univar(ps[-1],2))
    if idx==9:return realpoly(univar(ps[-1],4))
    return None
def disjoint(centers,r):
    for i,a in enumerate(centers):
        for b in centers[i+1:]:
            if normlo(gs(a,b))<=2*r:raise ArithmeticError('Disks overlap')
def variation_derivative(p,errors,c,r,order):
    q=p
    ee=dict(errors)
    for _ in range(order):
        q=deriv(q);ee={k-1:k*v for k,v in ee.items() if k}
    tt=taylor(q,c)
    return sum(normup(v)*r**k for k,v in enumerate(tt) if k)+sum(v*(normup(c)+r)**k for k,v in ee.items())
def force_exclusion(p,errors,z,r):
    q0=sum(normsq(c) for c in z)
    eq=sum(2*normup(c)*r+r*r for c in z)
    dp=deriv(p);ddp=deriv(dp)
    for i,c in enumerate(z):
        v1=peval(dp,c);v2=peval(ddp,c)
        res=gs(scale(v2,q0),scale(gm(conj(c),v1),30))
        ev1=variation_derivative(p,errors,c,r,1)
        ev2=variation_derivative(p,errors,c,r,2)
        bound=eq*normup(v2)+(q0+eq)*ev2+30*(r*normup(v1)+(normup(c)+r)*ev1)
        if normlo(res)>bound:return i, normlo(res)/bound
    return None,None
def delta_upper(z,r):
    q0=sum(normsq(c) for c in z)
    eq=sum(2*normup(c)*r+r*r for c in z)
    if q0<=eq:raise ArithmeticError('Nonpositive moment lower bound')
    prod=F(1)
    for i,c in enumerate(z):
        for d in z[:i]:
            cd=gs(c,d)
            prod*=normsq(cd)+4*normup(cd)*r+4*r*r
    return (F(6)/(q0-eq))**15*prod
def generate():
    # This import performs the existing independent numerical screening; none of
    # its floating-point decisions are used by verify().
    import parse_fs6_numerical as numerics
    from decimal import Decimal
    import numpy as np
    records=[];rb=F(1,10**70);rz=F(1,10**12)
    def decimal_center(c,digits):
        return (rounded(F(str(c.r)),digits),rounded(F(str(c.i)),digits))
    for idx,ps in enumerate(components(),1):
        pp=parameter_poly(idx,ps)
        if pp:
            params=numerics.roots({k:v[0] for k,v in pp.items()})
        else:params=[numerics.C()]
        for b in params:
            bc=decimal_center(b,90);p,errors=coefficient_disks(idx,ps,bc,rb)
            pc={k:numerics.C(Decimal(v[0].numerator)/Decimal(v[0].denominator),Decimal(v[1].numerator)/Decimal(v[1].denominator)) for k,v in p.items()}
            def ceval(z):
                acc=numerics.C()
                for k in range(6,-1,-1):acc=acc*z+pc.get(k,numerics.C())
                return acc
            def cderiv(z):
                acc=numerics.C()
                for k in range(6,0,-1):acc=acc*z+pc.get(k,numerics.C())*k
                return acc
            approx=np.roots([complex(float(p.get(k,Z)[0]),float(p.get(k,Z)[1])) for k in range(6,-1,-1)])
            centers=[]
            for t in approx:
                z=numerics.C.z(t)
                for _ in range(40):
                    dz=ceval(z)/cderiv(z);z=z-dz
                    if abs(dz)<Decimal('1e-90'):break
                centers.append(decimal_center(z,45))
            records.append({'component':idx,'parameter_center':pack(bc),'root_centers':[pack(z) for z in centers]})
    data={'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'parameter_radius':str(rb),'root_radius':str(rz),'records':records}
    CERT.write_text(json.dumps(data,indent=2))
    print('Generated',len(records),'parameter/root records',flush=True)
def verify():
    data=json.loads(CERT.read_text());pss=components()
    if data['source_sha256']!=hashlib.sha256(SOURCE.read_bytes()).hexdigest():raise ArithmeticError('Source hash mismatch')
    rb=F(data['parameter_radius']);rz=F(data['root_radius'])
    if rb<=0 or rz<=0:raise ArithmeticError('Nonpositive disk radius')
    records=data['records'];results=[];C6=F(6**15,5**10)
    for idx,ps in enumerate(pss,1):
        rr=[row for row in records if row['component']==idx]
        pp=parameter_poly(idx,ps)
        if len(rr)!=(max(pp) if pp else 1):raise ArithmeticError('Root count mismatch')
        bc=[unpack(row['parameter_center']) for row in rr]
        if pp:
            disjoint(bc,rb)
            for b in bc:rouche(pp,b,rb)
        for row,b in zip(rr,bc):
            p,errors=coefficient_disks(idx,ps,b,rb)
            z=[unpack(c) for c in row['root_centers']]
            if len(z)!=6:raise ArithmeticError('Six roots required')
            disjoint(z,rz)
            for c in z:rouche(p,c,rz,errors)
            excluded,ratio=force_exclusion(p,errors,z,rz)
            if excluded is not None:
                result={'component':idx,'status':'excluded_by_force','root':excluded,'exclusion_margin_ratio_lower_integer':ratio.numerator//ratio.denominator}
            elif idx==10:
                if p!={6:(F(1),F(0)),5:Z,4:Z,3:Z,2:Z,1:(F(-1),F(0)),0:Z}:raise ArithmeticError('Central-pentagon polynomial mismatch')
                result={'component':idx,'status':'exact_central_pentagon','delta':str(C6)}
            elif idx==11:
                if p!={6:(F(1),F(0)),5:Z,4:Z,3:Z,2:Z,1:Z,0:(F(1),F(0))}:raise ArithmeticError('Regular-hexagon polynomial mismatch')
                if not F(6**6)<C6:raise ArithmeticError('Hexagon comparison failed')
                result={'component':idx,'status':'strictly_below_C6','exact_delta':str(6**6),'integer_upper':6**6}
            else:
                upper=delta_upper(z,rz)
                if not upper<C6:raise ArithmeticError('Candidate exceeds target bound')
                integer_upper=-((-upper.numerator)//upper.denominator)
                if not F(integer_upper)<C6:raise ArithmeticError('Integer presentation bound exceeds C6')
                result={'component':idx,'status':'strictly_below_C6','rational_upper':str(upper),'integer_upper':integer_upper}
            results.append(result)
        print('Certified component',idx,'roots',len(rr),flush=True)
    if len(records)!=80:raise ArithmeticError('Expected 80 author-basis solutions')
    if any(row['component'] not in range(1,12) for row in records):raise ArithmeticError('Unexpected component')
    output={'source_sha256':data['source_sha256'],'certificate_sha256':hashlib.sha256(CERT.read_bytes()).hexdigest(),
            'algebraic_solutions':80,'force_excluded':sum(r['status']=='excluded_by_force' for r in results),
            'below_target':sum(r['status']=='strictly_below_C6' for r in results),'central_pentagon':sum(r['status']=='exact_central_pentagon' for r in results),
            'M6':str(C6),'results':results}
    (ROOT/'fs6_disk_verification_result.json').write_text(json.dumps(output,indent=2))
    print('EXACT verification passed:',{k:v for k,v in output.items() if k!='results'},flush=True)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--generate',action='store_true');parser.add_argument('--verify',action='store_true');args=parser.parse_args()
    if args.generate:generate()
    if args.verify or not args.generate:verify()
