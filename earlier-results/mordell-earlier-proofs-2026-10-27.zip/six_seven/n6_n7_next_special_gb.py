"""Bounded independent saturated Groebner computation for the e3=1 chart."""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'cas_runtime'))
import sympy as s
c,d,e,h=s.symbols('c d e h')
mode=sys.argv[1]
j=json.loads((HERE/('n6_n7_next_'+mode+'_equations.json')).read_text())
E=[s.sympify(q) for q in j['E']]
D=s.sympify(j['delta'])
start=time.monotonic()
print('start saturated grevlex',mode,flush=True)
G=s.groebner(E+[h*D-1],h,c,d,e,order='grevlex',method='f5b')
print('grevlex done',len(G.polys),'zero dimensional',G.is_zero_dimensional,'elapsed',time.monotonic()-start,flush=True)
if G.is_zero_dimensional:
    G=G.fglm(order='lex')
    print('lex done',time.monotonic()-start,flush=True)
out={'mode':mode,'order':G.order.alias,'variables':['h','c','d','e'],'G':[str(q) for q in G]}
(HERE/('n6_n7_next_'+mode+'_gb.json')).write_text(json.dumps(out,indent=2)+'\n')
for q in G:print(s.factor(q),flush=True)
