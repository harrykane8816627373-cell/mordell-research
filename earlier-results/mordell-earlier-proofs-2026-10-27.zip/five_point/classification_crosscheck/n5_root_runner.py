"""Rerun the user-supplied local n5 verification with assertions enabled.

No network code is fetched or executed. This wrapper also exports every
Groebner input/basis used by the supplied script for a separate audit.
Run with bundled Python -B -S, WITHOUT -O.
"""
from pathlib import Path
import contextlib
import hashlib
import json
import runpy
import sys
import time

if not __debug__:
    raise RuntimeError('This run requires enabled assertions; remove -O.')

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'cas_runtime'))
import sympy as sp

SOURCE=ROOT/'source'/'anc'/'n5_complete_verification.py'
if not SOURCE.is_file():
    SOURCE=ROOT/'n5_complete_verification.py'
LOG=ROOT/'n5_complete_reverification.log'
DATA=ROOT/'n5_recomputed_algebra.json'
records=[]
original_groebner=sp.groebner


def encode(poly,gens):
    return [[list(a),str(c)] for a,c in sp.Poly(poly,*gens,domain=sp.QQ).terms()]


def recording_groebner(polynomials,*gens,**kwargs):
    values=list(polynomials)
    result=original_groebner(values,*gens,**kwargs)
    records.append({'variables':[str(g) for g in gens],
                    'order':str(kwargs.get('order','lex')),
                    'inputs':[encode(f,gens) for f in values],
                    'basis':[encode(p.as_expr(),gens) for p in result.polys]})
    return result


sp.groebner=recording_groebner
started=time.monotonic()
try:
    with LOG.open('w',encoding='utf-8') as stream,contextlib.redirect_stdout(stream):
        print('Source SHA256:',hashlib.sha256(SOURCE.read_bytes()).hexdigest())
        print('Assertions active:',__debug__)
        runpy.run_path(str(SOURCE),run_name='__main__')
finally:
    sp.groebner=original_groebner

DATA.write_text(json.dumps({'source':str(SOURCE),
                          'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
                          'sympy_version':sp.__version__,
                          'assertions_active':True,
                          'groebner_computations':records},indent=2),encoding='utf-8')
print(f'PASS: full supplied n5 classification rerun in {time.monotonic()-started:.3f}s')
print(f'Log: {LOG}')
print(f'Algebra export: {DATA}; {len(records)} exact Groebner computations')
