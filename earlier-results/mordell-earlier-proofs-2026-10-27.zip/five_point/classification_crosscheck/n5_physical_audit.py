"""Independent rational physical-branch certificate for the n5 reconstruction.

Coverage is supplied by the separate full local n5_root_runner.py rerun,
not by this smaller script. Here all root counts, physical signs, classical
discriminants, and strict comparisons use standard-library rational code.
This file does NOT certify the reverse ideal inclusions of the Groebner step.
Run under Python -S -O; no external module or floating decision is used.
"""
from fractions import Fraction as F
from pathlib import Path
import json

checks = 0


def require(condition, reason):
    global checks
    if not condition:
        raise ArithmeticError(reason)
    checks += 1


def trim(p):
    p = [F(c) for c in p]
    while p and not p[-1]:
        p.pop()
    return p


def add(p, q):
    return trim([(p[i] if i < len(p) else 0) + (q[i] if i < len(q) else 0)
                 for i in range(max(len(p), len(q)))])


def scale(p, c):
    return trim([F(c) * v for v in p])


def mul(p, q):
    out = [F(0)] * max(0, len(p) + len(q) - 1)
    for i, a in enumerate(p):
        for j, b in enumerate(q):
            out[i + j] += a * b
    return trim(out)


def powpoly(p, k):
    result = [F(1)]
    for _ in range(k):
        result = mul(result, p)
    return result


def divmodpoly(p, q):
    p, q = trim(p), trim(q)
    if not q:
        raise ZeroDivisionError("polynomial division by zero")
    quotient = [F(0)] * max(0, len(p) - len(q) + 1)
    while p and len(p) >= len(q):
        shift = len(p) - len(q)
        ratio = p[-1] / q[-1]
        quotient[shift] += ratio
        p = add(p, [F(0)] * shift + scale(q, -ratio))
    return trim(quotient), p


def mod(p, q):
    return divmodpoly(p, q)[1]


def inverse(p, modulus):
    a, b = trim(modulus), mod(p, modulus)
    s, t = [], [F(1)]
    while b:
        quotient, remainder = divmodpoly(a, b)
        a, b = b, remainder
        s, t = t, add(s, scale(mul(quotient, t), -1))
    require(len(a) == 1, "Noninvertible quotient-ring denominator")
    answer = mod(scale(s, 1 / a[0]), modulus)
    require(mod(mul(answer, p), modulus) == [F(1)], "Inverse verification")
    return answer


def derivative(p):
    return trim([i * p[i] for i in range(1, len(p))])


def evalpoly(p, x):
    result = F(0)
    for c in reversed(p):
        result = result * x + c
    return result


def sign(x):
    return (x > 0) - (x < 0)


def sturm(p):
    seq = [trim(p), derivative(p)]
    while seq[-1]:
        remainder = scale(mod(seq[-2], seq[-1]), -1)
        if not remainder:
            break
        seq.append(remainder)
    require(len(seq[-1]) == 1, "Sturm polynomial must be square-free")
    return seq


def variations(seq, x):
    if x in ("-inf", "+inf"):
        signs = [sign(p[-1]) * (-1 if x == "-inf" and (len(p) - 1) % 2 else 1) for p in seq]
    else:
        signs = [sign(evalpoly(p, x)) for p in seq]
    signs = [s for s in signs if s]
    return sum(a != b for a, b in zip(signs, signs[1:]))


def root_count(seq, left, right):
    return variations(seq, left) - variations(seq, right)


def interval_mul(a, b):
    products = [x * y for x in a for y in b]
    return min(products), max(products)


def horner(p, interval):
    value = (F(0), F(0))
    for c in reversed(p):
        value = interval_mul(value, interval)
        value = value[0] + c, value[1] + c
    return value


def determinant(matrix):
    """Fraction Bareiss determinant, independent of any SymPy routine."""
    A=[list(map(F,row)) for row in matrix]
    n=len(A)
    previous=F(1)
    sign=1
    for k in range(n-1):
        if not A[k][k]:
            pivot=next((i for i in range(k+1,n) if A[i][k]),None)
            if pivot is None:
                return F(0)
            A[k],A[pivot]=A[pivot],A[k]
            sign=-sign
        pivot=A[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                A[i][j]=(A[i][j]*pivot-A[i][k]*A[k][j])/previous
        for i in range(k+1,n):
            A[i][k]=F(0)
        previous=pivot
    return sign*A[-1][-1]


def resultant(p,q):
    p,q=trim(p),trim(q)
    d,e=len(p)-1,len(q)-1
    matrix=[]
    for i in range(e):
        matrix.append([F(0)]*i+list(reversed(p))+[F(0)]*(e-1-i))
    for i in range(d):
        matrix.append([F(0)]*i+list(reversed(q))+[F(0)]*(d-1-i))
    return determinant(matrix)


def discriminant(p):
    p=trim(p)
    degree=len(p)-1
    return (-1)**(degree*(degree-1)//2)*resultant(p,derivative(p))/p[-1]


H, one = [F(0), F(1)], [F(1)]
Q = trim([6, -97, 140, -65, 10])
J = scale([975, -2430, 1775, -350], F(1, 92))
D = scale([-12854393, 32980990, -30197665, 7632290], -F(84375, 385875968))
Jinv = inverse(J, Q)

# Rebuild the discriminant factors with quotient arithmetic, rather than
# trusting the precomputed cubic D(H).
Hm1 = add(H, [-1])
Z = mul(mul(H, powpoly(Hm1, 2)), Jinv)
Dpair = scale(add(powpoly(add(add(scale(H, 5), J), [-20]), 2),
                   add(scale(mul(H, J), -4),
                       add(scale(mul(H, Hm1), 80), scale(Z, -400)))), F(1, 16))
AtH = scale(add(scale(powpoly(add(H, one), 2), 25),
               add(scale(mul(H, J), -4),
                   add(scale(mul(H, Hm1), -20), scale(Z, -25)))), F(1, 16))
Rpair = scale(add(scale(Z, 25),
                 add(scale(mul(H, Hm1), -5), mul(J, add([5], scale(H, -1))))), F(1, 4))
A, B, C = [mod(p, Q) for p in (Dpair, AtH, Rpair)]
require(mod(add(mul(mul(A, powpoly(B, 2)), powpoly(C, 2)), scale(D, -1)), Q) == [],
        "Discriminant factor certificate")

sequence = sturm(Q)
require(root_count(sequence, "-inf", "+inf") == 2, "Q has exactly two real roots")
intervals = [(F(68395128919, 10 ** 12), F(68395128920, 10 ** 12)),
             (F(1214112777579, 10 ** 12), F(1214112777580, 10 ** 12))]
rows = []
for I, coarse in zip(intervals, ((2347, 2348), (801, 802))):
    require(root_count(sequence, *I) == 1, "Q root isolation")
    require(horner(J, I)[0] > 0, "Physical squared pair-asymmetry positive")
    require(horner(scale(add(add(scale(H, 5), J), [-20]), F(1, 2)), I)[1] < 0,
            "Sum of quadratic discriminants negative")
    for factor in (A, B, C):
        require(horner(factor, I)[0] > 0, "Noncollision discriminant factor positive")
    lo, hi = horner(D, I)
    require(F(coarse[0]) < lo <= hi < F(coarse[1]) < 3125, "Strict global value comparison")
    rows.append({"H_interval": [str(v) for v in I], "discriminant_interval": [str(lo), str(hi)]})

Q32 = trim([-9, -37, 115, -55, 10])
V32 = scale([211, -1074, 625, -130], F(1, 304))
sequence32 = sturm(Q32)
I32 = F(607600, 10 ** 6), F(607601, 10 ** 6)
require(root_count(sequence32, F(0), "+inf") == 1, "Only one positive Q32 root")
require(root_count(sequence32, *I32) == 1, "Q32 positive root isolation")
require(horner(V32, I32)[1] < 0, "Three-real nonzero branch cannot have a nonreal conjugate pair")
require(F(5 ** 10, 2 ** 12) < 3125 and F(84375, 1024) < 3125, "Classical competitors smaller")

classical={
    'pentagon':([-1,0,0,0,0,1],F(3125)),
    'square_and_center':([0,-F(25,16),0,0,0,1],F(5**10,2**12)),
    'collinear':([0,F(15,16),0,-F(5,2),0,1],F(84375,1024)),
}
for name,(p,value) in classical.items():
    require(abs(discriminant(p))==value,f'Independent Sylvester discriminant: {name}')
collinear=classical['collinear'][0]
require(add(add(derivative(derivative(collinear)),scale(mul(H,derivative(collinear)),-4)),
            scale(collinear,20))==[], 'Unique monic degree-five Hermite equation')

result = {"status": "passed", "exact_checks": checks, "M5_after_reconstructed_coverage": 3125,
          "nonclassical_value_intervals": rows,
          "dependency": "Full local n5_root_runner.py reconstruction proves coverage; this independent checker proves the subsequent physical root filtering and exact values, not the Groebner ideal coverage.",
          "arithmetic": "standard-library Fraction only; -S -O compatible"}
Path(__file__).with_name("n5_physical_audit_result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: v for k, v in result.items() if k != "nonclassical_value_intervals"}, indent=2))
