"""Replay the focused earlier Mordell proofs using the standard library."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tempfile,time
BASE=Path(__file__).resolve().parent
JOBS=[
 ('five_point/verify_mordell.py',[]),
 ('five_point/algebra_identity_check.py',[]),
 ('five_point/generalization_check.py',[]),
 ('six_seven/verify_manifest.py',[]),
 ('six_seven/certify_fs6_disks.py',['--verify']),
 ('six_seven/certify_fs7_disks.py',['--verify']),
 ('six_seven/verify_fs6_components_exact.py',[]),
 ('general_n/audited_supplement/exact_check.py',[]),
 ('general_n/structural_and_algebraic/structural_verify.py',[]),
 ('general_n/structural_and_algebraic/algebraic_verify.py',[]),
]
def main():
 if sys.flags.optimize:raise RuntimeError('Run without -O so assertions remain enabled')
 manifest=json.loads((BASE/'source_manifest.json').read_text(encoding='utf8'))
 for item in manifest['files']:
  p=(BASE/item['path']).resolve()
  if not p.is_relative_to(BASE):raise ValueError('Unsafe manifest path')
  if hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:raise ArithmeticError('Source hash mismatch: '+item['path'])
 report={'status':'RUNNING','date':'2026-10-27','jobs':[],'full_eight_point_bound_proved':False,
         'six_seven_coverage':'Uses the explicitly cited published Faugere-Svartz classification; does not independently reconstruct all chart coverage.'}
 result=BASE/'verification/replay.json';result.parent.mkdir(exist_ok=True)
 def save():result.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 save();start=time.monotonic()
 try:
  workbase=(BASE/'.verification-work').resolve();workbase.mkdir(exist_ok=True)
  with tempfile.TemporaryDirectory(prefix='mordell-earlier-',dir=workbase) as d:
   if not Path(d).resolve().is_relative_to(workbase):raise ValueError('Unsafe temporary target')
   work=Path(d)/'proofs';shutil.copytree(BASE,work,ignore=shutil.ignore_patterns('verification','.verification-work','__pycache__'))
   for name,args in JOBS:
    print('RUN '+name,flush=True);tick=time.monotonic()
    env=os.environ.copy();env.pop('PYTHONOPTIMIZE',None);env['PYTHONIOENCODING']='utf8'
    p=work/name;r=subprocess.run([sys.executable,'-B','-S',str(p)]+args,cwd=p.parent,env=env,capture_output=True,text=True,encoding='utf8',errors='replace')
    row={'script':name,'args':args,'status':'PASS' if r.returncode==0 else 'FAIL','returncode':r.returncode,'seconds':round(time.monotonic()-tick,3)}
    report['jobs'].append(row);save()
    if r.returncode:
     print((r.stdout+'\n'+r.stderr)[-5000:],flush=True)
     raise RuntimeError('Acceptance failed: '+name)
    print('PASS '+name,flush=True)
  report['status']='PASS';report['seconds']=round(time.monotonic()-start,3);save()
  print(json.dumps({'status':'PASS','jobs':len(report['jobs']),'seconds':report['seconds']}),flush=True)
 except Exception as e:
  report['status']='FAIL';report['error']=str(e);save();raise
if __name__=='__main__':main()
