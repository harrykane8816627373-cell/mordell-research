"""Small exact checks for algebraic_fixed_moment.md.

This checks the coefficient moment normalization and the elementary
resultant/separation and fixed-K inequalities on small examples. It does
not execute the prohibitive universal polynomial enumeration or moment
index in the general-n theorem, and does not re-prove the cited JPT bound.
Only Python's standard library is used.
Checks raise explicit exceptions and remain active under python -O.
"""
from fractions import Fraction
from itertools import permutations
from math import comb, factorial, ceil


def require(condition, message):
    """A verification condition that Python optimization cannot remove."""
    if not condition:
        raise RuntimeError(message)


def check_verification_guard():
    try:
        require(False, 'Intentional failure to check the verification guard')
    except RuntimeError:
        print('PASS: explicit verification guard remains active')
        return
    raise RuntimeError('Verification guard failed to reject a false condition')


def padd(a, b):
    out = [0] * max(len(a), len(b))
    for i, c in enumerate(a):
        out[i] += c
    for i, c in enumerate(b):
        out[i] += c
    while len(out) > 1 and out[-1] == 0:
        out.pop()
    return out


def pmul(a, b):
    out = [0] * (len(a) + len(b) - 1)
    for i, c in enumerate(a):
        for j, e in enumerate(b):
            out[i + j] += c * e
    while len(out) > 1 and out[-1] == 0:
        out.pop()
    return out


def resultant_shift(f, g):
    """Exact Res_t(f(t),g(t+u)); polynomials stored low coefficient first."""
    d, e = len(f) - 1, len(g) - 1
    size = d + e
    fhigh = [[c] for c in reversed(f)]
    ghigh = []
    for tpower in reversed(range(e + 1)):
        ghigh.append([g[tpower + upower] * comb(tpower + upower, tpower)
                      for upower in range(e - tpower + 1)])
    matrix = []
    for offset in range(e):
        matrix.append([[0]] * offset + fhigh + [[0]] * (e - 1 - offset))
    for offset in range(d):
        matrix.append([[0]] * offset + ghigh + [[0]] * (d - 1 - offset))
    answer = [0]
    for perm in permutations(range(size)):
        inversions = sum(perm[i] > perm[j]
                         for i in range(size) for j in range(i + 1, size))
        term = [(-1) ** inversions]
        for row, col in enumerate(perm):
            term = pmul(term, matrix[row][col])
        answer = padd(answer, term)
    return answer


def vandermonde(n):
    polynomial = {(0,) * n: 1}
    for i in range(n):
        for j in range(i + 1, n):
            result = {}
            for exponents, coefficient in polynomial.items():
                for variable, sign in ((i, 1), (j, -1)):
                    key = list(exponents)
                    key[variable] += 1
                    key = tuple(key)
                    result[key] = result.get(key, 0) + sign * coefficient
            polynomial = {a: c for a, c in result.items() if c}
    return polynomial


def multivariate_product(p, q):
    out = {}
    for alpha, c in p.items():
        for beta, e in q.items():
            key = tuple(a + b for a, b in zip(alpha, beta))
            out[key] = out.get(key, 0) + c * e
    return {a: c for a, c in out.items() if c}


def check_moments():
    for n, maximum in ((2, 4), (3, 27)):
        N = n * (n - 1) // 2
        v = vandermonde(n)
        power = {(0,) * n: 1}
        previous_A = Fraction(1)
        previous_ratio = Fraction(0)
        for k in range(1, 7):
            power = multivariate_product(power, v)
            C = sum(c * c * factorial(alpha[0]) * factorial(alpha[1]) *
                    (factorial(alpha[2]) if n == 3 else 1)
                    for alpha, c in power.items())
            A = Fraction(n ** (k * N) * factorial(n - 2) * C,
                         factorial(k * N + n - 2))
            E = comb(k * N + n - 2, n - 2)
            require(A <= maximum ** k <= E * A,
                    f'Moment enclosure failed for n={n}, k={k}')
            ratio = A / previous_A
            require(previous_ratio <= ratio <= maximum,
                    f'Moment-ratio monotonicity or upper bound failed for n={n}, k={k}')
            if n == 2:
                require(A == 4 ** k == E * A,
                        f'Two-point exact moment identity failed for k={k}')
            previous_A, previous_ratio = A, ratio
    print('PASS: exact moments for n = 2, 3, k = 1,...,6')


def check_resultants():
    cases = [([-1, 1], [-4, 1]), ([-1, 0, 1], [-1, 0, 1]),
             ([1, -2, 1], [-1, 2, -1]), ([2, 0, -1, 1], [1, 1, 0, 1])]
    for f, g in cases:
        D = max(len(f), len(g)) - 1
        H = max(map(abs, f + g))
        R = resultant_shift(f, g)
        require(any(R), f'Translation resultant vanished identically for f={f}, g={g}')
        B = factorial(2 * D) * ((D + 1) * H * 2 ** D) ** (2 * D)
        require(sum(map(abs, R)) <= B,
                f'Resultant coefficient norm exceeded its bound for f={f}, g={g}')
        require(len(R) - 1 <= (len(f) - 1) * (len(g) - 1),
                f'Resultant degree exceeded its bound for f={f}, g={g}')
    require(resultant_shift([-1, 1], [-4, 1]) == [-3, 1],
            'Linear translation resultant identity failed')
    require(resultant_shift([-1, 0, 1], [-1, 0, 1]) == [0, 0, -4, 0, 1],
            'Repeated-root/zero-factor translation resultant identity failed')
    print('PASS: exact Sylvester resultants, including repeated roots and zero factors')


def check_fixed_K():
    # Toy constants exercise the exact same general inequality while the
    # actual n-only worst-case K is deliberately not instantiated.
    for N, m, U, delta in [(1, 1, Fraction(1), Fraction(1, 2)),
                            (3, 1, Fraction(2), Fraction(1, 2)),
                            (2, 2, Fraction(1), Fraction(1, 3))]:
        L = m * (N + m + 1)
        K = ceil(4 * U * L / delta) ** 2
        E = comb(K * N + m, m)
        ratio_bound = 1 + delta / (2 * U)
        # E**(1/K) <= ratio_bound, verified with integer arithmetic.
        require(E * ratio_bound.denominator ** K <= ratio_bound.numerator ** K,
                f'Fixed-K endpoint-ratio bound failed for N={N}, m={m}, U={U}, delta={delta}')
        require(Fraction(L, ceil(4 * U * L / delta)) <= delta / (4 * U),
                f'Fixed-K ceiling bound failed for N={N}, m={m}, U={U}, delta={delta}')
    print('PASS: prescribed K inequality by exact integer comparisons on toy constants')


def check_JPT_constants():
    for n in range(2, 25):
        N = n * (n - 1) // 2
        r, d = 2 * n, 2 * N
        h = max(8 ** N, 4 * n + 2)
        D = r * d * (d - 1) ** (r - 1)
        require(d >= 2 and d % 2 == 0 and n <= 8 ** N,
                f'JPT degree/parity/input-height conditions failed for n={n}')
        require(h >= 2 * r + 2 and h >= 8 ** N,
                f'JPT augmented-height substitution failed for n={n}')
        for s in (0, 1):
            require(comb(r, s) * d ** s * (d - 1) ** (r - s) <= D,
                    f'JPT active-constraint degree bound failed for n={n}, s={s}')
        # The coarse integer base 16 replaces the cited 2**(4-r/2).
        require(Fraction(2) ** (4 - n) <= 16,
                f'JPT integer-base enlargement failed for n={n}')
        # The enormous height is kept as a base/exponent pair.
        height_base = 16 * h * d ** r
        height_exponent = r * 2 ** r * d ** r
        require(height_base >= 1 and height_exponent >= 1,
                f'JPT height base/exponent positivity failed for n={n}')
        require((n - 2) * (N + n - 1) == (n - 2) * (N + (n - 2) + 1),
                f'Fixed-K L substitution identity failed for n={n}')
    print('PASS: JPT substitution and degree/base/exponent identities for n = 2,...,24')


if __name__ == '__main__':
    check_verification_guard()
    check_moments()
    check_resultants()
    check_fixed_K()
    check_JPT_constants()
    print('All small exact checks passed; universal general-n enumeration was not executed.')
