"""Exact rational audit for new Mordell subset constraints.

The analytic maximum-principle and Schwarz-Pick arguments are in
structural_findings.md. This program checks the decisive rational constant
certificate and the displayed algebraic identities using standard library only.
No floating-point comparison or assertion statement is used.
"""
from fractions import Fraction as F
from math import comb, isqrt


def check(condition, message):
    if not condition:
        raise ArithmeticError(message)


def exact_constant_certificate():
    n, d = 6, 5
    rho = F(d*d, n)
    terms = [F(comb(d,k)**2)*rho**k for k in range(n)]
    total = sum(terms, F(0))
    largest = max(terms)
    mu = F(2**d, n)/total
    moment = F(n*d, 2)
    aux_bound = moment*n*largest/F(2**d)
    check(rho == F(25, 6), 'six-point radius squared')
    check(total == F(138927151, 7776), 'six-point coefficient norm sum')
    check(mu == F(41472, 138927151), 'six-point Hermitian margin')
    check(mu > F(1,3350), 'six-point simplified Hermitian margin')
    check(aux_bound == F(48828125,2304), 'six-point auxiliary bound')
    check(aux_bound < 21193, 'six-point integer auxiliary bound')
    # Exact scalar conversion for the new triple constraint.
    for n in range(4,101):
        lam = F(n-1,2)
        triple_q = F(6,n-1)
        check(lam*triple_q == 3, 'force-one triple internal moment')
        check(3*triple_q == F(18,n-1), 'triple distance sum')
    # All-n force-one eta=2 dominates both former closed rational cuts.
    for n in range(3,1001):
        check(2 > max(F(n,n-1),F(16,11)), 'stronger rational separation')
        old_radius = F(n-1)
        new_radius = F((n-1)**2,n)
        check(new_radius < old_radius, 'strictly smaller radius squared')
        # The integer radius ceil is unchanged, despite the radius improvement.
        a_old = isqrt(n-1)
        if a_old*a_old < n-1:
            a_old += 1
        check(F((a_old-1)**2) < new_radius <= F(a_old*a_old),
              'unchanged integer radius ceil')


def add_square(matrix, vector, scale=F(1)):
    for j, a in enumerate(vector):
        for k, b in enumerate(vector):
            matrix[j][k] += scale*a*b


def audit_block_moment_identity(n, m):
    """Compare formal quadratic forms after eliminating block means.

    Independent real variables are m-1 internal S coordinates, n-m-1
    internal T coordinates, and q. Identical real and imaginary formulas
    prove the complex norm identity. The check below is formal coefficient
    arithmetic, not a sample of numerical point configurations.
    """
    d = n-1
    y = []
    for j in range(m-1):
        vector = [F(0)]*d
        vector[j] = F(1)
        y.append(vector)
    y.append([F(-1) if j<m-1 else F(0) for j in range(d)])
    v = []
    for j in range(n-m-1):
        vector = [F(0)]*d
        vector[m-1+j] = F(1)
        v.append(vector)
    v.append([F(-1) if m-1<=j<n-2 else F(0) for j in range(d)])
    lhs = [[F(0)]*d for _ in range(d)]
    rhs = [[F(0)]*d for _ in range(d)]
    for vector in y:
        shifted = list(vector)
        shifted[-1] += F(n-m, n)
        add_square(lhs, shifted)
        add_square(rhs, vector)
    for vector in v:
        shifted = list(vector)
        shifted[-1] -= F(m, n)
        add_square(lhs, shifted)
        add_square(rhs, vector)
    rhs[-1][-1] += F(m*(n-m), n)
    check(lhs == rhs, f'formal block moment identity n={n},m={m}')
    spread_sum = F(m*(m-1)+(n-m)*(n-m-1),n-1)
    check(n-spread_sum == F(2*m*(n-m),n-1),
          'complementary subset-spread deficit')
    check((n-spread_sum)*F(m*(n-m),n) ==
          F(2*m*m*(n-m)**2,n*(n-1)),
          'centroid cut from complementary subset moments')
    q_centroid = F(m*(n-m), n)
    radius_bound = F(2*n, n-1)
    check(q_centroid**2*radius_bound == F(2*m*m*(n-m)**2, n*(n-1)),
          'subset centroid conversion')
    if m == 1:
        check(q_centroid**2*radius_bound == F(2*(n-1), n),
              'one-point radius conversion')


def audit_projection_identity(n):
    # Squared reference values use c^2=2/[n(n-1)].
    ref_square_sum = F(2, n*(n-1))*sum((n+1-2*i)**2 for i in range(1,n+1))
    check(ref_square_sum == F(2*(n+1), 3), 'projection second moment')
    for m in range(1, n):
        check(sum(n+1-2*i for i in range(1,m+1)) == m*(n-m),
              'projection partial sum')
    check(2*F(2*(n+1),3)-n == F(n+4,3), 'holomorphic moment conversion')


def main():
    exact_constant_certificate()
    count = 0
    for n in range(2, 17):
        audit_projection_identity(n)
        for m in range(1, n):
            audit_block_moment_identity(n, m)
            count += 1
    print('PASS: exact trace constants, eta=2, triple Q_S > 6/(n-1).')
    print(f'PASS: {count} formal block quadratic identities (2 <= n <= 16).')
    print('PASS: projection sums, covariance conversion, sharper radius factors.')
    print('Analytic strictness and general-n proofs remain the written mathematical arguments.')


if __name__ == '__main__':
    main()
