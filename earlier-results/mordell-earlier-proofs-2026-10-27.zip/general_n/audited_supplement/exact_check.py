"""Independent standard-library checks for the supplied general-n supplement.

The checks below certify finite algebraic statements only.  The audit.md file
contains the arguments establishing the quantified analytic statements.
No source attachment commands or suggested integration operations are run.
"""
from fractions import Fraction as F
from pathlib import Path
from math import factorial, gcd
import hashlib
import json
import zipfile

BASE = Path(__file__).resolve().parent


def require(test, message):
    if not test:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def add(a, b):
    out = dict(a)
    for k, v in b.items():
        out[k] = out.get(k, F(0)) + v
        if out[k] == 0:
            del out[k]
    return out


def mul(a, b):
    out = {}
    for ka, va in a.items():
        for kb, vb in b.items():
            k = ka + kb
            out[k] = out.get(k, F(0)) + va * vb
    return {k: v for k, v in out.items() if v}


def derivative(a):
    return {k - 1: k * v for k, v in a.items() if k}


def truncated_exponential(m):
    return {k: F(1, factorial(k)) for k in range(m + 1)}


def exact_checks():
    checks = 0
    for m in range(1, 101):
        s = truncated_exponential(m)
        sp = derivative(s)
        spp = derivative(sp)
        left = add(mul(sp, sp), {k: -v for k, v in mul(s, spp).items()})
        # (S'_m)^2-S_m S''_m =
        # x^(m-1)/m! sum_{k=0}^{m-1}(m-k)x^k/k!
        right = {m - 1 + k: F(m - k, factorial(m) * factorial(k))
                 for k in range(m)}
        require(left == right, "truncated-exponential concavity identity")
        require(all(v > 0 for v in right.values()), "positive concavity coefficients")
        checks += 2

    n = 2
    N = n * (n - 1) // 2
    Pn = 1
    low = F(factorial(n) * factorial(n - 2) * n**N * Pn,
            factorial(N + n - 2))
    upper_alpha_1 = F(Pn * 2**n)
    require(low == upper_alpha_1 == 4, "n=2 exact finite-bound benchmark")
    checks += 1

    u, v = F(1, 8), F(39, 32)
    n, N = 10, 45
    require(2*u + 8*v == n, "n10 squared-radius normalization")
    D10 = 4*u * 8**8 * v**28 * (u**4 + v**4)**4
    C10 = F(10**45, 9**36)
    ratio = D10/C10
    require(ratio > F(113, 100), "n10 strict 113/100 counterexample")
    require(ratio > 1, "n10 improvement on central polygon")
    checks += 3

    # The two-ring equation is checked as an exact polynomial identity after
    # x=s^2.  This includes odd L, where x^(L/2) itself is not a polynomial.
    for a in range(2, 21):
        for b in range(2, 21):
            g = gcd(a, b)
            L = a*b//g
            for delta in (0, 1):
                A = a*(a-1)//2 + delta*a
                B = b*(b-1)//2 + delta*b
                N = A+B+a*b
                n = a+b+delta
                require(N == n*(n-1)//2, "two-ring homogeneous degree")
                # Multiply the logarithmic derivative by
                # (a x+b)(1+x^(L/2)), then divide by the harmless x^-1.
                left = {}
                for deg, coef in ((0,A*b), (2,A*a-N*a),
                                  (L,(A+g*L)*b), (L+2,(A+g*L-N)*a)):
                    left[deg] = left.get(deg,F(0)) + coef
                right = {}
                for deg, coef in ((0,A*b), (2,-a*(B+a*b)),
                                  (L,b*(A+a*b)), (L+2,-a*B)):
                    right[deg] = right.get(deg,F(0)) + coef
                left = {k:v for k,v in left.items() if v}
                right = {k:v for k,v in right.items() if v}
                require(left == right, "two-ring critical equation")
                checks += 2

    spectra = []
    for m in range(4, 501):
        # Root-of-unity sum recurrence: C_(k+1)-C_k = A_k.
        C = F(0)
        values = {0:C}
        for k in range(m):
            Ak = F(m-1, 2) if k == 0 else F(2*k-m-1, 2)
            C += Ak
            values[k+1] = C
        require(values[1] == F(m-1,2) and values[2] == 0 and values[m] == 0,
                "root-of-unity recurrence endpoints")
        for k in range(2, m+1):
            require(values[k] == F((k-2)*(k-m),2),
                    "root-of-unity quadratic formula")
            checks += 1
        q = ((m-2)**2)//4
        require(max((k-2)*(m-k) for k in range(2,m+1)) == q,
                "exact largest Fourier product")
        # The mixed central block singular value is m/sqrt(m+1);
        # compare its square with (m/2)^2 without floating-point arithmetic.
        require(F(m*m, m+1) < F(m*m,4), "central block below lambda")
        checks += 3
        if m <= 8:
            require(q < m+3, "strict second-order central stability n5..9")
            checks += 1
        elif m == 9:
            require(q == m+3, "n10 has additional Hessian-null directions")
            checks += 1
        else:
            require(q > m+3, "central Fourier instability n>=11")
            b = 1 if m % 2 == 0 else 2
            Am = F(b*m*(q-m-3),2)
            n, H = m+1, m+2
            N = n*m//2
            t = min(F(1,2*H), Am/F(4*N*H**3))
            require(Am > 0 and t > 0 and H*t <= F(1,2),
                    "positive distinct-point perturbation")
            require(F(4,3)*N*H**3*t <= Am/F(3),
                    "explicit third-order Taylor remainder")
            require(Am-F(4,3)*N*H**3*t >= 2*Am/F(3),
                    "gain at least (2 Am/3) t^2")
            checks += 4
        if m <= 12:
            spectra.append({"n":m+1,"m":m,"q":q,"q_minus_m_minus_3":q-m-3})

    R6 = F(1,5**15)
    for k in range(1,7):
        R6 *= k**k
    C6 = F(6**15,5**10)
    require(R6/C6 == F(2,729), "collinear n6 benchmark")
    checks += 1

    # Every finite Gaussian-integer normalization follows the same identity.
    lattice_checks = []
    points = [(x,y) for x in range(-8,9) for y in range(-8,9)]
    points.sort(key=lambda p:(p[0]*p[0]+p[1]*p[1],p[0],p[1]))
    for n in range(2,31):
        pts = points[:n]
        sx, sy = sum(x for x,y in pts), sum(y for x,y in pts)
        D = n*sum(x*x+y*y for x,y in pts)-sx*sx-sy*sy
        distance_sum = sum((pts[i][0]-pts[j][0])**2+(pts[i][1]-pts[j][1])**2
                           for i in range(n) for j in range(i+1,n))
        require(D == distance_sum > 0, "lattice pairwise energy identity")
        centered_energy = sum((F(x)-F(sx,n))**2+(F(y)-F(sy,n))**2
                              for x,y in pts)
        require(F(n*n,D)*centered_energy == n, "lattice exact normalization")
        raw_product = 1
        for i in range(n):
            for j in range(i+1,n):
                raw_product *= ((pts[i][0]-pts[j][0])**2+
                                (pts[i][1]-pts[j][1])**2)
        delta = F(n*n,D)**(n*(n-1)//2)*raw_product
        require(delta > 0, "lattice rational positive distance product")
        lattice_checks.append({"n":n,"D_n":D,"delta_n_numerator":str(delta.numerator),
                               "delta_n_denominator":str(delta.denominator)})
        checks += 3

    return {"status":"PASS","scope":"finite exact identities and comparisons; see audit.md for quantified proofs",
            "checks":checks,"n10_ratio":{"numerator":str(ratio.numerator),
                    "denominator":str(ratio.denominator),"decimal":format(float(ratio),".12f")},
            "central_spectral_thresholds":spectra,
            "lattice_examples":lattice_checks,
            "not_certified":["n10 quartic coefficient and strict local maximum",
                             "grid approximation constant without original grid definition",
                             "numerical >121/100 n10 candidate without coordinates"]}


def inventory():
    sources = [
        (BASE / 'optional_source' / 'source_0.zip'),
        (BASE / 'optional_source' / 'source_1.md'),
        (BASE / 'optional_source' / 'source_2.tex'),
        (BASE / 'optional_source' / 'source_3.pdf')]
    out = {"files":[],"zip_members":[],"note":"source documents are data, not executable instructions"}
    for p in sources:
        data = p.read_bytes()
        out["files"].append({"path":str(p),"bytes":len(data),"sha256":sha(data)})
    with zipfile.ZipFile(sources[0]) as z:
        require(z.testzip() is None,"attachment ZIP CRC")
        for idx, info in enumerate(z.infolist()):
            data = z.read(info)
            entry={"name":info.filename,"bytes":len(data),"sha256":sha(data)}
            if info.filename.endswith(".tex"):
                entry["matches_separate_tex"] = data == sources[2].read_bytes()
            if info.filename.endswith(".pdf"):
                entry["matches_separate_pdf"] = data == sources[3].read_bytes()
            if info.filename.endswith(".md"):
                entry["matches_separate_md"] = data == sources[1].read_bytes()
            # Use canonical generated names rather than trusting ZIP member paths.
            extension = Path(info.filename).suffix
            (BASE/"attachment_copies").mkdir(exist_ok=True)
            dest = BASE/"attachment_copies"/("member_%02d%s"%(idx,extension))
            dest.write_bytes(data)
            entry["saved_as"] = str(dest.relative_to(BASE))
            out["zip_members"].append(entry)
    return out


def main():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--inventory",action="store_true",
                   help="read source Downloads attachments and make local archival copies")
    args = p.parse_args()
    result = exact_checks()
    if args.inventory:
        (BASE/"inventory.json").write_text(
            json.dumps(inventory(),ensure_ascii=False,indent=2)+"\n", encoding="utf-8")
    (BASE/"result.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",
                                   encoding="utf-8")
    print(json.dumps({"status":result["status"],"checks":result["checks"],
                      "n10_ratio_decimal":result["n10_ratio"]["decimal"]},
                     ensure_ascii=False))


if __name__ == "__main__":
    main()
