# 一般点数引理与不分类估计索引

本表是已证明接口的导航；精确陈述以列出的 TeX、statement_catalog 和 all_proof_statement_index 为准。符号沿用综合主报告。量词范围必须随公式使用，表中“必要”不代表完整最大值证明。子集内部矩的严格式要求 \(2\le m<n\)，严格半径/质心推论要求 \(n\ge3\)；两点问题相应为等号。

## 1. 一般点数可复用接口

| 编号 | 内容与范围 | 证明定位及使用限制 |
|---|---|---|
| G01 | 中心化、紧性、非碰撞及尺度律；驻点 \(F_i=\kappa\bar x_i,\ \kappa=N/Q\) | source/n5_primary/supplied_main.tex 与 source 主报告 general hierarchy；普通局部最大可变分，固定原点子问题不允许原点自由变分 |
| G02 | 一般单纯形系数矩上下包围 \(A_{n,k}^{1/k}\le M_n\le[\binom{kN+n-2}{n-2}A_{n,k}]^{1/k}\) | source/mordell_general_n_addendum.tex:137；有效渐近/精确算法接口，未输出一般闭式 |
| G03 | 复子集缩放、边界导数与严格内部矩 \(Q_S>m(m-1)/(n-1)\) | source/general_n/structural_addendum.tex；仅实际全局极大点，推出两点/三点距离、半径与每子集质心界 |
| G04 | Directional majorization、投影协方差及紧系数常数 | 同上 directional/trace propositions；力1系数模型用 \(\rho_n=(n-1)^2/n,\ T_{nk}=\binom{n-1}k^2\rho_n^k\)；改坐标时必须改常数 |
| G05 | 全幂矩/径向矩递推与 mixed-force 条件 | source/n5_primary/generalization_check.py、主报告 general moment hierarchy；任意物理驻点必要条件，可与有限径向层多项式结合 |
| G06 | 二阶复对称矩阵、Takagi/收缩与径向 Gram | source/n5_primary/supplied_main.tex；局部最大 \(\\vert B\\vert \le\lambda\)，不应对任意驻点假定收缩 |
| G07 | 迹约束 \(\operatorname{tr}B=\lambda^2\bar p_2\)、一般 \(\vert p_2\vert \le2n(n-3)/(n(n-1)-4)\) | source/no_classification、主报告 trace；迹界有真实局部最大前提 |
| G08 | 有限点共轭闭合 \(\det H=\vert \det C\vert \)、Fourier 框架/缺陷、距离 Hankel 正性 | source/no_classification/noclass_frames.tex、noclass_relaxation.tex；不能用任意正测度替代恰好n个等权点 |
| G09 | 一般 \(n-2\) 列二维余块 exact trace completion、加权全行迹和满列秩 | source/no_origin_oct8/noorigin_oct8_trace.tex、noorigin_oct8_six.tex；存在精确余块公式不等于已证全域目标符号 |
| G10 | 四列 skew inverse-distance completion、Laurent 对数 majorant、逆矩联合表达 | source/no_origin_oct7/noorigin_oct7_six.tex、source/no_origin_oct8/noorigin_oct8_seven.tex；保留补空间正项及 \(D_{-1},D_{-2}\) 相关性 |
| G11 | sharp fixed-correlation spectral envelope：\(\det G\le(1+(n-1)r)(1-r)^{n-1}\) | work/new_spectral_weighted.tex；单位对角PSD，\(r=\sqrt{X/N}\)；全部端点与等号已证，不能把两种X混用 |
| G12 | \(d>1\) 的候选锐加权 Vandermonde 核与两条有理符号测试 | 同上 weighted theorem；候选可达已证，所有配置存在适用d尚未证，平方前符号前提不可丢 |
| G13 | 删点后的精确力残差及定量范数差距 | source/no_origin_oct7/noorigin_oct7_six_centroid.tex；力差距尚未转成全域锐值差距 |
| G14 | 三层质心零/共线、反射迫出及 circle/self-inversive 根条件 | source/n8 三层相关片段、work/eight_134_new；必须注明对应点数/人数与物理/全局前提，不能脱离人数当一般分类 |
| G15 | 新真实共轭 dual：\(R_0=\delta(2\kappa)^n\bar P(Y/(2\kappa))\)，及 \(R_t=R_0''\) | work/oct9_first4/c0_dual_certificate.tex 和 handoff/c0_root_review.md；一般n物理驻点必要条件，零系数直接传到dual，不需要未知力常数消元 |
| G16 | 有效 annihilator 高度、根分离、固定有限系数矩选择 \(M_n\) | source/general_n/algebraic_fixed_moment.tex；JPT 高度工具为外部依赖，巨大矩阶未执行为八点答案 |

## 2. 五至八点的可直接复用区域定理

| 编号 | 定理与精确范围 | 当前最新值/状态 | 主要证据 |
|---|---|---|---|
| E05 | 五点无限制值上界与等号 | \(M_5=5^5\)，单位正五边形 | source/n5_primary 全二阶矩/二维证书；source/n5 为另一路代数交叉核验 |
| O06 | 六点含原点任意配置 | \(\Delta_6\le C_6\)，中央五边形等号 | source/no_classification 的 weighted5 凹性证明 |
| O07 | 七点含原点任意配置 | \(\Delta_7\le C_7\)，中央六边形等号 | source/no_classification 的 weighted6 凹性证明 |
| O08 | 八点含原点任意配置 | \(W_7\le Q^{28}/7^{21}\)，同半径正七边形等号 | source/no_classification/noclass_origin8.py 及精确1102叶盒、TeX；无中心化/驻点/层数假设 |
| R06 | 任意六点的径向方差带 | \(s\le11/125\Rightarrow\Delta_6<C_6\) | 最新 addendum 与对应 rational checks；旧3/68等更弱阈值为历史 |
| R07 | 任意七点的径向方差带 | \(s\le5/13\Rightarrow\Delta_7<C_7\) | 最新 addendum；旧8/25、189/512为历史 |
| R08 | 任意八点的径向方差带 | \(s\le31/60\Rightarrow\Delta_8<C_8\) | source/no_origin_oct8 径向/quintic 接口及新主报告 |
| X06 | 六点实际局部最大 Gram 排除 | \(X\ge4563/2000\Rightarrow\Delta_6<C_6\) | work/new_spectral_weighted.tex、spectral_conditional_check.py |
| X07 | 七点实际局部最大 Gram 排除 | \(X\ge525/121\)；若所有 \(t_i\ge7/16\)，可用 \(9261/2500\) | 同上；强阈值保留半径前提 |
| X08 | 八点实际局部最大 Gram 排除 | \(X\ge7\Rightarrow\Delta_8<C_8\) | 同上 |
| N06 | 中心化任意六点近原点锐界 | \(\min\vert z_i\vert \le10^{-5}\)；中央管 \(\eta=1/36\) 对数下降 \(-d^2/100\) | work/six_origin_gap 的 whole-region、tube 与审计 |
| N07 | 中心化任意七点近原点锐界 | \(\min\vert z_i\vert \le10^{-6}\)；中央管 \(\eta=1/100\) 下降 \(-2d^2/5\) | work/seven_origin_gap/seven_origin_whole_region.tex 与审计 |
| N08 | 八点实际全局最大近原点刚性 | \(\min\vert z_i\vert \le2\cdot10^{-9}\Rightarrow\)中央七边形 | work/eight_refined_origin.tex、eight_advance/origin_stability.md、audit_new/eight_refined_origin_review.md；不是所有配置上界 |
| H08 | 八点实际局部最大低谐波刚性 | \(\max_{2\le k\le6}\vert p_k\vert \le10^{-14}\Rightarrow\)中央七边形 | work/eight_advance/eight_advance.tex；旧 \(10^{-38}\) 为历史 |
| T678 | coupled trace band | \(\vert s-n/(n-1)\vert \le1/20,\ \vert p_3\vert \le1\) 时 \(\vert p_2\vert \le1,6/5,4/3\) | 六七八对应力/迹证明及 checks；保留所有带内假设 |
| C08 | 二次/三次力列 cubic trace envelope | 候选 trace radius 从 \(3+1/\sqrt2\) 改进到 \(2+1/\sqrt2\) | work/eight_advance/cubic_trace.md；任意收缩完成的最优性不是实际复对称B可达 |
| V08 | 中心对称物理驻点连续方差带不稳定 | 力1矩28，\(V\le9/10\)；原坐标 \(s\le36/245\)，范数平方 \(>1+1/300\) | work/oct9_even/radial_band.tex、21检查及18独立作用式 |
| P08 | 八点整个首四次项 \(c=0\) 图 | 物理驻点 \(b=d=0\)，随后两方形不稳定；无局部最大 | work/oct9_first4/c0_dual_certificate.tex，12独立重建恒等式、107节点/742检查、根线程独立重放 |

## 3. 通用证书方法也应保留

* **商环乘法行列式**：\(\operatorname{Res}(P,A)=\det M_A\)，可以独立于 Sylvester 构造重建生成元；一阶参数导数为逐行替换行列式之和。适合避免大双变量整体展开。
* **整数三角 DAG**：每条 \(m_iQ_i=\sum B_{ij}Q_j\) 的 \(m_i\) 为非零整数；最终 \(Q=1\) 给出原始理想排空。最后检查器只用整数卷积，保留完整多项式及输入映射。
* **单变量 PRS/Sturm/纤维**：先证结果式链并处理共因子的每个实根，再处理层合并、域外、碰撞和被除分母；单纯gcd打印不等于完整纤维证明。
* **合法模 Bézout**：单变量两个primitive整数多项式在素数p下次数保持且明确Bézout=1，可推有理互素。多变量模unit不能无条件推有理unit。
* **精确圆盘及 Rouché/区间力筛选**：给输入代数组件做真实力与值比较；组件全集覆盖须另证或注明发表依赖。
* **完整有理叶盒分割**：需域覆盖、中心/端点分析及每盒下界。随机采样、有限 Gaussian 输入检验只是恒等式诊断。

这些方法同数学引理一样可复用，但证书与物理覆盖必须同时存在。更多未闭合接口、精确反例和版本修复见 classification_and_route_registry.md 第3—5节。
