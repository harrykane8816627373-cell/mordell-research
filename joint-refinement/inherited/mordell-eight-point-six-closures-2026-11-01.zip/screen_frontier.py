"""Standalone independent exact integer interval filter of the 2026-11-01 21-box frontier.
This does NOT re-run original layer 6 contraction; it applies rigorous necessary
layer-7 exclusions to the saved 21 boxes. Candidate boxes are outer regions.
"""
from itertools import combinations
import json
from pathlib import Path
BASE=Path(__file__).resolve().parent
S=1<<40
SEP=S//2
P=list(combinations(range(8),2))

def add(a,b): return a[0]+b[0],a[1]+b[1]
def neg(a): return -a[1],-a[0]
def sub(a,b): return add(a,neg(b))
def mul(a,b):
  q=(a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1])
  return min(q)//S,-(-max(q)//S)
def sq(a):
  return (0 if a[0]<=0<=a[1] else min(a[0]**2,a[1]**2))//S,-(-max(a[0]**2,a[1]**2)//S)
def reciprocal(a):
  if a[0]<=0:raise ArithmeticError('not positive')
  return S*S//a[1],-(-S*S//a[0])
def cadd(a,b):return add(a[0],b[0]),add(a[1],b[1])
def csub(a,b):return sub(a[0],b[0]),sub(a[1],b[1])
def cmul(a,b):return sub(mul(a[0],b[0]),mul(a[1],b[1])),add(mul(a[0],b[1]),mul(a[1],b[0]))
def cnorm(a):return add(sq(a[0]),sq(a[1]))
def points(b):
  q=[(tuple(b[0]),(0,0))]+[(tuple(b[2*k-1]),tuple(b[2*k])) for k in range(1,7)]
  q.append((neg(tuple(map(sum,zip(*(p[0] for p in q))))),neg(tuple(map(sum,zip(*(p[1] for p in q)))))))
  return q

def spectral(q):
  edges=[]
  for i,j in P:
    z=csub(q[i],q[j]);r2=cnorm(z)
    if r2[1]<=SEP:return ('distance',i,j),None
    rec=reciprocal((max(r2[0],SEP),r2[1]));z0=(mul(z[0],rec),neg(mul(z[1],rec)))
    edges.append(cmul(z0,z0))
  best=(0,None,None,None)
  modes=0
  for k in range(1,5):
    for subindices in combinations(range(8),k):
      mask=sum(1<<j for j in subindices)
      if k==4 and mask>255^mask:continue
      modes+=1
      v=[((0,0),(0,0)) for _ in range(8)]
      for (i,j),z in zip(P,edges):
        xi=bool(mask&(1<<i));xj=bool(mask&(1<<j))
        if xi==xj:continue
        if xi:v[i]=cadd(v[i],z);v[j]=csub(v[j],z)
        else:v[i]=csub(v[i],z);v[j]=cadd(v[j],z)
      lhs=sum(cnorm(a)[0] for a in v)
      rhs=2*k*(8-k)*S
      ratio=lhs/rhs
      if ratio>best[0]:best=(ratio,k,mask,lhs)
      if lhs>rhs:return ('spectral',k,mask), best
  assert modes==127,modes
  return None,best

def main():
  results=[]
  for i,b in json.load(open(BASE/'frontier21.json')):
    q=points(b)
    norms=[cnorm(z) for z in q]
    cutoff=all(n[0]*1000>=729*S for n in norms)
    res,best=spectral(q)
    results.append({'index':i,'inner_lower':min(n[0]/S for n in norms),'inner_upper':min(n[1]/S for n in norms), 'radius_reject':cutoff,'spectral_reject':res,'spectral_best_ratio':round(best[0],6) if best else None,'spectral_best_mask':best[2] if best else None,'box_max_width':round(max(y-x for x,y in b)/S,6)})
  print(json.dumps(results,indent=2))
  print('total',len(results),'radial',sum(r['radius_reject'] for r in results),'spectral',sum(bool(r['spectral_reject']) for r in results))
  (BASE/'frontier21-layer7-initial-report.json').write_text(json.dumps({'status':'exact_direct_screen_without_parent_recontraction','precision_bits':40,'results':results,'open_boxes':len(results),'new_whole_box_exclusions':sum(r['radius_reject'] or bool(r['spectral_reject']) for r in results)},indent=2))
if __name__=='__main__':main()

def exact_complex_scale(a,n):
  if n>=0:return (n*a[0][0],n*a[0][1]),(n*a[1][0],n*a[1][1])
  return (n*a[0][1],n*a[0][0]),(n*a[1][1],n*a[1][0])

def high_mode_screen(q):
  powers=[ [((S,S),(0,0)) for _ in range(8)], q]
  for k in range(2,8): powers.append([cmul(a,b) for a,b in zip(powers[-1],q)])
  ss=[((0,0),(0,0)) for _ in range(8)]
  for k in range(8):
    z=((0,0),(0,0))
    for w in powers[k]: z=cadd(z,w)
    ss[k]=z
  t=[cnorm(z) for z in q]
  ratios=[]
  for k in range(2,8):
    lhs=0
    rhs=16*(sum(cnorm(p)[1] for p in powers[k])-cnorm(ss[k])[0]//8)
    for i in range(8):
      # B(q^k)_i = 4k*q^(k-1)*bar(q)-Σ(k-1-r)*s_r*q^(k-2-r) +k(k-1)/2*q^(k-2)
      zr=cmul(powers[k-1][i], (q[i][0],neg(q[i][1])))
      z=exact_complex_scale(zr,4*k)
      for r in range(k-1):
        b=cmul(ss[r],powers[k-2-r][i]);z=csub(z,exact_complex_scale(b,k-1-r))
      z=cadd(z,exact_complex_scale(powers[k-2][i],k*(k-1)//2))
      lhs+=cnorm(z)[0]
    ratio=lhs/rhs if rhs>0 else None
    ratios.append((k,ratio,lhs/S,rhs/S))
  return ratios

if __name__=='__main__':
 print('--- high moments ---')
 for i,b in json.load(open(BASE/'frontier21.json')):
  rr=high_mode_screen(points(b)); ranked=sorted([x for x in rr if x[1] is not None], key=lambda x:x[1],reverse=True)
  print(i,ranked[:2])
