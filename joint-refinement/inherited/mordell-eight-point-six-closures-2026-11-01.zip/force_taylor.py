"""Rigorous center-radius bound for the exact eight-particle stationary force.
Given interval coordinates in the 2^-40 grid, it evaluates F(c) in outward
interval arithmetic at the exact rational center c, and bounds F(q)-F(c)
using the exact reciprocal identity.  A whole box can be excluded only if
some component's center force exceeds its uniform perturbation bound.
"""
from math import isqrt
from screen_frontier import S,P,points,sub,add,mul,neg,cnorm,cadd,csub,reciprocal

def sqrt_up(n):
    k=isqrt(n)
    return k+(k*k<n)

def midpoint_point(interval):
    x,y=interval
    def roundhalf(pair):
        sm=pair[0]+pair[1]
        return sm//2,-(-sm//2)
    return (roundhalf(x),roundhalf(y))

def contract_force(box):
    q=points(box)
    C=[midpoint_point(z) for z in q]
    # doubled-grid center coordinates and radii Ri, all integers.
    mids=[(x[0]+x[1],y[0]+y[1]) for x,y in q]
    rad=[sqrt_up((x[1]-x[0])**2+(y[1]-y[0])**2) for x,y in q]
    forces=[((0,0),(0,0)) for _ in q]
    err=[2*r for r in rad] # 4*delta norm times physical-to-grid conversion.
    for i,j in P:
        dx=mids[i][0]-mids[j][0]
        dy=mids[i][1]-mids[j][1]
        D=isqrt(dx*dx+dy*dy)
        H=rad[i]+rad[j]
        if D<=H:return None
        # 2*S*S*H/(D(D-H)) is the force-change bound in grid units.
        er=-(-2*S*S*H//(D*(D-H)))
        err[i]+=er;err[j]+=er
        z=(sub(C[i][0],C[j][0]),sub(C[i][1],C[j][1]))
        norm=cnorm(z)
        if norm[0]<=0:return None
        rr=reciprocal(norm)
        w=(mul(z[0],rr),neg(mul(z[1],rr)))
        forces[i]=cadd(forces[i],w)
        forces[j]=csub(forces[j],w)
    for i in range(8):
        # f_i(c) -4*conj(c_i)
        centered=csub(forces[i], ((C[i][0][0]*4,C[i][0][1]*4),(-4*C[i][1][1],-4*C[i][1][0])))
        if cnorm(centered)[0]*S>err[i]*err[i]:return 'force_taylor'
    return None
