"""Certified first-order affine force enclosure with quadratic remainder.
For every i, F_i(q) lies in the complex interval
F_i(c) + J_i(c)(x-c) + disk(0, R_i) where x denotes 13 true
independent coordinates, and R_i is derived using exact reciprocal
Taylor identities and exact upper/lower integer square roots.
"""
from math import isqrt
from screen_frontier import S,P,points,add,neg,sub,mul,cnorm,cadd,csub,cmul,reciprocal

def up(n):
 k=isqrt(n)
 return k+(k*k<n)

def midint(interval):
 v=interval[0]+interval[1]
 return v//2, -(-v//2)

def cscale(z,n):
 assert n>=0
 return (z[0][0]*n,z[0][1]*n),(z[1][0]*n,z[1][1]*n)

def zimag(z): return z[0],neg(z[1])

def zl(a,b,z):
 # Complex Gaussian integer multiple (a+ib)*z.
 ar=(a*z[0][0],a*z[0][1]) if a>=0 else (a*z[0][1],a*z[0][0])
 ai=(b*z[1][0],b*z[1][1]) if b>=0 else (b*z[1][1],b*z[1][0])
 br=(b*z[0][0],b*z[0][1]) if b>=0 else (b*z[0][1],b*z[0][0])
 bi=(a*z[1][0],a*z[1][1]) if a>=0 else (a*z[1][1],a*z[1][0])
 return sub(ar,ai),add(br,bi)

def coeffs():
 # L_{ik} = dq_i/dx_k for q_0 real, q_1..q_6 complex, q_7=-sum(q_0..q_6)
 L=[[(0,0) for _ in range(13)] for _ in range(8)]
 L[0][0]=(1,0);L[7][0]=(-1,0)
 for j in range(1,7):
  L[j][2*j-1]=(1,0);L[j][2*j]=(0,1)
  L[7][2*j-1]=(-1,0);L[7][2*j]=(0,-1)
 return L
L=coeffs()

def contract_affine(box, debug=False):
 q=points(box)
 m=[midint(t) for t in box]
 # The actual reference point is the exact rational center of all 13
 # intervals; C encloses its dependent eighth centered point.
 C=points([midint(t) for t in box])
 mids=[(x[0]+x[1],y[0]+y[1]) for x,y in q]
 rad=[up((x[1]-x[0])**2+(y[1]-y[0])**2) for x,y in q]
 F=[((0,0),(0,0)) for _ in range(8)]
 J=[[((0,0),(0,0)) for _ in range(13)] for _ in range(8)]
 er=[0]*8
 for i,j in P:
  d=(mids[i][0]-mids[j][0],mids[i][1]-mids[j][1])
  D=isqrt(d[0]**2+d[1]**2)
  H=rad[i]+rad[j]
  if D<=H:return None
  err=-(-2*S*S*H*H//(D*D*(D-H)))
  er[i]+=err;er[j]+=err
  z=csub(C[i],C[j]);r2=cnorm(z)
  if r2[0]<=0:return None
  inv=reciprocal(r2)
  recip=(mul(z[0],inv),neg(mul(z[1],inv)))
  invsq=cmul(recip,recip)
  F[i]=cadd(F[i],recip);F[j]=csub(F[j],recip)
  for k in range(13):
   aa=L[i][k][0]-L[j][k][0];bb=L[i][k][1]-L[j][k][1]
   if not aa and not bb:continue
   v=zl(aa,bb,invsq)
   J[i][k]=csub(J[i][k],v)
   J[j][k]=cadd(J[j][k],v)
 for i in range(8):
  F[i]=csub(F[i],cscale(zimag(C[i]),4))
  for k in range(13):
   a,b=L[i][k]
   if a or b:
    v=( (4*a*S,4*a*S), (-4*b*S,-4*b*S))
    J[i][k]=csub(J[i][k],v)
 for i in range(8):
  aff=F[i]
  for k in range(13):
   delta=sub(tuple(box[k]),m[k])
   aff=cadd(aff,(mul(J[i][k][0],delta),mul(J[i][k][1],delta)))
  if aff[0][0]>er[i] or aff[0][1]<-er[i] or aff[1][0]>er[i] or aff[1][1]<-er[i]:
   if debug: print('violation',i,'affine',aff,'error',er[i],'scale',S)
   return 'force_affine'
 return None
