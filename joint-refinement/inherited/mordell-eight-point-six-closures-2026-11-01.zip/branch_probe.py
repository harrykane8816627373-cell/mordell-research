"""Conservative proof-search probe on the 21 certified frontier outer boxes.
All rejection inequalities are exact integer interval bounds, never floats.
The output is a PARTIAL certificate, unless every remaining box is empty.
"""
import sys,json,gzip,collections,hashlib,argparse
from screen_frontier import *
from pathlib import Path
from force_taylor import contract_force
from force_affine import contract_affine
BASE=Path(__file__).resolve().parent

def mulpositive(a,b):
    return a*b

def mulc(a,b):return cmul(a,b)

def zscale(a,n):
    assert n>=0
    return ((a[0][0]*n,a[0][1]*n),(a[1][0]*n,a[1][1]*n))

def zzero():return ((0,0),(0,0))
def has_zero(a):return a[0][0]<=0<=a[0][1] and a[1][0]<=0<=a[1][1]

def check_simple(b, use_taylor=True, use_affine=True):
    q=points(b)
    t=[cnorm(z) for z in q]
    if sum(x[0] for x in t)>7*S or sum(x[1] for x in t)<7*S:return 'mass'
    if any(a>49*S//32 for a,_ in t):return 'radius'
    d2=[cnorm(csub(q[i],q[j])) for i,j in P]
    if any(hi<=SEP for lo,hi in d2):return 'separation'
    if all(1000*lo>=729*S for lo,hi in t):return 'radial_729'
    # Product of squared distances upper bounds Delta.  All exact integers.
    dprod=1
    for lo,hi in d2:dprod*=hi
    if dprod<7**7*S**28:return 'discriminant'
    if use_taylor and contract_force(b):return 'force_taylor'
    if use_affine and contract_affine(b):return 'force_affine'
    powers=[ [((S,S),(0,0)) for _ in q],q]
    for k in range(2,7):powers.append([cmul(a,z) for a,z in zip(powers[-1],q)])
    ss=[]
    for k in range(7):
        z=zzero()
        for p in powers[k]:z=cadd(z,p)
        ss.append(z)
    s2=cnorm(ss[2]);s3=cnorm(ss[3])
    if 175*s2[0]+54*s3[0]>=175*S:return 'ellipse'
    for k in range(1,7):
        Q=zzero()
        for i in range(8):Q=cadd(Q,cmul((t[i],(0,0)),powers[k][i]))
        W=csub(zscale(Q,8),zscale(ss[k],15-k))
        for ell in range(1,k):W=csub(W,cmul(ss[ell],ss[k-ell]))
        if not has_zero(W):return f'Ward{k}'
    # Whole-box radial E upper <=1/1200, so cannot challenge candidate
    Ehi=0
    for lo,hi in t:
        shift=(lo-S,hi-S)
        Ehi+=mul((lo,hi),sq(shift))[1]
    if Ehi*1200<=S:return 'radial_gap'
    # True force conditions are implied by Ward, but direct intervals may tighten.
    # Inverse geometric differences use already certified strict separation.
    inv=[]
    for i,j in P:
        z=csub(q[i],q[j]);r2=cnorm(z)
        rec=reciprocal((max(r2[0],SEP),r2[1]))
        inv.append((mul(z[0],rec),neg(mul(z[1],rec))))
    F=[zzero() for _ in q]
    for (i,j),v in zip(P,inv):F[i]=cadd(F[i],v);F[j]=csub(F[j],v)
    for i in range(8):
        # f_i=4*conjugate(q_i)
        g=csub(F[i],zscale((q[i][0],neg(q[i][1])),4))
        if not has_zero(g):return 'force'
    # Apply layer-7 mode inequalities after cheaper old tests
    reason,_=spectral(q)
    if reason:return reason[0]
    return None

def solve(nodes=2000,limit_roots=None,resume=None):
    original=json.load(open(BASE/'frontier21.json'))
    pending=collections.deque((i,[tuple(x) for x in b]) for i,b in original)
    if limit_roots is not None:pending=collections.deque(v for v in pending if v[0] in limit_roots)
    counts=collections.Counter();proof=[]
    initial=list(pending)
    if resume is not None:
        from verify_probe import verify
        evidence=verify(str(resume))
        assert evidence['passed'] and not evidence['selected_scope_complete'], 'need a verified unfinished proof'
        with gzip.open(resume,'rt') as f: prior=json.load(f)
        if prior['algorithm_version']!='affine' or prior['original_roots'] != [i for i,b in initial]: raise ArithmeticError('mismatched algorithm/root set')
        pending=collections.deque((i,[tuple(x) for x in b]) for i,b in prior['pending'])
        proof=prior['proof_nodes']
        counts=collections.Counter(prior['counts'])
    base_nodes=len(proof)
    for it in range(nodes):
        if not pending:break
        root,b=pending.popleft()
        reason=check_simple(b)
        if reason:
            counts[reason]+=1
            proof.append(['X',root,b,reason])
        else:
            dim=max(range(13),key=lambda j:b[j][1]-b[j][0]);lo,hi=b[dim];cut=(lo+hi)//2
            if lo>=cut or cut>=hi:
                pending.append((root,b));continue
            l=b.copy();r=b.copy();l[dim]=(lo,cut);r[dim]=(cut,hi)
            pending.append((root,l));pending.append((root,r))
            counts['split']+=1
            proof.append(['S',root,b,dim,cut])
        if it%500==499:print('iter',it+1,'counts',dict(counts),'open',len(pending),flush=True)
    closed=[i for i,b in initial if i not in set(x[0] for x in pending)]
    record={'explanation':'original unresolved boxes are outer enclosures; every X excludes its entire exact box; S partitions entire exact box; missing branch is retained as pending','precision_bits':40,'algorithm_version':'affine','source':'e846b8e9 joint-refinement/certificates/joint_extension.json.gz','input_file_sha256':hashlib.sha256(open(BASE/'frontier21.json','rb').read()).hexdigest(),'counts':dict(counts),'original_roots':[i for i,b in initial],'closed_roots':closed,'open_roots':sorted(set(i for i,b in pending)),'open_count':len(pending),'selected_roots_complete':not pending,'full_exclusion_proved':not pending and len(initial)==21,'proof_nodes':proof,'pending':[[i,b] for i,b in pending]}
    suffix='' if limit_roots is None else '_roots'+'-'.join(map(str,sorted(limit_roots)))
    filename=str(BASE/f'probe_certificate_{len(proof)}{suffix}.json.gz')
    with gzip.open(filename,'wt',encoding='utf-8') as f:json.dump(record,f,separators=(',',':'))
    report={k:v for k,v in record.items() if k not in ('proof_nodes','pending')}
    report['certificate_path']=filename
    print(json.dumps(report,indent=2));return record

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--nodes',type=int,default=2000);p.add_argument('--roots',type=int,nargs='*');p.add_argument('--resume',type=Path);a=p.parse_args();solve(a.nodes,set(a.roots) if a.roots else None,a.resume)
