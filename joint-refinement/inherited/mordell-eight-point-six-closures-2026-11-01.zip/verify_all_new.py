"""Replay the six complete subtree proofs and the two partial proof forests.
This does not replay the immutable original 330021-node parent repository
certificate.  It verifies the extracted 21 outer boxes and new subtree claims.
"""
import hashlib,json,zlib
from pathlib import Path
from fractions import Fraction as F
from verify_probe import verify
BASE=Path(__file__).resolve().parent
CLOSED=(9976,10012,10014,10016,10019,10020)
OPEN=(7954,9814)
EXPECTED_CANONICAL_SHA256='a365cea82dc5e953dd2e8517d94606f3da1e0dd5210530091fdc8ac42b79736b'

def polynomial_identity():
    a=F(729,1000);L=F(1083,20)
    f=lambda t:-120*t**4+288*t**3-162*t**2
    c=f(a)-L*a
    g=lambda t:120*t*(t-F(1073,1000))**2+57*(t-F(63718,59375))**2+F(474140217,11875000000)
    # Difference is a polynomial of degree<=4; five distinct exact zeros imply identity.
    for t in [F(0),F(1,4),F(1,2),F(1),F(3,2)]:
        assert L*t+c-f(t)==(t-a)*g(t)
    assert 7*L+8*c+4==-F(49638643,3125000000)

if __name__=='__main__':
    raw=json.loads((BASE/'frontier21.json').read_text())
    canon=json.dumps(raw,separators=(',',':'))
    assert len(raw)==21 and len(set(i for i,b in raw))==21
    assert hashlib.sha256(canon.encode()).hexdigest()==EXPECTED_CANONICAL_SHA256
    assert zlib.adler32(canon.encode())==0xa44d42fe
    polynomial_identity()
    details={}
    for root in CLOSED:
        result=verify(BASE/f'certificates/closed_{root}.json.gz')
        assert result['passed'] and result['selected_scope_complete']
        assert result['closed_roots']==[root] and not result['global_exclusion_proved']
        details[str(root)]=result
    partial={}
    for root,n in ((7954,1800),(9814,4000)):
        result=verify(BASE/f'certificates/open_{root}_{n}.json.gz')
        assert result['passed'] and not result['selected_scope_complete']
        partial[str(root)]=result
    remaining=sorted(set(i for i,b in raw)-set(CLOSED))
    out={'passed':True,'parent_scope':'global_maximum','parent_open_boxes':21,
         'independent_newly_closed_parent_boxes':len(CLOSED), 'closed_ids':list(CLOSED),
         'remaining_parent_boxes':len(remaining),'remaining_parent_ids':remaining,
         'certificate_nodes_for_closed_trees':sum(details[str(root)]['processed_nodes'] for root in CLOSED),
         'proofs':details,'partial_probes':partial,
         'global_eight_point_exclusion_proved':False,
         'full_original_parent_proof_replayed_in_this_package':False}
    print(json.dumps(out,indent=2))
