"""Replay each finite whole-box exclusion and split in an open partial tree.
No numeric tolerances. A nonempty pending queue prohibits proof completion.
"""
import gzip,json,collections,hashlib,sys
from pathlib import Path
from branch_probe import check_simple

def verify(path):
 data=json.load(gzip.open(path,'rt'))
 raw=(Path(__file__).resolve().parent/'frontier21.json').read_bytes()
 if data['input_file_sha256'] != hashlib.sha256(raw).hexdigest():raise ArithmeticError('frontier identity mismatch')
 frontier=json.loads(raw)
 if data.get('algorithm_version') not in ('original','taylor','affine'):raise ArithmeticError('unknown method version')
 pending=collections.deque((i,[tuple(x) for x in b]) for i,b in frontier if i in data['original_roots'])
 if data['original_roots'] != [i for i,b in frontier if i in data['original_roots']] or len(data['original_roots'])!=len(set(data['original_roots'])):raise ArithmeticError('roots changed')
 counts=collections.Counter()
 for r in data['proof_nodes']:
  i,b=pending.popleft()
  if r[1]!=i or [list(v) for v in b]!=[list(v) for v in r[2]]:raise ArithmeticError('incorrect next box')
  reason=check_simple(b,use_taylor=(data['algorithm_version'] in ('taylor','affine')),use_affine=(data['algorithm_version']=='affine'))
  if r[0]=='X':
   if r[3]!=reason or reason is None:raise ArithmeticError('unproved exclusion')
   counts[reason]+=1
  elif r[0]=='S':
   dim,cut=r[3:]
   if reason is not None or not 0<=dim<13 or not b[dim][0]<cut<b[dim][1]:raise ArithmeticError('unproved split')
   left=b.copy();right=b.copy();left[dim]=(b[dim][0],cut);right[dim]=(cut,b[dim][1]);pending.extend([(i,left),(i,right)]);counts['split']+=1
  else:raise ArithmeticError('bad node')
 recorded=[(i,[tuple(x) for x in b]) for i,b in data['pending']]
 if list(pending)!=recorded:raise ArithmeticError('frontier incomplete or incorrect')
 if counts!=data['counts']:raise ArithmeticError('counts mismatch')
 if data.get('full_exclusion_proved')!= (not pending and len(data['original_roots'])==21):raise ArithmeticError('false complete')
 if 'selected_roots_complete' in data and data['selected_roots_complete'] != (not pending):raise ArithmeticError('false selected-root complete')
 if data['open_count']!=len(pending):raise ArithmeticError('incorrect open count')
 closed=[i for i,b in frontier if i in data['original_roots'] and i not in set(j for j,c in pending)]
 if data['closed_roots']!=closed:raise ArithmeticError('incorrect closed roots')
 return {'passed':True,'selected_scope_complete':not pending,'global_exclusion_proved':data['full_exclusion_proved'],'processed_nodes':len(data['proof_nodes']),'counts':dict(counts),'open_count':len(pending),'closed_roots':closed}
if __name__=='__main__':
 for f in sys.argv[1:]:print(json.dumps(verify(f),indent=2))
