"""Exact arithmetic checks for the improved grid certificate.

The analytic matrix and Taylor estimates are proved in the accompanying
LaTeX section; this checker validates its rational constants and schedules.
"""
from fractions import Fraction as Q
from math import isqrt
import json


def require(ok, message):
    if not ok:
        raise ArithmeticError(message)


def rational_error(n, q):
    require(n >= 2 and q >= n, "Grid hypotheses")
    return Q(n * (n - 1), 2 * q * q) + Q(35 * n**3, 72 * q**3)


def audit():
    # The uniform rational majorant uses 2^(-1/4) < 7/8 and
    # 2/(3*sqrt(3)) < 2/5; both reduce to integer inequalities.
    require(8**4 < 2 * 7**4, "Fourth-root constant")
    require(25 < 27, "Square-root constant")
    require(Q(1, 2) + Q(35, 72) == Q(71, 72), "Accuracy coefficient")

    # E_6(10) < 7113/38000 < 3/16 from separately certified roots.
    require(5 * 4**2 < 9**2, "sqrt(5) upper bound")
    require(6 * 100**4 < 157**4, "Fourth root of 6 upper bound")
    require(12**2 < 6 * 5**2, "sqrt(6) lower bound")
    old_gap = Q(6 * 5 * 11, 4 * 10**2)
    upper = Q(3, 20) + Q(25) * Q(9, 4) * Q(157, 100) / (Q(3000) * Q(19, 24))
    require(old_gap == Q(33, 40), "Original six-point gap")
    require(upper == Q(7113, 38000) < Q(3, 16), "New six-point gap")
    require(1 / (1 - Q(3, 16)) == Q(16, 13), "New rational enclosure")

    rows = []
    for n in range(2, 51):
        for epsilon in (Q(1), Q(1, 10), Q(1, 100)):
            q = isqrt((n*n*epsilon.denominator + epsilon.numerator - 1) // epsilon.numerator)
            if epsilon*q*q < n*n:
                q += 1
            q = max(q, n)
            require(epsilon*q*q >= n*n, "Accuracy schedule")
            gap = rational_error(n, q)
            require(gap < Q(71, 72)*epsilon, "Uniform error schedule")
            rows.append({"n": n, "epsilon": str(epsilon), "q": q, "rational_gap": str(gap)})
    return {
        "status": "passed",
        "arithmetic": "Exact integer comparisons and Fraction",
        "n6_q10_old_gap": str(old_gap),
        "n6_q10_new_gap_strict_upper": str(upper),
        "n6_q10_enclosure_factor": "16/13",
        "schedule_checks": len(rows),
        "scope": "Rational constants and accuracy schedules; no new complete six-point grid enumeration",
    }


if __name__ == "__main__":
    print(json.dumps(audit(), ensure_ascii=False, indent=2))
