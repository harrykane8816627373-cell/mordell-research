"""Independent rational checks of all_n_structure_radial.tex.

Only integers and Fraction are used.  Explicit exceptions keep every check
active under python -S -O.  The script checks the positive combinations,
rescalings, exact polynomial identities, and rational radius enclosures.
"""

from fractions import Fraction as F
from pathlib import Path
import json

checks = 0


def check(condition, reason):
    global checks
    if not condition:
        raise RuntimeError(reason)
    checks += 1


def add(*terms):
    answer = {}
    for multiplier, polynomial in terms:
        for variable, coefficient in polynomial.items():
            answer[variable] = answer.get(variable, F(0)) + multiplier * coefficient
    return {variable: coefficient for variable, coefficient in answer.items() if coefficient}


def radius_function(n, p, x):
    return x ** p + (n - x) ** p / F((n - 1) ** (p - 1))


def isolate_radius(n, p, limit):
    lower, upper = F(1), F(n)
    for _ in range(90):
        midpoint = (lower + upper) / 2
        if radius_function(n, p, midpoint) < limit:
            lower = midpoint
        else:
            upper = midpoint
    check(radius_function(n, p, lower) < limit <= radius_function(n, p, upper),
          f"Invalid radius enclosure n={n}, p={p}")
    return [str(lower), str(upper)]


for n in range(2, 501):
    v = n - 1
    N = F(n * v, 2)
    c, d = 2 * n - 3, 3 * (n - 2)
    D = 6 * d * c - d * d
    C2 = {"u2": F(3), "s2": F(1, n), "constant": -n * v * v}
    C3 = {"u3": F(8), "u2": -6 * c, "s3": F(1, n), "constant": c * c * N}
    C4 = {"u4": F(15), "u3": -8 * d, "u2": d * d,
          "s2": -n, "s4": F(1, n)}
    combined3 = add((F(1), C3), (F(2 * c), C2))
    K3 = F(n * v * c * (2 * n - 1), 2)
    check(combined3 == {"u3": F(8), "s2": F(2 * c, n),
                        "s3": F(1, n), "constant": -K3},
          f"Sixth-moment positive combination failed n={n}")
    L3 = F(n * c * (2 * n - 1), 2 * v * v)
    check(L3 == 2 * n - F(n, 2 * v * v), f"L3 identity failed n={n}")
    check(K3 / v ** 3 == L3, f"L3 rescaling failed n={n}")
    check((F(2 * c, n) * F(v * v, 4)) / v ** 3 == F(c, 2 * n * v),
          f"Sixth s2 rescaling failed n={n}")
    check(F(1, n) * F(v ** 3, 8) / v ** 3 == F(1, 8 * n),
          f"Sixth s3 rescaling failed n={n}")
    check(n < L3 < n ** 3, f"Sixth radial-root bracket failed n={n}")
    check(F(n * v * c, 4) > F(n * v * v, 3) if n >= 3 else True,
          f"Collinear exclusion failed n={n}")

    if n >= 3:
        a = 8 * n * n - 30 * n + 24
        K4 = F(3 * n * v * (n - 2) * (2 * n * n - 2 * n - 1), 2)
        combined4 = add((F(1), C4), (F(d), C3), (F(D, 3), C2))
        check(combined4 == {"u4": F(15), "s2": F(a, n),
                            "s3": F(d, n), "s4": F(1, n), "constant": -K4},
              f"Eighth-moment positive combination failed n={n}")
        check(a > 0 and d > 0 and D > 0, f"Combination/penalty sign failed n={n}")
        L4 = F(8 * n * (n - 2) * (2 * n * n - 2 * n - 1), 5 * v ** 3)
        check(F(16, 15 * v ** 4) * K4 == L4, f"L4 rescaling failed n={n}")
        check(L4 == F(16 * n, 5) - F(24 * n, 5 * v * v) + F(8 * n, 5 * v ** 3),
              f"L4 expanded identity failed n={n}")
        check(n < L4 < F(16 * n, 5) < n ** 4,
              f"Eighth radial-root bracket failed n={n}")
        scale = F(16, 15 * v ** 4)
        check(scale * F(a, n) * F(v * v, 4) == F(4 * a, 15 * n * v * v),
              f"Eighth s2 rescaling failed n={n}")
        check(scale * F(d, n) * F(v ** 3, 8) == F(2 * (n - 2), 5 * n * v),
              f"Eighth s3 rescaling failed n={n}")
        check(scale * F(1, n) * F(v ** 4, 16) == F(1, 15 * n),
              f"Eighth s4 rescaling failed n={n}")

# Independently verify the divided-difference pair sum for the mixed term.
# Sum_{i<j} wi*wj=(s1^2-s2)/2, with s1=0, makes the coefficient n-3/2.
for n in range(2, 501):
    check(F(n - 1) - F(1, 2) == F(2 * n - 3, 2),
          f"Pairwise mixed-moment identity failed n={n}")
    check(4 * F(2 * n - 3, 2) - 3 * (n - 2) == n,
          f"Quartic constant projection failed n={n}")

for n in range(8, 501):
    a = F(n - 1, 2)
    ring_cut = n * (15 * a ** 4 - 24 * (n - 2) * a ** 3 + 9 * (n - 2) ** 2 * a ** 2)
    check(ring_cut == F(3 * n * (n - 1) ** 2 * (n - 3) * (n - 7), 16) > 0,
          f"Regular-polygon k=4 exclusion failed n={n}")

for n in range(11, 501):
    a = F(n, 2)
    d5 = 4 * n - 10
    central_cut = (n - 1) * (24 * a ** 5 - 10 * d5 * a ** 4 + d5 ** 2 * a ** 3)
    check(central_cut == F(n ** 3 * (n - 1) * (n - 5) * (n - 10), 4) > 0,
          f"Central-polygon k=5 exclusion failed n={n}")

# Exact shell-count tests at rational thresholds: the bound itself does not
# assume a physical configuration, and this merely records allowable counts.
shell_counts = []
for n in (6, 10, 20, 100):
    L4 = F(8 * n * (n - 2) * (2 * n * n - 2 * n - 1), 5 * (n - 1) ** 3)
    for threshold in (F(3, 2), F(2), F(5, 2)):
        possible = [0]
        for k in range(1, n):
            if k * threshold <= n:
                lower_moment = k * threshold ** 4 + (n - k * threshold) ** 4 / F((n - k) ** 3)
                if lower_moment <= L4:
                    possible.append(k)
        check(possible == list(range(max(possible) + 1)),
              f"Nonmonotone outer-shell counts n={n}, threshold={threshold}")
        shell_counts.append({"n": n, "squared_radius_threshold": str(threshold),
                             "maximum_allowed_outer_count": max(possible)})

radius_intervals = []
for n in (6, 10, 100):
    for p in (3, 4):
        v = n - 1
        L = F(n * (2 * n - 3) * (2 * n - 1), 2 * v * v) if p == 3 else F(8 * n * (n - 2) * (2 * n * n - 2 * n - 1), 5 * v ** 3)
        radius_intervals.append({"n": n, "moment_power": p,
                                 "squared_radius_interval": isolate_radius(n, p, L)})

result = {
    "exact_checks_passed": checks,
    "arithmetic": "integers and Fraction only; checks survive -S -O",
    "L6_3": str(F(6 * 9 * 11, 50)),
    "L6_4": str(F(8 * 6 * 4 * 59, 625)),
    "radius_intervals": radius_intervals,
    "shell_counts": shell_counts,
}
target = Path(__file__).with_name("all_n_structure_radial_results.json")
target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"exact_checks_passed": checks, "result_file": str(target)}, indent=2))
