"""Independent standard-library checks for the all-n conversion and formulas.

All verification uses integers/Fractions and explicit exceptions. Floating
values printed at the end are illustrations, not certificate endpoints.
"""
import json
import math
from collections import Counter
from fractions import Fraction as Q
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def require(flag,message):
    if not flag:raise ArithmeticError(message)


def prime_factors(a):
    out=Counter();d=2
    while d*d<=a:
        while a%d==0:out[d]+=1;a//=d
        d+=1
    if a>1:out[a]+=1
    return out


def add(a,b):
    out=dict(a)
    for k,x in b.items():out[k]=out.get(k,Q(0))+x
    return {k:x for k,x in out.items() if x}


def scale(a,q):return {k:x*q for k,x in a.items() if x*q}


def formal_log(q):
    q=Q(q);require(q>0,'Log argument must be positive')
    a=prime_factors(q.numerator);b=prime_factors(q.denominator)
    return add({f'log({p})':Q(v) for p,v in a.items()},
               {f'log({p})':Q(-v) for p,v in b.items()})


def conversion_check(n,delta):
    N=n*(n-1)//2;s=Q(n-1,2*n)
    # Exact objective and quadratic norm of the scaled shape.
    delta_x=Q(delta)*s**N;quadratic_x=n*s
    direct=add(scale(formal_log(delta_x),Q(-1)),{'one':n*quadratic_x})
    conversion=add(scale(formal_log(delta),Q(-1)),
                   add({'one':Q(N)},scale(formal_log(s),Q(-N))))
    require(direct==conversion,'Exact scaling-energy identity failed')
    # Radial stationarity for H_n: Q_x=N/n.
    require(quadratic_x==Q(N,n),'Exact radius factor failed')


def multiply_factor(poly,i,j,k):
    out={}
    for a,c in poly.items():
        for r in range(k+1):
            b=list(a);b[i]+=k-r;b[j]+=r;b=tuple(b)
            out[b]=out.get(b,0)+c*((-1)**r)*math.comb(k,r)
    return {a:c for a,c in out.items() if c}


def vandermonde_power(n,k):
    poly={(0,)*n:1}
    for i in range(n):
        for j in range(i+1,n):poly=multiply_factor(poly,i,j,k)
    return poly


def norm(poly):
    return sum(c*c*math.prod(math.factorial(x) for x in a) for a,c in poly.items())


def partition_check(n,k):
    poly=vandermonde_power(n,k);orbits={}
    N=n*(n-1)//2
    for a,c in poly.items():
        lam=tuple(sorted(a,reverse=True))
        require(sum(lam)==k*N,'Wrong homogeneous degree')
        require(all(sum(lam[:r])<=k*r*(2*n-r-1)//2 for r in range(1,n+1)),
                'Dominance bound failed')
        if k%2:require(len(set(lam))==n,'Odd power has repeated exponent')
        if lam in orbits:require(orbits[lam][0]==c*c,'Orbit coefficient magnitude failed')
        else:orbits[lam]=[c*c,0]
        orbits[lam][1]+=1
    compressed=Q(0)
    for lam,(csq,count) in orbits.items():
        denominator=math.prod(math.factorial(v) for v in Counter(lam).values())
        require(count==math.factorial(n)//denominator,'Incomplete exponent orbit')
        compressed+=Q(math.factorial(n)*csq*math.prod(math.factorial(x) for x in lam),denominator)
    direct=norm(poly)
    require(compressed==direct,'Partition normalization failed')
    if n==2:require(direct==2**k*math.factorial(k),'Two-point exact norm mismatch')
    if n==3:
        independent=sum(math.comb(k,j)**2*math.factorial(3*j)*math.factorial(3*(k-j)) for j in range(k+1))
        require(direct==independent,'Unitary three-point norm mismatch')
    return {'n':n,'k':k,'monomials':len(poly),'partition_orbits':len(orbits),'C':str(direct)}


def derivative_difference(poly,i,j):
    out={}
    for a,c in poly.items():
        for index,sgn in ((i,1),(j,-1)):
            if a[index]:
                b=list(a);b[index]-=1;b=tuple(b)
                out[b]=out.get(b,0)+sgn*c*a[index]
    return {a:c for a,c in out.items() if c}


def run():
    # Exact logarithms of rationals are recorded by prime-factor coefficient.
    for n in range(2,31):conversion_check(n,n**n)
    conversion_check(6,Q(6**15,5**10))
    # Formal Taylor coefficients of N[1+log2-log(1-1/n)].
    # A coefficient is (constant, coefficient of log2); x=1/n.
    series={-2:(Q(1,2),Q(1,2)),-1:(Q(0),Q(-1,2))}
    for r in range(7):
        actual=Q(1,2*(r+2))-Q(1,2*(r+1))
        expected=Q(-1,2*(r+1)*(r+2))
        require(actual==expected,'Formal scaling expansion failed')
        series[r]=(actual,Q(0))
    require(series[0][0]==Q(-1,4),'Scaling constant term failed')
    # Symbolic linear coefficient and triangular substitution.
    gamma={'W_over_pi':Q(-1),'log_pi':Q(-1,2),'log_2':Q(-1,2)}
    triangle_W={'log_pi':Q(1),'log_3':Q(-1,2),'log_Gamma_1third':Q(-3),'log_2':Q(3,2)}
    triangle_gamma=add(scale(triangle_W,Q(-1)),{'log_pi':Q(-1,2),'log_2':Q(-1,2)})
    require(triangle_gamma=={'log_pi':Q(-3,2),'log_3':Q(1,2),'log_Gamma_1third':Q(3),'log_2':Q(-2)},
            'Triangular linear coefficient conversion failed')
    cases=[(2,k) for k in range(1,7)]+[(3,k) for k in range(1,7)]+[(4,k) for k in range(1,4)]+[(5,1),(5,2),(6,1),(6,2)]
    rows=[partition_check(n,k) for n,k in cases]
    # Specific failure of the ordinary-differential shift.
    poly=vandermonde_power(3,3)
    for i,j in ((0,1),(0,2),(1,2)):poly=derivative_difference(poly,i,j)
    at_collision=sum(c for a,c in poly.items() if a[0]==a[1]==0)
    require(at_collision==-12,'Differential-shift counterexample failed')
    # Specific failure of the single per-pair Selberg correction.
    k=2;n=3;N=3
    pairfactor=Q(2**k*math.factorial(k)**2,math.factorial(2*k))
    predicted=pairfactor**N*math.prod(Q(math.factorial(j*k),math.factorial(k)) for j in range(1,n+1))
    actual=norm(vandermonde_power(n,k))
    require(predicted==1280 and actual==1584,'Selberg-product counterexample failed')
    # The Gaussian p2/p1^2 cross inner product follows monomial orthogonality.
    for n in range(1,21):
        p2={tuple(2*int(i==j) for i in range(n)):1 for j in range(n)}
        p1sq={}
        for i in range(n):
            for j in range(n):
                a=[0]*n;a[i]+=1;a[j]+=1;a=tuple(a)
                p1sq[a]=p1sq.get(a,0)+1
        cross=sum(c*p1sq.get(a,0)*math.prod(math.factorial(x) for x in a) for a,c in p2.items())
        require(cross==2*n,'Gaussian/Jack scalar-product mismatch check failed')
    output={'exact_scaling_cases':30,'formal_scaling_constant':'-1/4',
            'gamma_symbolic':{k:str(v) for k,v in gamma.items()},
            'triangle_gamma_symbolic':{k:str(v) for k,v in triangle_gamma.items()},
            'partition_cases':rows,'differential_shift_collision_value':at_collision,
            'Selberg_corrected_prediction':str(predicted),'actual_C3_2':str(actual),
            'illustrative_gamma_triangle':3*math.lgamma(1/3)+0.5*math.log(3)-2*math.log(2)-1.5*math.log(math.pi),
            'illustrative_gamma_upper':0.5*math.log(math.pi)}
    (ROOT/'all_n_uniform_checks.json').write_text(json.dumps(output,indent=2))
    print('Exact checks passed:',len(rows),'partition cases; exact energy scaling; constant normalization; two specific product obstructions.')
    print('Illustrative linear-coefficient endpoints:',output['illustrative_gamma_triangle'],output['illustrative_gamma_upper'])


if __name__=='__main__':run()
