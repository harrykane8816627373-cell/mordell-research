"""Exact checks of the new framework; independent of floating-point eigensolvers."""
from fractions import Fraction as F
from math import factorial, comb
from pathlib import Path
import json
import verify_spectral_agent as spectral


def check(ok, message):
    if not ok:
        raise ArithmeticError(message)


def main():
    spectral.check_three_sos()
    for n in range(2,8):
        spectral.check_first_level(n)
    # All bounds below are proved by positive rational integer comparisons.
    check(F(9,4)**2 > 5, 'sqrt5 upper bound')
    check(F(157,100)**4 > 6, 'fourth root6 upper bound')
    check(F(5,24)**2 * 24 > 1, 'reciprocal sqrt6 upper bound')
    e6_upper = F(3,20)+25*F(9,4)*F(157,100)/(3000*(1-F(5,24)))
    check(e6_upper == F(7113,38000), 'six-point grid rational arithmetic')
    check(e6_upper < F(3,16), 'six-point grid improvement')
    check(1/(1-F(3,16)) == F(16,13), 'rational grid factor')
    # General rational majorant's elementary root constants.
    check(F(2,5)**2 > F(4,27), 'bound on b for q>=n')
    check(F(7,8)**4 > F(1,2), 'bound on n^(-1/4)')
    check(F(7,8)/(3*(1-F(2,5))) == F(35,72), 'majorant coefficient')
    # Cross-check the six-point centered r=1 value against ambient Gram formula.
    n=6;N=15
    c1=factorial(n)
    for j in range(n):
        c1 *= factorial(j)
    first_upper=F(n**N*(n+2)*c1,2*factorial(N+1))
    check(first_upper < 2236740, 'first spectral level exact bound')
    result={'status':'passed',
            'checks':['n=2..7 complete first-degree Gaussian Gram',
                      'n=3 exact spectral matrices',
                      'n=3 mixed-polynomial sharp SOS identity',
                      'rational constants in improved grid error',
                      'n=6 centered first spectral-level bound'],
            'six_point_grid_exponent_rational_upper':str(e6_upper),
            'six_point_first_spectral_upper':str(first_upper),
            'scope':'These finite checks validate formulas; the general-n analytic proofs are in the manuscript.'}
    Path(__file__).with_name('framework_verification_result.json').write_text(
        json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
