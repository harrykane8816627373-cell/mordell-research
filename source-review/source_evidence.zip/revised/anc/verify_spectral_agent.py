"""Exact arithmetic checks for the new spectral formulas (standard library)."""
from fractions import Fraction
from itertools import permutations
from math import factorial, prod, comb


def check_first_level(n):
    coeff = {}
    for p in permutations(range(n)):
        inv = sum(p[i] > p[j] for i in range(n) for j in range(i + 1, n))
        coeff[p] = (-1) ** inv
    shifted = []
    for i in range(n):
        col = {}
        for p, c in coeff.items():
            t = list(p)
            t[i] += 1
            col[tuple(t)] = c
        shifted.append(col)
    gaussian_gram = []
    for i in range(n):
        row = []
        for j in range(n):
            val = sum(c * shifted[j].get(a, 0) * prod(factorial(t) for t in a)
                      for a, c in shifted[i].items())
            row.append(val)
        gaussian_gram.append(row)
    c1 = factorial(n) * prod(factorial(k) for k in range(n))
    for i in range(n):
        for j in range(n):
            expected = Fraction((n + 1) * c1, 2) if i == j else -Fraction(c1, 2)
            if gaussian_gram[i][j] != expected:
                raise RuntimeError((n, i, j, gaussian_gram[i][j], expected))
    N = n * (n - 1) // 2
    l0 = Fraction(c1, factorial(N))
    l1 = Fraction((n + 2) * c1, 2 * factorial(N + 1))
    if l1 / l0 != Fraction(n + 2, 2 * (N + 1)):
        raise RuntimeError("First spectral-level factor failed")
    return str(l1)


def add(*polys):
    out = {}
    for p in polys:
        for a, c in p.items():
            out[a] = out.get(a, 0) + c
    return {a: c for a, c in out.items() if c}


def scale(p, c):
    return {a: c * b for a, b in p.items()}


def mul(p, q):
    out = {}
    for a, c in p.items():
        for b, d in q.items():
            t = tuple(x + y for x, y in zip(a, b))
            out[t] = out.get(t, 0) + c * d
    return {a: c for a, c in out.items() if c}


def conjugate(p):
    return {(a[2], a[3], a[0], a[1]): c for a, c in p.items()}


def abs_square(p):
    return mul(p, conjugate(p))


def check_three_sos():
    # Variables are formally u, v, conjugate(u), conjugate(v).
    u2vbar = {(2, 0, 0, 1): 1}
    ubarv2 = {(0, 2, 1, 0): 1}
    q = {(1, 0, 1, 0): 1, (0, 1, 0, 1): 1}
    f = {(3, 0, 0, 0): 1, (0, 3, 0, 0): 1}
    left = add(mul(mul(q, q), q), scale(abs_square(f), -1))
    right = add(abs_square(add(u2vbar, scale(ubarv2, -1))),
                scale(abs_square(u2vbar), 2), scale(abs_square(ubarv2), 2))
    if left != right:
        raise RuntimeError("Mixed real-SOS identity failed")
    # Independent coefficient calculation for A_r^* A_r, r=1,2.
    for r, expected in [(1, [Fraction(5, 4)] * 2),
                        (2, [Fraction(11, 10), Fraction(4, 5), Fraction(11, 10)])]:
        columns = []
        for j in range(r + 1):
            # Exponents of v in the two terms of u^(r-j) v^j f.
            columns.append({j: 1, j + 3: 1})
        gram = []
        for i, col in enumerate(columns):
            row = []
            for j, other in enumerate(columns):
                # Off-diagonal support is disjoint at these two levels.
                overlap = set(col) & set(other)
                if i != j and overlap:
                    raise RuntimeError("Unexpected overlapping support")
                row.append(sum(Fraction(comb(r, i), comb(r + 3, k))
                               for k in overlap) if i == j else Fraction(0))
            gram.append(row)
        if [gram[j][j] for j in range(r + 1)] != expected:
            raise RuntimeError((r, gram, expected))


if __name__ == "__main__":
    check_three_sos()
    for n in range(2, 8):
        print(f"n={n}: exact centered first-level eigenvalue {check_first_level(n)}")
    print("PASS: Gaussian Gram entries, first-level factors, n=3 matrices, and mixed SOS.")
