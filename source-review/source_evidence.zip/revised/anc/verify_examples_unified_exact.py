#!/usr/bin/env python3
"""Exact stdlib checks accompanying examples_unified_exact.tex.

The global proofs are in the TeX fragment. This checker verifies their
polynomial identities, independently checks the n=5 quartic comparisons,
and exercises the bordered trace test. It does not replace the complete
n5_complete_verification.py classification.
"""
from fractions import Fraction as Q
from pathlib import Path
import json


def require(condition, message):
    if not condition:
        raise ArithmeticError(message)


def trim(p):
    p = [Q(x) for x in p]
    while len(p) > 1 and p[-1] == 0:
        p.pop()
    return p


def padd(p, q):
    return trim([(p[i] if i < len(p) else 0) +
                 (q[i] if i < len(q) else 0)
                 for i in range(max(len(p), len(q)))])


def pmul(p, q):
    r = [Q(0)] * (len(p) + len(q) - 1)
    for i, a in enumerate(p):
        for j, b in enumerate(q):
            r[i + j] += a * b
    return trim(r)


def pdiv(p, q):
    p, q = trim(p), trim(q)
    require(q != [0], 'zero polynomial divisor')
    result = [Q(0)] * max(1, len(p) - len(q) + 1)
    while p != [0] and len(p) >= len(q):
        j, a = len(p) - len(q), p[-1] / q[-1]
        result[j] += a
        p = padd(p, [Q(0)] * j + [-a * b for b in q])
    return trim(result), p


def deriv(p):
    return trim([i * p[i] for i in range(1, len(p))] or [0])


def peval(p, x):
    y = Q(0)
    for a in reversed(p):
        y = y * x + a
    return y


def sturm(p):
    chain = [trim(p), deriv(p)]
    while chain[-1] != [0]:
        remainder = pdiv(chain[-2], chain[-1])[1]
        if remainder == [0]:
            break
        chain.append([-x for x in remainder])
    return chain


def sign(x):
    return (x > 0) - (x < 0)


def variations(chain, x=None, infinity=0):
    if infinity:
        signs = [sign(p[-1]) * (-1 if infinity < 0 and
                 (len(p) - 1) % 2 else 1) for p in chain]
    else:
        signs = [sign(peval(p, x)) for p in chain]
    signs = [s for s in signs if s]
    return sum(a != b for a, b in zip(signs, signs[1:]))


def root_count(chain, lo, hi):
    return variations(chain, lo) - variations(chain, hi)


def interval_mul(a, b):
    products = [x * y for x in a for y in b]
    return min(products), max(products)


def interval_eval(p, interval):
    out = (Q(0), Q(0))
    for a in reversed(p):
        out = interval_mul(out, interval)
        out = out[0] + a, out[1] + a
    return out


def det(matrix):
    a = [[Q(x) for x in row] for row in matrix]
    product = Q(1)
    for j in range(len(a)):
        k = next((k for k in range(j, len(a)) if a[k][j]), None)
        if k is None:
            return Q(0)
        if k != j:
            a[j], a[k] = a[k], a[j]
            product = -product
        pivot = a[j][j]
        product *= pivot
        for k in range(j + 1, len(a)):
            ratio = a[k][j] / pivot
            for col in range(j + 1, len(a)):
                a[k][col] -= ratio * a[j][col]
    return product


def resultant(p, q):
    m, n = len(p) - 1, len(q) - 1
    rows = []
    for poly, repetitions in ((p, n), (q, m)):
        for j in range(repetitions):
            row = [Q(0)] * (m + n)
            row[j:j + len(poly)] = list(reversed(poly))
            rows.append(row)
    return det(rows)


def quotient_power(p, a, k):
    result = [Q(1)]
    for _ in range(k):
        result = pdiv(pmul(result, a), p)[1]
    return result


def trace_basis(p):
    n = len(p) - 1
    sums = [Q(n)]
    for k in range(1, n):
        sums.append(-sum(p[n - j] * sums[k - j]
                         for j in range(1, k)) - k * p[n - k])
    return sums


def bordered_trace(p, r):
    n = len(p) - 1
    sums = trace_basis(p)
    out = []
    for j in range(n + 1):
        row = []
        tj = quotient_power(p, [0, 1], j)
        for k in range(n + 1):
            rk = quotient_power(p, r, k)
            remainder = pdiv(pmul(tj, rk), p)[1]
            row.append(sum(a * sums[i] for i, a in enumerate(remainder)))
        out.append(row)
    return out


def sparse_add(p, q):
    r = dict(p)
    for m, a in q.items():
        r[m] = r.get(m, 0) + a
        if not r[m]:
            del r[m]
    return r


def sparse_scale(p, a):
    return {m: a * b for m, b in p.items() if a * b}


def sparse_mul(p, q):
    r = {}
    for m, a in p.items():
        for n, b in q.items():
            monomial = tuple(i + j for i, j in zip(m, n))
            r[monomial] = r.get(monomial, 0) + a * b
    return {m: a for m, a in r.items() if a}


def sparse_power(p, k):
    result = {(0,) * len(next(iter(p))): 1}
    for _ in range(k):
        result = sparse_mul(result, p)
    return result


def variable(d, j):
    m = [0] * d
    m[j] = 1
    return {tuple(m): 1}


def difference(p, q):
    return sparse_add(p, sparse_scale(q, -1))


def conjugate_four(p):
    return {(m[1], m[0], m[3], m[2]): a for m, a in p.items()}


def verify_identities():
    # n=3: treat u, conjugate(u), v, conjugate(v) as independent variables.
    u, ub, v, vb = [variable(4, j) for j in range(4)]
    norm = sparse_add(sparse_mul(u, ub), sparse_mul(v, vb))
    f = sparse_add(sparse_power(u, 3), sparse_power(v, 3))
    lhs = difference(sparse_power(norm, 3), sparse_mul(f, conjugate_four(f)))
    g = difference(sparse_mul(sparse_power(u, 2), vb),
                   sparse_mul(ub, sparse_power(v, 2)))
    g1 = sparse_mul(sparse_power(u, 2), vb)
    g2 = sparse_mul(ub, sparse_power(v, 2))
    rhs = sparse_mul(g, conjugate_four(g))
    for h in (g1, g2):
        rhs = sparse_add(rhs, sparse_scale(sparse_mul(h, conjugate_four(h)), 2))
    require(lhs == rhs, 'n=3 mixed SOS identity')

    # n=4: Hadamard representation and its exact Vandermonde factorization.
    a, b, c = [variable(3, j) for j in range(3)]
    z = [sparse_add(sparse_add(a, b), c),
         difference(difference(a, b), c),
         difference(difference(b, a), c),
         difference(c, sparse_add(a, b))]
    vandermonde = {(0, 0, 0): 1}
    for i in range(4):
        for j in range(i + 1, 4):
            vandermonde = sparse_mul(vandermonde, difference(z[i], z[j]))
    squares = [sparse_power(x, 2) for x in (a, b, c)]
    factored = sparse_scale(sparse_mul(sparse_mul(difference(squares[0], squares[1]),
                          difference(squares[0], squares[2])),
                          difference(squares[1], squares[2])), 64)
    require(vandermonde == factored, 'n=4 Vandermonde factorization')
    # The three rows of the linear representation are orthogonal, norm^2=4.
    linear = [[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]]
    require([[sum(row[i] * row[j] for row in linear) for j in range(3)]
             for i in range(3)] == [[4, 0, 0], [0, 4, 0], [0, 0, 4]],
            'n=4 quadratic moment identity')
    x, y, zz = [variable(3, j) for j in range(3)]
    dxy = sparse_add(sparse_add(sparse_power(x, 2), sparse_mul(x, y)), sparse_power(y, 2))
    dxz = sparse_add(sparse_add(sparse_power(x, 2), sparse_mul(x, zz)), sparse_power(zz, 2))
    numerator = difference(sparse_mul(y, dxz), sparse_mul(zz, dxy))
    factor = sparse_mul(difference(y, zz), difference(sparse_power(x, 2), sparse_mul(y, zz)))
    require(numerator == factor, 'n=4 imaginary-force factor identity')
    require(Q(1, 27) < Q(1, 16), 'interior/boundary comparison')


def verify_n5_comparison():
    quartic = [6, -97, 140, -65, 10]
    chain = sturm(quartic)
    require(variations(chain, infinity=-1) - variations(chain, infinity=1) == 2,
            'n=5 quartic has exactly two real roots')
    h_intervals = [(Q(68395128919, 10**12), Q(68395128920, 10**12)),
                   (Q(1214112777579, 10**12), Q(1214112777580, 10**12))]
    delta = [Q(1084589409375, 385875968),
             -Q(1391385515625, 192937984),
             Q(2547927984375, 385875968),
             -Q(321987234375, 192937984)]
    output = []
    for interval, integer_lo, integer_hi in zip(h_intervals, (2347, 801), (2348, 802)):
        require(root_count(chain, *interval) == 1, 'quartic isolation interval')
        enclosure = interval_eval(delta, interval)
        require(integer_lo < enclosure[0] <= enclosure[1] < integer_hi < 3125,
                'strict n=5 nonclassical discriminant bound')
        output.append({'H_interval': [str(x) for x in interval],
                       'Delta_interval': [str(x) for x in enclosure]})
    require(Q(9765625, 4096) < 3125 and Q(84375, 1024) < 3125,
            'n=5 classical comparisons')
    return output


def verify_trace_examples():
    output = []
    for n in range(2, 8):
        p = [-1] + [0] * (n - 1) + [1]
        r = [0] * (n - 1) + [1]
        lam = Q(n - 1, 2)
        remainder = pdiv(padd(deriv(deriv(p)),
                    [-2 * lam * x for x in pmul(r, deriv(p))]), p)[1]
        require(remainder == [0], 'regular polygon force congruence')
        matrix = bordered_trace(p, r)
        expected = [[Q(n) if (j - k) % n == 0 else Q(0)
                     for k in range(n + 1)] for j in range(n + 1)]
        require(matrix == expected, 'regular polygon bordered Gram identity')
        require(det([row[:n] for row in matrix[:n]]) == n**n,
                'regular polygon Gram determinant')
        require(abs(resultant(p, deriv(p))) == n**n,
                'regular polygon discriminant identity')
        output.append({'n': n, 'lambda': str(lam), 'det_H': n**n})
    bad = bordered_trace([-4, 0, 1], [0, Q(1, 8)])
    require(bad[0][:2] == [2, 0] and bad[1][:2] == [0, 1],
            'unbordered spurious test H is positive')
    require(bad[2][0] == 8 and bad[0][2] == Q(1, 8),
            'border detects wrong pairing')
    require(pdiv(padd([2], [-2 * x for x in pmul([0, Q(1, 8)], [0, 2])]),
                 [-4, 0, 1])[1] == [0], 'spurious force congruence')
    return output


def exact_output_examples():
    output = []
    for n, value in [(n, Q(n**n)) for n in range(2, 6)] + [(6, Q(6**15, 5**10)), (7, Q(7**21,6**15))]:
        floor = value.numerator // value.denominator
        lo, hi = (floor - 1, floor + 1) if value.denominator == 1 else (floor, floor + 1)
        polynomial = [-value.numerator, value.denominator]
        require(peval(polynomial, value) == 0, 'exact output polynomial')
        require(root_count(sturm(polynomial), Q(lo), Q(hi)) == 1,
                'exact output isolating interval')
        output.append({'n': n, 'M_n': str(value),
                       'primitive_minimal_polynomial_ascending': polynomial,
                       'open_isolating_interval': [str(lo), str(hi)]})
    central = [0, -1, 0, 0, 0, 0, 1]
    require(abs(resultant(central, deriv(central))) == 5**5,
            'central pentagon shape discriminant')
    require(Q(5**5) * Q(6, 5)**15 == Q(6**15, 5**10),
            'central pentagon normalized objective')
    central7 = [0, -1, 0, 0, 0, 0, 0, 1]
    conjugate7 = [0, 0, 0, 0, 0, 1]
    require(pdiv(padd(deriv(deriv(central7)),
                     [-7*x for x in pmul(conjugate7,deriv(central7))]),
                 central7)[1] == [0], 'central hexagon exact force congruence')
    require(abs(resultant(central7,deriv(central7))) == 6**6,
            'central hexagon exact discriminant')
    central7_trace=bordered_trace(central7,conjugate7)
    require(det([row[:7] for row in central7_trace[:7]]) == 6**6,
            'central hexagon physical bordered Gram determinant')
    require(Q(6**6)*Q(7,6)**21 == Q(7**21,6**15),
            'central hexagon normalized value')
    return output


def main():
    verify_identities()
    data = {'n5_quartic_comparisons': verify_n5_comparison(),
            'bordered_trace_regular_polygons': verify_trace_examples(),
            'exact_value_output_examples': exact_output_examples(),
            'status': 'ALL EXACT STDLIB CHECKS PASSED',
            'scope': ('Global completeness for n=5 uses the separately executed '
                      'n5_complete_verification.py; n=6 and n=7 use their exact disk '
                      'certificates with the explicitly cited external coverage inputs.')}
    path = Path(__file__).with_name('examples_unified_exact_checks.json')
    path.write_text(json.dumps(data, indent=2), encoding='utf-8')
    print(data['status'])
    for item in data['exact_value_output_examples']:
        print('n=', item['n'], 'M=', item['M_n'],
              'polynomial=', item['primitive_minimal_polynomial_ascending'],
              'interval=', item['open_isolating_interval'])


if __name__ == '__main__':
    main()
