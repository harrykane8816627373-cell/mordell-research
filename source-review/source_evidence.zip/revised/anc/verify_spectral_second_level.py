"""Independently check all quadratic blocks by exact Gaussian coefficients.

No numerical eigenvalue calculation is used. We verify a complete block
congruence with the Bombieri metric, and directly check every moment class
against the determinant expansion, for n=3,...,7.
"""
from fractions import Fraction as Q
from itertools import permutations, combinations
from math import factorial, prod


def monomial(n, indices):
    a = [0] * n
    for i in indices:
        a[i] += 1
    return tuple(a)


def polynomial(n, terms):
    out = {}
    for i, j, c in terms:
        a = monomial(n, [i, j])
        out[a] = out.get(a, Q(0)) + c
    return {a: c for a, c in out.items() if c}


def nullspace(mat):
    a = [[Q(x) for x in row] for row in mat]
    rows, cols = len(a), len(a[0])
    pivots = []
    rank = 0
    for j in range(cols):
        p = next((i for i in range(rank, rows) if a[i][j]), None)
        if p is None:
            continue
        a[rank], a[p] = a[p], a[rank]
        q = a[rank][j]
        a[rank] = [x / q for x in a[rank]]
        for i in range(rows):
            if i != rank and a[i][j]:
                q = a[i][j]
                a[i] = [x - q * y for x, y in zip(a[i], a[rank])]
        pivots.append(j)
        rank += 1
        if rank == rows:
            break
    basis = []
    for j in range(cols):
        if j in pivots:
            continue
        v = [Q(0)] * cols
        v[j] = Q(1)
        for i, p in enumerate(pivots):
            v[p] = -a[i][j]
        basis.append(v)
    return rank, basis


def direct_moment(coeff, alpha, beta, normalizer):
    shifted = {tuple(x+y for x, y in zip(a, beta)): c for a, c in coeff.items()}
    out = 0
    for a, c in coeff.items():
        t = tuple(x+y for x, y in zip(a, alpha))
        out += c * shifted.get(t, 0) * prod(factorial(x) for x in t)
    return Q(out, normalizer)


def moment_class(alpha, beta, moments):
    ia = [i for i, x in enumerate(alpha) if x]
    ib = [i for i, x in enumerate(beta) if x]
    if len(ia) == 1 and len(ib) == 1:
        return moments['a' if ia == ib else 'b']
    if len(ia) == 1 or len(ib) == 1:
        return moments['d' if set(ia) & set(ib) else 'e']
    overlap = len(set(ia) & set(ib))
    return moments[{2: 'c', 1: 'g', 0: 'h'}[overlap]]


def gram(p, q, moments):
    return sum(c * d * moment_class(a, b, moments)
               for a, c in p.items() for b, d in q.items())


def bombieri(p, q):
    return sum(c * q.get(a, Q(0)) * prod(factorial(t) for t in a) / 2
               for a, c in p.items())


def check(n):
    coeff = {}
    for p in permutations(range(n)):
        inv = sum(p[i] > p[j] for i in range(n) for j in range(i + 1, n))
        coeff[p] = (-1) ** inv
    c1 = factorial(n) * prod(factorial(k) for k in range(n))
    moments = {'a': Q((n+1)*(n+2), 3), 'b': -Q(n-2, 3),
               'c': Q((n+1)*(3*n+2), 12), 'd': -Q(n+1, 3),
               'e': Q(2, 3), 'g': -Q(3*n+1, 12), 'h': Q(1, 2)}
    representatives = {'a': ([0, 0], [0, 0]), 'b': ([0, 0], [1, 1]),
                       'c': ([0, 1], [0, 1]), 'd': ([0, 0], [0, 1]),
                       'e': ([0, 0], [1, 2]), 'g': ([0, 1], [0, 2])}
    if n >= 4:
        representatives['h'] = ([0, 1], [2, 3])
    for name, (a, b) in representatives.items():
        value = direct_moment(coeff, monomial(n, a), monomial(n, b), c1)
        if value != moments[name]:
            raise RuntimeError((n, name, value, moments[name]))

    # Complete quadratic basis: q_H, n-1 standard vectors, row-null edges.
    trivial = polynomial(n, [(i, i, Q(1)) for i in range(n)]
                         + [(i, j, -Q(1, n)) for i in range(n) for j in range(n)])
    standard = []
    for i in range(n - 1):
        j = n - 1
        standard.append(polynomial(n, [(i, i, Q(1)), (j, j, Q(-1))]
                                   + [(i, k, -Q(2, n)) for k in range(n)]
                                   + [(j, k, Q(2, n)) for k in range(n)]))
    edges = list(combinations(range(n), 2))
    rank, edge_basis = nullspace([[int(i in e) for e in edges] for i in range(n)])
    if rank != n or len(edge_basis) != n*(n-3)//2:
        raise RuntimeError("Incorrect complete-graph incidence rank")
    complement = [polynomial(n, [(i, j, a) for (i, j), a in zip(edges, v) if a])
                  for v in edge_basis]
    basis = [trivial] + standard + complement
    if len(basis) != n*(n-1)//2:
        raise RuntimeError("Incomplete centered quadratic basis")
    ratios = [Q(2*(n+1))] + [Q(n*n+6*n+6, 3)]*(n-1)
    ratios += [Q((3*n+5)*(n+2), 6)]*len(complement)
    for i, p in enumerate(basis):
        if not bombieri(p, p) > 0:
            raise RuntimeError("Zero basis vector")
        for j, q in enumerate(basis):
            ordinary = bombieri(p, q)
            weighted = gram(p, q, moments)
            if weighted != ratios[i] * ordinary:
                raise RuntimeError((n, i, j, weighted, ratios[i] * ordinary))
            if ratios[i] != ratios[j] and ordinary:
                raise RuntimeError("Blocks not Bombieri orthogonal")
    # Since the three within-block bases are independent by construction,
    # the checked full congruence certifies every eigenvalue and multiplicity.
    print(f"n={n}: full spectrum factors "
          f"{Q(2*(n+1))} [1], {Q(n*n+6*n+6, 3)} [{n-1}], "
          f"{Q((3*n+5)*(n+2), 6)} [{n*(n-3)//2}]")


if __name__ == '__main__':
    for n in range(3, 8):
        check(n)
    print('PASS: all labeled moments and complete quadratic block spectra.')
