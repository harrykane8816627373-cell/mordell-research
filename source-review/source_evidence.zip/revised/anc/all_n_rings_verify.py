"""Exact rational polar-ring lower bounds; no numerical dependency.

For every n, inner ring j has 6j points and squared radius 6j^2/n.
If r=n-3k(k+1)>0, add r outer points at squared radius (n+3k(k+1))/n.
All phases are zero. A population-one outer ring is permitted.
This is an attainable lower bound, not a claim of global optimality.
"""
import argparse, hashlib, json, math
from fractions import Fraction as F
from pathlib import Path

def data(n):
    if n<2:raise ValueError('n must be at least two')
    k=0
    while 3*(k+1)*(k+2)<=n:k+=1
    n0=3*k*(k+1);r=n-n0
    rings=[(6*j,6*j*j) for j in range(1,k+1)]
    if r:rings.append((r,n+n0))
    if sum(m for m,a in rings)!=n:raise ArithmeticError('Population mismatch')
    if sum(F(m*a,n) for m,a in rings)!=n:raise ArithmeticError('Moment mismatch')
    if any(a<=0 for m,a in rings):raise ArithmeticError('Nonpositive radius')
    if any(a>=b for (m,a),(mm,b) in zip(rings,rings[1:])):raise ArithmeticError('Rings not strictly ordered')
    return k,n0,r,rings

def polar_value(n):
    k,n0,r,rings=data(n);N=n*(n-1)//2
    integer=1
    for m,a in rings:integer*=m**m*a**(m*(m-1)//2)
    for j,(m,a) in enumerate(rings):
        for mm,b in rings[j+1:]:
            g=math.gcd(m,mm);L=m*mm//g
            if L%2:raise ArithmeticError('Unexpected odd cross exponent')
            integer*=(b**(L//2)-a**(L//2))**(2*g)
    value=F(integer,n**N)
    if value<=0:raise ArithmeticError('Collision or nonpositive value')
    return value

def central_value(n):return F((n-1)**(n-1))*F(n,n-1)**(n*(n-1)//2)

def exp_lower(q,terms):return sum((q**j/F(math.factorial(j)) for j in range(terms+1)),F(0))

def log_bounds(q,terms=32):
    """Exact logarithm interval using positive atanh series, q >= 1."""
    if q<1:
        lo,hi=log_bounds(1/q,terms);return -hi,-lo
    t=(q-1)/(q+1)
    lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(terms)),F(0))
    tail=2*t**(2*terms+1)/(F(2*terms+1)*(1-t*t)) if t else F(0)
    return lo,lo+tail

def integer_hash(x):return hashlib.sha256(x.to_bytes((x.bit_length()+7)//8,'big')).hexdigest()

def verify(max_n):
    # Constants used in the uniform analytic remainder and threshold proof.
    l2,u2=log_bounds(F(2));l6,u6=log_bounds(F(6),80)
    if not F(17,25)<l2<=u2<F(7,10):raise ArithmeticError('log 2 bounds failed')
    if not l6>F(17,10):raise ArithmeticError('log 6 lower bound failed')
    if not exp_lower(F(6,5),5)>F(33,10):raise ArithmeticError('Outer correction estimate failed')
    if not exp_lower(F(3),8)>20:raise ArithmeticError('Outer correction denominator failed')
    if not exp_lower(F(6),6)>100:raise ArithmeticError('Base correction bound failed')
    if not exp_lower(F(9,2),8)>36:raise ArithmeticError('log n <= n/8 starting bound failed')
    if not F(12)*F(10,33)/((1-F(10,33))*(1-F(1,20)))<6:raise ArithmeticError('Near-ring constant failed')
    if not F(12)*F(1,64)/(1-F(1,64))**3<1:raise ArithmeticError('Far-ring constant failed')
    if not F(12)*F(1,100)*(1+F(1,100))/(1-F(1,100))**4<1:raise ArithmeticError('Base constant failed')
    # Analytic threshold polynomial is increasing beyond 80 and positive there.
    if not F(11,400)*80**2-2*80-9>0:raise ArithmeticError('Large-n threshold failed')
    rows=[]
    for n in range(2,max_n+1):
        value=polar_value(n);central=central_value(n);ratio=value/central
        k,n0,r,rings=data(n)
        if n<=5 and value!=n**n:raise ArithmeticError('Small-n polygon check failed')
        if n==6 and value!=6**6:raise ArithmeticError('Hexagon check failed')
        if n==18:
            explicit=F(2**162*455**12,3**111)
            if value!=explicit or not ratio>970:raise ArithmeticError('Eighteen-point bound failed')
        if 13<=n<80 and not value>central:raise ArithmeticError('Finite threshold comparison failed')
        rows.append({'n':n,'k':k,'remainder_population':r,'above_central':value>central,
                     'ratio_integer_lower':ratio.numerator//ratio.denominator,
                     'value_numerator_sha256':integer_hash(value.numerator),
                     'value_denominator_sha256':integer_hash(value.denominator)})
    if max_n<79:raise ValueError('Verification must include the full finite threshold range through 79')
    output={'verified_through_n':max_n,'exact_comparisons':len(rows),
            'eighteen_point_value':'2^162*455^12/3^111','eighteen_point_ratio_above':970,
            'all_n_ge_13_above_central':True,
            'large_n_proof':'Analytic uniform remainder and rational threshold polynomial for n>=80; exact n=13..79 comparisons.',
            'rows':rows}
    (Path(__file__).resolve().parent/'all_n_rings_exact_result.json').write_text(json.dumps(output,indent=2))
    print('EXACT verification passed:',{k:v for k,v in output.items() if k!='rows'})
    print('Small-n failures of this particular construction:',[r['n'] for r in rows if not r['above_central'] and r['n']>=6])

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--max-n',type=int,default=120);args=parser.parse_args()
    verify(args.max_n)
