"""Exact subset identities and rational recursive enclosures; standard library."""
from fractions import Fraction as F
from itertools import combinations
from math import comb, isqrt, factorial
from pathlib import Path
import json
import random

def require(condition, message):
    if not condition:
        raise ArithmeticError(message)

def dist2(a, b):
    return (a[0]-b[0])**2 + (a[1]-b[1])**2

def product(values):
    out = F(1)
    for value in values:
        out *= value
    return out

def centered_moment(points):
    m = len(points)
    return sum((dist2(a, b) for a, b in combinations(points, 2)), F(0))/m

def delta(points):
    return product(dist2(a, b) for a, b in combinations(points, 2))

def root_upper(value, degree=3, scale=10**6):
    lo, hi = 0, 1
    target = value*scale**degree
    while hi**degree < target:
        hi *= 2
    while lo+1 < hi:
        mid = (lo+hi)//2
        if mid**degree < target:
            lo = mid
        else:
            hi = mid
    require(F(hi, scale)**degree >= value, 'root enclosure')
    return F(hi, scale)

rng = random.Random(20261005)
checks = 0
for n in range(3, 9):
    for sample in range(8):
        points = []
        while len(points) < n:
            point = (F(rng.randint(-9, 9), 3), F(rng.randint(-9, 9), 5))
            if point not in points:
                points.append(point)
        q = centered_moment(points)
        whole = delta(points)
        for m in range(2, n):
            subsets = list(combinations(points, m))
            moments = [centered_moment(s) for s in subsets]
            require(sum(moments)/comb(n, m) == F(m-1, n-1)*q, 'mean subset moment')
            require(product(delta(s) for s in subsets) == whole**comb(n-2, m-2), 'subset discriminant product')
            require(product(moments) <= (sum(moments)/len(moments))**len(moments), 'rational AMGM')
            checks += 3
        cx = sum(p[0] for p in points)/n
        cy = sum(p[1] for p in points)/n
        points = [(p[0]-cx, p[1]-cy) for p in points]
        for i in range(n):
            t = points[i][0]**2+points[i][1]**2
            require(centered_moment(points[:i]+points[i+1:]) == q-F(n, n-1)*t, 'deleted moment identity')
            checks += 1

for n in range(3, 101):
    lam, kap = F(n-1, 2), F((n-1)**2, 2*n)
    require(lam-kap == F(n-1, 2*n), 'force difference z coefficient')
    require(kap/F(n-1) == F(n-1, 2*n), 'force difference deleted coefficient')
    checks += 2

rows = []
compact_margins = []
for n in range(2, 101):
    a = isqrt(n-1)
    if a*a < n-1:
        a += 1
    new_mu = F(1, n*(1+a)**(2*(n-1)))
    old_mu = F(1, n**(2*n-1))
    new_aux = n*a*(1+a)**(n-1)
    old_aux = (n-1)*n**n
    require(new_mu >= old_mu and new_aux <= old_aux, 'compact bound improvement')
    checks += 2
    if n in (4, 6, 10):
        compact_margins.append({'n':n, 'new_mu':str(new_mu), 'old_mu':str(old_mu), 'new_aux':new_aux, 'old_aux':old_aux})
for n in range(7, 21):
    N = n*(n-1)//2
    cubed_bound = F(5**N)*F(n, n-1)**(3*N)
    upper = root_upper(cubed_bound)
    c_n = F(n**N, (n-1)**(N-n+1))
    require(c_n**3 < cubed_bound, 'central polygon versus deletion bound')
    alpha = F(n-1, 2)
    partial_exp = sum((alpha**j/factorial(j) for j in range(n)), F(0))
    P = product(factorial(j) for j in range(n))
    hadamard = P*partial_exp**n/alpha**N
    rows.append({'n':n, 'six_seed_upper':str(upper), 'hadamard_at_half_n_minus_one':str(hadamard), 'better_bound':'six_seed' if upper<hadamard else 'hadamard'})

boxes = []
for q in range(1, 101):
    r = isqrt(2*q*q)
    if r*r < 2*q*q:
        r += 1
    require((r-1)**2 < 2*q*q <= r*r, 'minimal fixed disk box')
    checks += 1
    if q in (6, 10, 20):
        boxes.append({'q':q, 'R':r})

result = {'checks':checks, 'status':'passed', 'n_range_exact_subset_checks':[3,8], 'fixed_disk_boxes':boxes, 'compact_margins':compact_margins, 'recursive_bounds':rows, 'proof_scope':'Exact identities are independently checked; analytic maximum-modulus and Jensen proofs are in all_n_deletion_radius.tex.'}
target = Path(__file__).with_name('all_n_deletion_result.json')
target.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'status':result['status'], 'checks':checks, 'fixed_disk_boxes':boxes, 'recursive_bound_n7':str(root_upper(F(5**21)*F(7,6)**63))}, indent=2))
