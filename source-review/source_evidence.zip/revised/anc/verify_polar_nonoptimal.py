"""Rational certificate: the explicit polar family loses at linear order."""
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import json

def require(condition, message):
    if not condition:
        raise ArithmeticError(message)

# Gamma(1/3)=3*integral_0^infinity exp(-u^3) du. An odd Taylor
# truncation is below exp(-u^3) everywhere, so integrate it over [0,2].
gamma_integral_lower = 3*sum((F((-1)**j*2**(3*j+1), (3*j+1)*factorial(j))
                            for j in range(42)), F(0))
gamma_lower = F(26788, 10000)
require(gamma_integral_lower > gamma_lower, 'Gamma rational lower bound')
e_lower = sum((F(1, factorial(j)) for j in range(11)), F(0))

def atan_partial(x, last_index):
    return sum((F((-1)**j)*x**(2*j+1)/(2*j+1) for j in range(last_index+1)), F(0))

# Machin identity and alternating-series outward bound.
pi_series_upper = 16*atan_partial(F(1,5), 10)-4*atan_partial(F(1,239), 9)
pi_upper = F(355,113)
require(pi_series_upper < pi_upper, 'Pi outward upper bound')
ratio_squared_lower = gamma_lower**6*e_lower/(32*pi_upper**3)
require(ratio_squared_lower > F(100,99), 'linear gap greater than 1/200')
# e^(1/100) < 1/(1-1/100)=100/99. Thus
# gamma_triangle-gamma_polar = (1/2)*log(Gamma(1/3)^6*e/(32*pi^3)) > 1/200.
result={'status':'passed', 'Gamma_1_3_lower':str(gamma_lower),
        'Gamma_integral_lower':str(gamma_integral_lower),
        'e_lower':str(e_lower), 'pi_upper':str(pi_upper),
        'ratio_squared_lower':str(ratio_squared_lower),
        'linear_gap_strictly_above':'1/200',
        'scope':'Uses the proved polar asymptotic and the external triangular trial-energy lower bound; no floating comparisons.'}
Path(__file__).with_name('polar_nonoptimal_result.json').write_text(json.dumps(result,indent=2)+'\n', encoding='utf-8')
print('Exact polar nonoptimality certificate passed; asymptotic linear gap > 1/200.')
