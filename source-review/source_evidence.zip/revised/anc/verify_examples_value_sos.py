"""Standard-library exact arithmetic for the three-point value certificate."""
from fractions import Fraction as F
from pathlib import Path
import json

def trim(p):
    while len(p)>1 and p[-1] == 0: p.pop()
    return p
def add(p,q):
    return trim([(p[j] if j<len(p) else F(0))+(q[j] if j<len(q) else F(0)) for j in range(max(len(p),len(q)))])
def scale(p,c): return trim([c*x for x in p])
def mul(p,q):
    r=[F(0)]*(len(p)+len(q)-1)
    for j,x in enumerate(p):
        for k,y in enumerate(q): r[j+k]+=x*y
    return trim(r)
def divmodpoly(p,q):
    r=trim(p[:])
    s=[F(0)]*max(1,len(p)-len(q)+1)
    while len(r)>=len(q) and any(r):
        k=len(r)-len(q)
        c=r[-1]/q[-1]
        s[k]+=c
        r=add(r,[F(0)]*k+scale(q,-c))
    return trim(s),trim(r)
def check(ok,label):
    if not ok: raise ArithmeticError(label)

t=[F(0),F(1)]
p=mul([F(-27),F(1)],[F(-27),F(2)])
E=[F(2),F(-2,27)]
sos=add(add(mul(scale(E,F(3)),scale(E,F(3))),
            mul(scale(E,F(3,2)),scale(E,F(3,2)))),
        mul(scale(E,F(3,2)),scale(E,F(3,2))))
check(add(sos,scale(p,F(-1,27))) == [F(27),F(-1)], 'exact global SOS identity')
for value in [F(27),F(27,2)]:
    check((value-27)*(2*value-27)==0,'stationary value polynomial')
    ev=F(2,27)*(27-value)
    check(27-value==9*ev**2+F(9,2)*ev**2,'stationary SOS evaluation')
check(F(3,2)*F(3,2)*6 == F(27,2),'collinear discriminant')
# Coefficients of P''-2tP'+6P for P=t^3+a*t+b are (4a+6)t+6b.
check(4*F(-3,2)+6==0,'collinear force polynomial')

# Four-point certificate: all three values are physically stationary.
four_values=[F(256),F(4096,27),F(1024,27)]
four_p=mul(mul([F(-256),F(1)],[F(-4096),F(27)]),[F(-1024),F(27)])
selectors=[]
for i,ri in enumerate(four_values):
    ei=[F(1)]
    for j,rj in enumerate(four_values):
        if i!=j: ei=mul(ei,scale([-rj,F(1)],1/(ri-rj)))
    selectors.append(ei)
four_sos=[F(0)]
weights=[[F(80,9),F(32,9),F(32,9)],[F(128,9),F(32,9),F(16,9)]]
for ri,ei,ws in zip(four_values[1:],selectors[1:],weights):
    check(sum((w*w for w in ws),F(0))==256-ri,'rational four-square multipliers')
    for w in ws: four_sos=add(four_sos,mul(scale(ei,w),scale(ei,w)))
four_q,four_rem=divmodpoly(add([F(256),F(-1)],scale(four_sos,-1)),four_p)
check(four_rem==[F(0)],'four point exact polynomial remainder')
check(add(four_sos,mul(four_q,four_p))==[F(256),F(-1)],'six-square upper certificate')
for i,ri in enumerate(four_values):
    for j,ej in enumerate(selectors):
        v=F(0)
        for c in reversed(ej): v=v*ri+c
        check(v==int(i==j),'four point Lagrange selector')

result={'status':'passed','checks':20,'M3':27,'all_stationary_values':['27/2','27'],
        'identity':'27-F = (3E)^2 + (3E/2)^2 + (3E/2)^2 - (F-27)(2F-27)/27, E=2(27-F)/27',
        'M4':256,'four_stationary_values':[str(v) for v in four_values],
        'four_value_polynomial':[str(v) for v in four_p],
        'four_selectors':[[str(v) for v in e] for e in selectors],
        'four_certificate_remainder_multiplier':[str(v) for v in four_q],
        'scope':'Exact certificates after the analytically proved stationary-value equations.'}
Path(__file__).with_name('examples_value_sos_result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
