"""Exact three-point critical-value ideal identities. Standard library only.
This verifies complete n=3 elimination; no n>=4 elimination is asserted.
"""
from fractions import Fraction
from pathlib import Path
import json

def add(*polys):
    out={}
    for p in polys:
        for ij,c in p.items(): out[ij]=out.get(ij,0)+c
    return {ij:c for ij,c in out.items() if c}
def scale(p,c): return {ij:a*c for ij,a in p.items() if a*c}
def mul(p,q):
    out={}
    for (i,j),a in p.items():
        for (k,l),b in q.items():
            ij=(i+k,j+l); out[ij]=out.get(ij,0)+a*b
    return {ij:c for ij,c in out.items() if c}
def power(p,n):
    ans={(0,0):1}
    for _ in range(n): ans=mul(ans,p)
    return ans
def check(ok,message):
    if not ok: raise ArithmeticError(message)

def audit():
    one={(0,0):1}; u={(1,0):1}; v={(0,1):1}; t=mul(u,v)
    G=add(scale(u,6),scale(mul(power(u,2),v),-1),scale(v,3))
    H=add(scale(v,6),scale(mul(power(v,2),u),-1),scale(u,3))
    S=add(mul(v,G),mul(u,H))
    K=mul(t,mul(add(t,scale(one,-3)),add(t,scale(one,-9))))
    Kcert=mul(v,add(mul(add(scale(one,6),scale(t,-1)),G),scale(H,-3)))
    check(K==Kcert,'Critical t ideal identity')
    P=mul(add(one,scale(power(u,2),-1)),add(one,scale(power(v,2),-1)))
    q=add(scale(one,3),t)
    R=mul(add(scale(P,27),scale(power(q,3),-1)),add(scale(P,27),scale(power(q,3),-2)))
    r1=add(scale(power(t,3),-1),scale(t,81))
    r2=add(scale(power(t,3),-2),scale(power(t,2),-9),scale(t,54),scale(one,-27))
    L=mul(add(t,scale(one,9)),add(scale(power(t,2),2),scale(t,15),scale(one,-9)))
    C=add(r1,r2,scale(S,-9))
    AG=add(mul(mul(v,add(scale(one,6),scale(t,-1))),L),scale(mul(v,C),-9))
    AH=add(scale(mul(v,L),-3),scale(mul(u,C),-9))
    check(R==add(mul(AG,G),mul(AH,H)),'Critical value ideal identity')
    values=set()
    for root in (0,3,9):
        val=Fraction(243*(root*root+12*root+3),2*(root+3)**3)
        values.add(val)
        check((2*val-27)*(val-27)==0,'Value eliminant')
    check(values=={Fraction(27,2),Fraction(27)},'Complete value list')
    # Both values have real physical witnesses: third point 0 or i*sqrt(3).
    for x,y,value in ((0,0,Fraction(27,2)),(0,3,Fraction(27))):
        # y denotes squared imaginary coordinate; u=x+i*sqrt(y), v=conjugate(u).
        uv=x*x+y; norm=2+Fraction(2,3)*uv
        product=(1-x*x+y)**2+4*x*x*y
        check(Fraction(108)*product/norm**3==value,'Real physical witness')
    grid=Fraction(49280427,1825346); exponent=Fraction(15,32)
    upper=grid/(1-exponent)
    isolated=[val for val in sorted(values) if grid<=val<=upper]
    check(isolated==[Fraction(27)],'Grid isolates exactly one critical value')
    # All n collinear maxima follow the monic Hermite resultant recurrence.
    collinear=[]
    res=Fraction(1)
    for n in range(2,31):
        res*=Fraction(n-1,2)**(n-1)
        N=n*(n-1)//2
        disc=n**n*res
        powers=1
        for k in range(1,n+1): powers*=k**k
        check(disc==Fraction(powers,2**N),'Hermite discriminant recurrence')
        value=Fraction(powers,(n-1)**N)
        if n==6:
            center=Fraction(6**15,5**10)
            check(value/center==Fraction(2,729),'Six-point collinear exclusion')
        collinear.append({'n':n,'exact_collinear_maximum':str(value)})
    return {'status':'passed','arithmetic':'Integer polynomial ideal identities and Fraction','n3_critical_uv_values':[0,3,9],'n3_critical_values':list(map(str,sorted(values))),'n3_squarefree_eliminant':'(2*T-27)*(T-27)','n3_exact_global_maximum':'27','n3_grid_interval':[str(grid),str(upper)],'grid_interval_unique_critical_value':'27','hermite_resultant_recurrence_checks':collinear,'scope':'Complete n=3 critical-value verification and all-n collinear formula; no unrestricted n>=4 eliminant computed'}
if __name__=='__main__':
    result=audit()
    Path(__file__).with_name('critical_value_result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print('PASS: exact n3 ideal certificate, unique-root global interval, and n2..30 Hermite recurrence.')
