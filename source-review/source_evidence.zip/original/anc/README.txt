Explicit constructions and global bounds for the Mordell discriminant problem
Fengcan Jiang -- 2255214397@stu.xjtu.edu.cn
Research supplement, October 3, 2026; 18-page compiled manuscript

Scope: universal attainable constructions, asymptotic bounds, local certificates,
exact global grid error, a true-conjugate polynomial trace test, and a low-degree
finite terminating exact-value algorithm. The exact elimination is demonstrated
for n=2,3. The unrestricted n=6 maximum and a closed formula for general finite n
are not computed. The origin-containing n=6 subclass and the general collinear
subclass are solved. A degree bound is not a computed eliminant.
The asymptotic and vortex background is classical; priority is not asserted.

Build the standalone main.tex, with its embedded bibliography:
  latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
The built-in editor compiler was unavailable on this host; the supplied PDF
was compiled with the already installed TeX Live 2026 and visually checked.

The ZIP contains main.tex and ancillary programs, results and notes in anc/.
Change into anc/ and run the standard-library checks:
  python -O verify_constructions.py --max-n 30
  python -O verify_hermite.py
  python -O verify_saved_candidates.py
  python -O verify_polygon_perturbations.py
  python -O verify_global_grid.py
  python -O verify_stationary_polynomial.py
  python -O verify_critical_value.py

The new grid checker fully enumerates 1176 n=2,q=2 subsets and 1873200 n=3,q=4
subsets, compares exact rational products, and rejects an invalid mesh bound.
The new trace checker uses Fraction and a cubic algebraic field to check five
true stationary examples and a genuine spurious six-root conjugate pairing.
The new critical-value checker verifies exact n=3 ideal identities, isolates
M_3=27 with the global grid interval, and audits the Hermite discriminant recurrence.
These checks do not constitute complete unrestricted n=6 stationary enumeration.

Optional SageMath eliminant source (not executed here; SageMath is not installed):
  sage -python critical_value_eliminant.sage.py 3
Expected three-point result: t^2 - 81/2*t + 729/2.
The code requires SageMath; syntax has been checked, runtime output is unverified.
Higher-dimensional Groebner elimination may use substantial time and memory.
Other real eliminant roots can be nonphysical: never assume the largest real
root is M_n without a global enclosure or exact real-configuration filtering.

Optional NumPy search:
  python explore_candidates.py
Seed 20261004; 50 Gaussian starts and one central-ring start per n=6,...,12.
This script overwrites numerical_candidates.json. Numerical stationarity and
exact attainable rounded-coordinate products are recorded separately.

The Chinese .md file explains the results and remaining global comparison.
SOURCE_SHA256.json covers the ZIP members. SHA256.json covers delivered files.
No arXiv upload has been performed.
