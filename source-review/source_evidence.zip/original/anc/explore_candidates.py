#!/usr/bin/env python3
"""Numerical exploration only; no global optimality certificate. Requires NumPy."""
import json
from pathlib import Path
from math import log
from fractions import Fraction as F
import numpy as np

SEED=20261004
RANDOM_STARTS=50

def objective(x):
    n=x.size//2
    points=x.reshape(n,2)
    delta=points[:,None,:]-points[None,:,:]
    distances=(delta*delta).sum(2)
    np.fill_diagonal(distances,1)
    if np.any(distances<1e-25):
        return np.inf,np.zeros_like(x)
    f=(n-1)/2*(points*points).sum()-np.log(distances[np.triu_indices(n,1)]).sum()
    gradient=(n-1)*points-2*(delta/distances[:,:,None]).sum(1)
    return f,gradient.ravel()

def optimize(points):
    n=len(points)
    x=(points-points.mean(0)).ravel()
    x*=np.sqrt(n/(x@x))
    inverse=np.eye(2*n)/(n-1)
    f,gradient=objective(x)
    for iteration in range(500):
        if np.linalg.norm(gradient)<2e-8: break
        direction=-inverse@gradient
        if gradient@direction>=0:
            inverse=np.eye(2*n)/(n-1)
            direction=-inverse@gradient
        alpha=1.
        accepted=False
        for _ in range(35):
            xx=x+alpha*direction
            ff,gg=objective(xx)
            if ff<=f+1e-4*alpha*(gradient@direction):
                accepted=True
                break
            alpha*=.5
        if not accepted: break
        step=xx-x
        change=gg-gradient
        ys=change@step
        if ys>1e-12*np.linalg.norm(change)*np.linalg.norm(step):
            rho=1/ys
            hy=inverse@change
            inverse+=((1+(change@hy)*rho)*rho)*np.outer(step,step)-rho*(np.outer(hy,step)+np.outer(step,hy))
        x,f,gradient=xx,ff,gg
    points=x.reshape(n,2)
    points-=points.mean(0)
    points*=np.sqrt(n/(points*points).sum())
    f,gradient=objective(points.ravel())
    return points,f,float(np.linalg.norm(gradient)),iteration

def exact_normalization(points):
    """After rounding, all value comparisons use integer and rational arithmetic."""
    n=len(points)
    raw=np.rint(points*1000000).astype(np.int64).tolist()
    raw=[(int(x),int(y)) for x,y in raw]
    if len(set(raw))!=n: raise ValueError("Rounding caused collision")
    sx=sum(x for x,y in raw)
    sy=sum(y for x,y in raw)
    D=n*sum(x*x+y*y for x,y in raw)-sx*sx-sy*sy
    if D<=0: raise ValueError("Invalid exact normalization")
    product=1
    for i in range(n):
        for j in range(i+1,n):
            d=(raw[i][0]-raw[j][0])**2+(raw[i][1]-raw[j][1])**2
            if d<=0: raise ValueError("Integer pair collision")
            product*=d
    N=n*(n-1)//2
    value=F(n**(2*N)*product,D**N)
    center=F((n-1)**(n-1))*F(n,n-1)**N
    if n==10 and not value/center>F(121,100):
        raise ValueError("Ten-point rationalized candidate did not improve by 21 percent")
    return {
        "scope":"Exact attainable lower bound; no global optimality",
        "integer_points":raw,"D":str(D),
        "coordinates":"n*(v_j-mean(v))/sqrt(D)",
        "discriminant_numerator":str(value.numerator),
        "discriminant_denominator":str(value.denominator),
        "natural_log_discriminant_display":log(value.numerator)-log(value.denominator),
        "ratio_to_centered_ring_numerator":str((value/center).numerator),
        "ratio_to_centered_ring_denominator":str((value/center).denominator)}

def main():
    rng=np.random.default_rng(SEED)
    rows=[]
    for n in range(6,13):
        starts=[rng.normal(size=(n,2)) for _ in range(RANDOM_STARTS)]
        ring=np.sqrt(n/(n-1))*np.exp(2j*np.pi*np.arange(n-1)/(n-1))
        z=np.r_[0,ring]
        starts.append(np.c_[z.real,z.imag])
        best=None
        energies=[]
        for start in starts:
            answer=optimize(start)
            energies.append(answer[1])
            if best is None or answer[1]<best[1]: best=answer
        points,f,residual,iterations=best
        log_delta=float(n*(n-1)/2-f)
        center_log=(n-1)*log(n-1)+n*(n-1)/2*log(n/(n-1))
        row={
            "n":n,"coordinates_real_imaginary":points.tolist(),
            "natural_log_discriminant":log_delta,
            "regular_polygon_log_discriminant":n*log(n),
            "centered_ring_log_discriminant":center_log,
            "log_gain_over_centered_ring":log_delta-center_log,
            "stationarity_gradient_norm":residual,
            "converged_to_gradient_tolerance":residual<2e-8,
            "last_iteration_index":iterations,
            "sorted_radii":np.sort(np.linalg.norm(points,axis=1)).tolist(),
            "quadratic_moment":float((points*points).sum()),
            "centroid":points.mean(0).tolist(),
            "distinct_observed_energy_bins_at_8_decimals":len(set(round(e,8) for e in energies)),
            "rationalized_attainable_candidate":exact_normalization(points)}
        rows.append(row)
        print(n,format(log_delta,'.15g'),format(log_delta-center_log,'.9g'),
              format(residual,'.3g'),flush=True)
    data={
        "scope":"Floating-point search candidates; exact rationalized values are lower bounds only",
        "seed":SEED,"random_starts_per_n":RANDOM_STARTS,
        "additional_starts_per_n":1,"additional_start":"origin plus regular (n-1)-gon",
        "numpy_version":np.__version__,
        "optimizer":"BFGS with analytic gradient and Armijo search",
        "candidates":rows}
    Path(__file__).with_name("numerical_candidates.json").write_text(
        json.dumps(data,indent=2)+"\n",encoding="utf-8")

if __name__=="__main__":
    main()
