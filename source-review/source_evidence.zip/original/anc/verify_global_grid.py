from pathlib import Path
from fractions import Fraction as Q
from itertools import combinations
from math import comb, isqrt
import json

def require(ok,message):
    if not ok: raise ValueError(message)

def exact_product(v):
    n=len(v)
    require(n>=2 and len(set(v))==n, 'Distinct points required')
    require(all(len(p)==2 and all(type(x) is int for x in p) for p in v), 'Integer coordinates required')
    D=n*sum(x*x+y*y for x,y in v)-sum(x for x,y in v)**2-sum(y for x,y in v)**2
    prod,total=1,0
    for (x,y),(a,b) in combinations(v,2):
        d=(x-a)**2+(y-b)**2
        require(d>0, 'Collision')
        prod*=d; total+=d
    require(D==total and D>0, 'Variance identity')
    N=n*(n-1)//2
    return Q(n**(2*N)*prod,D**N),D

def coordinate_radius(n,q):
    require(type(n) is int and n>=2 and type(q) is int and q>=1,'Invalid n,q')
    square=q*q*n; r=isqrt(square)
    return r+(r*r<square)

def enclosure(n,q,B):
    coordinate_radius(n,q)
    require(isinstance(B,Q) and B>0,'Positive exact grid maximum required')
    result={'applicable':q>=2*(n-1),'required_q_at_least':2*(n-1),'q':q}
    if result['applicable']:
        gap=Q(n*(n-1)*(2*n-1),4*q*q)
        result.update(logarithmic_gap_at_most=str(gap),lower_bound=str(B),upper_bound_expression=f'({B})*exp({gap})',meaning='B_grid <= M_n <= exp(K_n/q^2)*B_grid')
        if gap<1: result['rational_upper_bound']=str(B/(1-gap))
    else: result['reason']='q < 2*(n-1): no upper bound or error is asserted'
    return result

def enumeration(n,q):
    r=coordinate_radius(n,q)
    points=[(x,y) for x in range(-r,r+1) for y in range(-r,r+1)]
    m=len(points); N=n*(n-1)//2
    require(m>=n,'Not enough grid points')
    ds=[[0]*m for _ in points]
    for i,(x,y) in enumerate(points):
        for j in range(i):
            a,b=points[j]; ds[i][j]=ds[j][i]=(x-a)**2+(y-b)**2
    pairs=list(combinations(range(n),2))
    bestP,bestden,best,count,ties=0,1,None,0,0
    for ix in combinations(range(m),n):
        prod,D=1,0
        for i,j in pairs:
            d=ds[ix[i]][ix[j]]; prod*=d; D+=d
        den=D**N; comparison=prod*bestden-bestP*den
        if comparison>0: bestP,bestden,best,ties=prod,den,ix,1
        elif comparison==0: ties+=1
        count+=1
    require(count==comb(m,n) and best is not None,'Incomplete enumeration')
    coords=[points[i] for i in best]; B=Q(n**(2*N)*bestP,bestden)
    independent,D=exact_product(coords)
    require(independent==B,'Independent product mismatch')
    return {'n':n,'q':q,'integer_coordinate_radius':r,'grid_point_count':m,'distinct_subsets_expected':comb(m,n),'distinct_subsets_enumerated':count,'grid_maximizer_subset_count':ties,'grid_maximum_exact':str(B),'grid_maximum_decimal':float(B),'one_maximizing_integer_configuration':[list(p) for p in coords],'centering_normalization_D':D,'normalized_coordinates_formula':'n*(v_j-mean(v))/sqrt(D)','global_enclosure':enclosure(n,q,B),'scope':'Complete finite-grid maximum; not unrestricted global maximization'}

def audit():
    require(coordinate_radius(4,2)==4 and coordinate_radius(3,4)==7,'Exact coordinate caps')
    try: exact_product([(0,0),(0,0)])
    except ValueError: pass
    else: raise ValueError('Duplicate rejection failed')
    invalid=enclosure(3,3,Q(1))
    require(not invalid['applicable'] and 'upper_bound_expression' not in invalid,'Invalid q rejection')
    rows=[enumeration(2,2),enumeration(3,4)]
    require(rows[0]['distinct_subsets_enumerated']==1176 and rows[1]['distinct_subsets_enumerated']==1873200,'Enumeration counts')
    require(Q(rows[0]['grid_maximum_exact'])==4,'Two-point value')
    require(Q(rows[1]['grid_maximum_exact'])==Q(49280427,1825346)<27,'Three-point complete grid value')
    require(all(r['global_enclosure']['applicable'] for r in rows),'Grid hypotheses')
    return {'status':'passed','arithmetic':'Integer cross multiplication and exact Fraction products','complete_grid_enumerations':rows,'invalid_q_check':invalid,'known_unrestricted_maxima':{'n=2':'4','n=3':'27'},'scope':'The analytic enclosure theorem applies for every n; exhaustive computation here covers only two- and three-point grids'}

if __name__=='__main__':
    result=audit()
    Path(__file__).with_name('grid_global_result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    for row in result['complete_grid_enumerations']:
        print(f"Complete grid n={row['n']} q={row['q']}: {row['distinct_subsets_enumerated']} subsets, B={row['grid_maximum_exact']}")
    print('Passed exact enumeration, global enclosures, and invalid q rejection.')
