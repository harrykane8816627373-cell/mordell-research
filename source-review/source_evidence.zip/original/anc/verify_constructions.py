#!/usr/bin/env python3
"""Exact constructions and supporting algebra; not a global optimality certificate."""
from fractions import Fraction as F
from math import factorial, log
from pathlib import Path
import argparse
import json
import sys

if hasattr(sys, "set_int_max_str_digits"):
    sys.set_int_max_str_digits(0)

def require(ok, message):
    if not ok:
        raise ValueError(message)

def value_data(v):
    v = F(v)
    require(v > 0, "Nonpositive value")
    return {"numerator": str(v.numerator), "denominator": str(v.denominator),
            "natural_log": log(v.numerator)-log(v.denominator)}

def sub(p, q):
    out = [F(0)]*max(len(p), len(q))
    for i, c in enumerate(p): out[i] += c
    for i, c in enumerate(q): out[i] -= c
    while out and not out[-1]: out.pop()
    return out

def mul(p, q):
    if not p or not q: return []
    out = [F(0)]*(len(p)+len(q)-1)
    for i, c in enumerate(p):
        for j, d in enumerate(q): out[i+j] += c*d
    return out

def S_coeff(m):
    return [F(1, factorial(k)) for k in range(m+1)]

def check_concavity(m):
    lhs = sub(mul(S_coeff(m-1), S_coeff(m-1)), mul(S_coeff(m), S_coeff(m-2)))
    rhs = [F(0)]*(m-1)+[
        F(1, factorial(m-1))*(1-F(k,m))/factorial(k) for k in range(m)]
    require(not sub(lhs, rhs), "Concavity identity failed for m="+str(m))
    require(all(c >= 0 for c in rhs) and any(c > 0 for c in rhs),
            "Invalid concavity coefficients")

def integer_construction(n):
    radius = 0
    while True:
        disk = sorted((x*x+y*y,x,y) for x in range(-radius,radius+1)
                      for y in range(-radius,radius+1) if x*x+y*y <= radius*radius)
        if len(disk) >= n: break
        radius += 1
    points = [(x,y) for _,x,y in disk[:n]]
    require(len(set(points)) == n, "Integer point collision")
    sx = sum(x for x,y in points)
    sy = sum(y for x,y in points)
    D = n*sum(x*x+y*y for x,y in points)-sx*sx-sy*sy
    require(D > 0, "Zero normalization denominator")
    centered = [(F(x)-F(sx,n), F(y)-F(sy,n)) for x,y in points]
    require(sum(x for x,y in centered) == sum(y for x,y in centered) == 0,
            "Centering failed")
    moment = sum(x*x+y*y for x,y in centered)
    require(moment == F(D,n) and F(n*n,D)*moment == n, "Normalization failed")
    product = 1
    for i in range(n):
        for j in range(i+1,n):
            d = (points[i][0]-points[j][0])**2+(points[i][1]-points[j][1])**2
            require(d > 0, "Zero pair distance")
            product *= d
    N = n*(n-1)//2
    value = F(n**(2*N)*product, D**N)
    return value, {
        "integer_points": points, "enumeration_disk_radius": radius,
        "tie_rule": "ascending squared radius, then real coordinate, then imaginary coordinate",
        "centered_points": [[str(x),str(y)] for x,y in centered],
        "D": str(D), "integer_squared_distance_product": str(product),
        "normalized_points": "z_j = n*(v_j-mean(v))/sqrt(D)",
        "discriminant": value_data(value)}

def ten_value():
    u, v = F(1,8), F(39,32)
    return 4*u*8**8*v**28*(u**4+v**4)**4

def exact_bounds(n):
    N = n*(n-1)//2
    product = 1
    for k in range(n): product *= factorial(k)
    a = F(1) if n == 2 else (F(11,4) if n == 6 else F(n-1,2))
    require(a > 0, "Nonpositive upper-bound parameter")
    series = sum(a**k/factorial(k) for k in range(n))
    upper = F(product)*series**n/a**N
    lower_average = F(factorial(n)*factorial(n-2)*n**N*product,
                      factorial(N+n-2))
    lattice, construction = integer_construction(n)
    lower = {
        "regular_polygon": F(n**n),
        "centered_regular_ring": F((n-1)**(n-1))*F(n,n-1)**N,
        "centered_sphere_average": lower_average,
        "gaussian_integer_construction": lattice}
    if n == 10:
        lower["ten_point_two_ring"] = ten_value()
    require(all(0 < v <= upper for v in lower.values()),
            "Inconsistent exact bounds at n="+str(n))
    if n == 2: require(lower_average == upper == 4, "Two-point sharp bound")
    if n == 6:
        require(lower["centered_regular_ring"] == F(6**15,5**10), "Six-point value")
        require(upper < 89309, "Six-point rational upper bound")
    row = {
        "n": n, "number_of_pairs": N, "factorial_product_P_n": str(product),
        "a": str(a), "S_n_minus_1_at_a": str(series),
        "rational_upper_U_a": value_data(upper),
        "exact_lower_bounds": {k: value_data(v) for k,v in lower.items()},
        "largest_computed_exact_lower": value_data(max(lower.values())),
        "gaussian_integer_construction": construction}
    return row, upper

def ten_comparison():
    u, v = F(1,8), F(39,32)
    require(2*u+8*v == 10 and 0 < u < v, "Invalid ten-point radii")
    delta = ten_value()
    center = F(9**9)*F(10,9)**45
    ratio = delta/center
    require(ratio > F(113,100), "Ten-point ratio not greater than 113/100")
    require(delta <= exact_bounds(10)[1], "Ten-point value exceeds upper bound")
    return {
        "inner_squared_radius": str(u), "outer_squared_radius": str(v),
        "inner_points": "plus/minus sqrt(1/8)",
        "outer_points": "sqrt(39/32)*exp(i*(pi/8+j*pi/4)), j=0,...,7",
        "discriminant_formula": "4*u*8^8*v^28*(u^4+v^4)^4",
        "candidate_discriminant": value_data(delta),
        "centered_regular_nine_ring": value_data(center),
        "ratio": value_data(ratio), "verified_ratio_lower": "113/100"}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--max-n", type=int, default=30)
    parser.add_argument("--output", default="verification_result.json")
    args = parser.parse_args()
    require(args.max_n >= 2, "max-n must be at least 2")
    for m in range(1,args.max_n): check_concavity(m)
    rows = [exact_bounds(n)[0] for n in range(2,args.max_n+1)]
    data = {
        "status": "passed",
        "arithmetic": "Exact integers and fractions; logarithms are for display only",
        "scope": "Construction values and finite coefficient checks; no global optimality certificate",
        "definitions": {
            "N": "n*(n-1)/2", "P_n": "product(k!,k=0,...,n-1)",
            "S_m": "sum(a^k/k!,k=0,...,m)", "U_a": "P_n*S_(n-1)(a)^n/a^N",
            "Lc": "n!*(n-2)!*n^N*P_n/(N+n-2)!"},
        "concavity_identity": "S_(m-1)^2-S_m*S_(m-2)=a^(m-1)/(m-1)!*[1+sum((1-k/m)*a^k/k!,k=1,...,m-1)]",
        "concavity_identity_checked_m": [1,args.max_n-1],
        "ten_point_counterexample": ten_comparison(), "bounds_by_n": rows}
    Path(args.output).write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8")
    print("Passed exact bounds and constructions for n=2,...,"+str(args.max_n)+".")
    print("Ten-point ratio exceeds 113/100; no claim of global optimality.")

if __name__ == "__main__":
    main()
