#!/usr/bin/env python3
"""Independently check saved exact attainable values; standard library only."""
from fractions import Fraction
from math import factorial, log
from pathlib import Path
import json
import sys

if hasattr(sys, 'set_int_max_str_digits'):
    sys.set_int_max_str_digits(0)

ROOT = Path(__file__).resolve().parent

def require(condition, message):
    if not condition:
        raise ValueError(message)

def unpack(value):
    return Fraction(int(value['numerator']), int(value['denominator']))

def direct_product(raw, denominator):
    n = len(raw)
    require(n >= 2 and len(set(map(tuple, raw))) == n, 'Invalid distinct points')
    sx = sum(p[0] for p in raw)
    sy = sum(p[1] for p in raw)
    # Exact coordinates have these integer numerators and common sqrt(D).
    numerators = [(n*x-sx, n*y-sy) for x, y in raw]
    require(sum(x for x, y in numerators) == 0, 'Real centroid')
    require(sum(y for x, y in numerators) == 0, 'Imaginary centroid')
    moment = sum(Fraction(x*x+y*y, denominator) for x, y in numerators)
    require(moment == n, 'Quadratic moment')
    product = Fraction(1)
    for i, (x, y) in enumerate(numerators):
        for u, v in numerators[:i]:
            distance = Fraction((x-u)**2+(y-v)**2, denominator)
            require(distance > 0, 'Collision')
            product *= distance
    return product

def upper_bound(n):
    a = Fraction(1) if n == 2 else (Fraction(11, 4) if n == 6 else Fraction(n-1, 2))
    series = sum(a**k / factorial(k) for k in range(n))
    factor = 1
    for k in range(n):
        factor *= factorial(k)
    return factor*series**n/a**(n*(n-1)//2)

def main():
    constructions = json.loads((ROOT/'verification_result.json').read_text(encoding='utf-8'))
    for row in constructions['bounds_by_n']:
        n = row['n']
        saved = row['gaussian_integer_construction']
        actual = direct_product(saved['integer_points'], int(saved['D']))
        require(actual == unpack(saved['discriminant']), 'Lattice product at n='+str(n))
        require(actual <= upper_bound(n), 'Lattice upper bound at n='+str(n))

    search = json.loads((ROOT/'numerical_candidates.json').read_text(encoding='utf-8'))
    audit = []
    for row in search['candidates']:
        n = row['n']
        saved = row['rationalized_attainable_candidate']
        actual = direct_product(saved['integer_points'], int(saved['D']))
        require(actual == Fraction(int(saved['discriminant_numerator']),
                                   int(saved['discriminant_denominator'])), 'Saved product at n='+str(n))
        center = (n-1)**(n-1)*Fraction(n, n-1)**(n*(n-1)//2)
        ratio = actual/center
        require(ratio == Fraction(int(saved['ratio_to_centered_ring_numerator']),
                                 int(saved['ratio_to_centered_ring_denominator'])), 'Saved ratio')
        require(actual <= upper_bound(n), 'Candidate upper bound at n='+str(n))
        if n == 10:
            require(ratio > Fraction(121, 100), 'Ten-point strict improvement')
        exact_log_display = log(actual.numerator)-log(actual.denominator)
        require(abs(exact_log_display-row['natural_log_discriminant']) < 1e-8,
                'Floating-point display mismatch')
        audit.append({'n': n, 'exact_constraints_and_product': 'passed',
                      'ratio_to_centered_ring_display': float(ratio),
                      'comparison_to_global_upper_bound': 'passed'})
    result = {'status': 'passed',
              'scope': 'Saved attainable lower bounds; not a global optimality proof',
              'lattice_point_counts_checked': [r['n'] for r in constructions['bounds_by_n']],
              'numerical_candidates': audit}
    (ROOT/'saved_candidates_audit.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print('Passed independent exact checks of all saved coordinates and products.')

if __name__ == '__main__':
    main()
