"""Exact stationary-polynomial examples and an actual spurious six-root pairing.
Standard library only; finite examples are not complete stationary enumeration.
All example coefficients are real, hence coefficientwise conjugation is trivial.
"""
from fractions import Fraction as F
from pathlib import Path
import json

def trim(a):
    a=list(a)
    while len(a)>1 and not a[-1]: a.pop()
    return a or [0]
def add(a,b):
    c=[0]*max(len(a),len(b))
    for i,x in enumerate(a): c[i]+=x
    for i,x in enumerate(b): c[i]+=x
    return trim(c)
def scale(a,s): return trim([x*s for x in a])
def sub(a,b): return add(a,scale(b,-1))
def mul(a,b):
    c=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): c[i+j]+=x*y
    return trim(c)
def divrem(a,b):
    a,b=trim(a),trim(b); q=[0]*max(1,len(a)-len(b)+1)
    if len(b)==1 and not b[0]: raise ZeroDivisionError
    while not(len(a)==1 and not a[0]) and len(a)>=len(b):
        k=len(a)-len(b); u,v=a[-1],b[-1]
        t=F(u)/F(v) if isinstance(u,(int,F)) and isinstance(v,(int,F)) else u/v
        q[k]+=t; a=sub(a,[0]*k+scale(b,t))
    return trim(q),trim(a)
def rem(a,p): return divrem(a,p)[1]
def invmod(a,p):
    r0,r1,s0,s1=trim(p),trim(a),[0],[1]
    while not(len(r1)==1 and not r1[0]):
        q,r2=divrem(r0,r1); r0,r1=r1,r2; s0,s1=s1,sub(s0,mul(q,s1))
    if len(r0)!=1: raise ArithmeticError('not invertible')
    z=r0[0]; iz=F(1)/F(z) if isinstance(z,(int,F)) else 1/z
    return rem(scale(s0,iz),p)
def derivative(a): return trim([i*a[i] for i in range(1,len(a))])
def power(a,k,p):
    out=[1]
    while k:
        if k&1: out=rem(mul(out,a),p)
        a=rem(mul(a,a),p); k>>=1
    return out
def compose(a,b,p):
    out=[0]
    for v in a[::-1]: out=add(rem(mul(out,b),p),[v])
    return rem(out,p)
def trace(a,p):
    out=0
    for i in range(len(p)-1):
        c=rem([0]*i+a,p); out+=c[i] if i<len(c) else 0
    return out
def determinant(a):
    dp={0:1}
    for row in range(len(a)):
        nxt={}
        for mask,v in dp.items():
            for j in range(len(a)):
                if not(mask>>j)&1:
                    z=mask|(1<<j); sign=-1 if (mask>>(j+1)).bit_count()&1 else 1
                    nxt[z]=nxt.get(z,0)+sign*v*a[row][j]
        dp=nxt
    return dp[(1<<len(a))-1]
def check(b,message):
    if not b: raise ArithmeticError(message)
CUBIC=list(map(F,[-45,126,-60,8]))
class K:
    def __init__(self,x=0):
        self.c=x.c if isinstance(x,K) else tuple(rem(list(map(F,x)) if isinstance(x,(list,tuple)) else [F(x)],CUBIC))
    def __add__(self,x): return K(add(self.c,K(x).c))
    __radd__=__add__
    def __neg__(self): return K(scale(self.c,-1))
    def __sub__(self,x): return self+-K(x)
    def __rsub__(self,x): return K(x)-self
    def __mul__(self,x): return K(mul(self.c,K(x).c))
    __rmul__=__mul__
    def inverse(self): return K(invmod(self.c,CUBIC))
    def __truediv__(self,x): return self*K(x).inverse()
    def __rtruediv__(self,x): return K(x)*self.inverse()
    def __pow__(self,k): return self.inverse()**(-k) if k<0 else K(power(self.c,k,CUBIC))
    def __bool__(self): return any(self.c)
    def __eq__(self,x): return self.c==K(x).c
    def __repr__(self): return str(list(map(str,self.c)))
def stationary(P):
    n=len(P)-1; dP=derivative(P)
    R=rem(mul(scale(derivative(dP),F(1,2)),invmod(dP,P)),P)
    check(rem(sub(derivative(dP),scale(mul(R,dP),2)),P)==[0],'force polynomial relation')
    check(compose(P,R,P)==[0],'conjugate root matching')
    H=[[trace(rem(mul([0]*j+[1],power(R,k,P)),P),P) for k in range(n)] for j in range(n)]
    check(all(H[j][k]==H[k][j] for j in range(n) for k in range(n)),'Hermitian')
    check(H[1][1]==F(n*(n-1),2),'automatic mixed trace identity')
    return R,H
def interval(a,lo,hi):
    out=(F(0),F(0))
    for v in a[::-1]:
        q=[out[0]*lo,out[0]*hi,out[1]*lo,out[1]*hi]; out=(min(q)+v,max(q)+v)
    return out

def main():
    cases=[]
    examples=[('n2 pair',[F(-1,2),0,1],F(2)),('n3 collinear Hermite',[0,F(-3,2),0,1],F(27,2)),('n3 equilateral',[-1,0,0,1],F(27)),('n4 regular square',[F(9,4),0,0,0,1],F(2916)),('n5 origin and square',[0,F(-25,4),0,0,0,1],F(9765625,4))]
    for name,P,expected in examples:
        P=list(map(F,P)); R,H=stationary(P)
        minors=[determinant([r[:k] for r in H[:k]]) for k in range(1,len(H)+1)]
        check(all(x>0 for x in minors),'positive definiteness')
        check(minors[-1]==expected,'Vandermonde trace determinant')
        n=len(P)-1; normalized=F(2,n-1)**(n*(n-1)//2)*minors[-1]
        cases.append({'name':name,'P_ascending':list(map(str,P)),'R_ascending':list(map(str,R)),'leading_principal_minors':list(map(str,minors)),'normalized_product':str(normalized),'physical_stationary_certificate':True})
    lo,hi=F(11,25),F(9,20)
    check(interval(CUBIC,lo,lo)[0]<0<interval(CUBIC,hi,hi)[0],'cubic root exists')
    check(interval(derivative(CUBIC),lo,hi)[0]>0,'cubic root unique in isolating interval')
    check(all(sum(int(CUBIC[j])*r**j for j in range(4))%7 for r in range(7)),'cubic irreducible modulo 7')
    p=K([0,1]); c=(15-4*p)/2; s=(20*p**2-108*p+135)/(2*(15-4*p)); t=p**2-c*s+c**2
    check(s==2*p**2-10*p+F(15,2),'simplified radius sum')
    check(s*p**2-2*c*s**2+s*c**2+4*c*p**2==0,'inner force products equal')
    check((2*p-3)*t-4*p**2+2*c*s==0,'sum inner force products')
    numlo,numhi=interval(list(map(F,[135,-108,20])),lo,hi)
    denlo,denhi=2*(15-4*hi),2*(15-4*lo)
    slo,shi,clo=F(17,5),F(347,100),F(33,5)
    check(numlo/denhi>slo and numhi/denlo<shi,'exact s bounds')
    check(clo>shi and slo>2*hi,'three distinct positive squared radii')
    P=[-c*p**2,K(0),p**2+c*s,K(0),-(s+c),K(0),K(1)]
    R,H=stationary(P)
    check(rem(sub([0]+R,[p]),[p**2,0,-s,0,1])==[0],'inner root swap')
    check(rem(sub([0]+R,[c]),[-c,0,1])==[0],'outer root fixed')
    even=[[H[j][k] for k in [0,2,4]] for j in [0,2,4]]; v=determinant(even)
    check(v==-8*(s**2-4*p**2)*t**2,'negative minor factorization')
    check(v==K([-48600,19440,2592]),'negative minor simplified form')
    check(slo**2>4*hi**2,'strict negative minor sign')
    result={'arithmetic':'exact Fraction and Q[p]/cubic','scope':'finite examples only, not full stationary-point enumeration','physical_examples':cases,'genuine_spurious_n6':{'cubic_ascending':list(map(str,CUBIC)),'p_isolating_interval':[str(lo),str(hi)],'P_ascending_Qp':list(map(repr,P)),'R_ascending_Qp':list(map(repr,R)),'force_relation':True,'conjugate_root_matching':True,'Hermitian_trace_matrix':True,'negative_principal_minor_Qp':repr(v),'permutation_cycle_structure':'two transpositions, two fixed points','inertia':[4,2,0],'physical_stationary_certificate':False},'all_checks_passed':True}
    out=Path(__file__).with_name('stationary_polynomial_result.json')
    out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'all_checks_passed':True,'true_examples':len(cases),'genuine_spurious_matching_rejected':True,'output':str(out)},ensure_ascii=False))
if __name__=='__main__': main()

