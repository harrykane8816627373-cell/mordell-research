"""Optional SageMath critical-value eliminant generator.
Needs SageMath; not executed in the present environment. General n Groebner
elimination can take substantial time and memory. A polynomial's largest real
root need not be the physical maximum; use the global-grid enclosure in main.tex.
"""
from sage.all import QQ, PolynomialRing, prod

def critical_value_polynomial(n):
    if n<2: raise ValueError('n must be >=2')
    N=n*(n-1)//2; m=n-2
    names=['s']+[f'z{i}' for i in range(3,n+1)]+[f'w{i}' for i in range(3,n+1)]+['T']
    R=PolynomialRing(QQ,names=names,order='lex'); gen=R.gens()
    s,T=gen[0],gen[-1]
    Z=[R(-1),R(1)]+list(gen[1:1+m])
    W=[R(-1),R(1)]+list(gen[1+m:1+2*m])
    sz,sw=sum(Z),sum(W)
    Q=sum(Z[i]*W[i] for i in range(n))-sz*sw/n
    Vz=prod(Z[i]-Z[j] for i in range(n) for j in range(i+1,n))
    Vw=prod(W[i]-W[j] for i in range(n) for j in range(i+1,n))
    forces=[]
    for A,B,sb in [(Z,W,sw),(W,Z,sz)]:
        for i in range(2,n):
            Di=prod(A[i]-A[j] for j in range(n) if j!=i)
            Ei=sum(prod(A[i]-A[k] for k in range(n) if k!=i and k!=j) for j in range(n) if j!=i)
            forces.append(Q*Ei-N*(B[i]-sb/n)*Di)
    if any(f.total_degree()>n for f in forces): raise RuntimeError('Degree audit failed')
    gb=R.ideal(forces+[s*Q*Vz*Vw-1,T*Q**N-n**N*Vz*Vw]).groebner_basis()
    U=PolynomialRing(QQ,'t'); hom=R.hom([U(0)]*(R.ngens()-1)+[U.gen()],U)
    terms=[hom(f) for f in gb if f and all(v==T for v in f.variables())]
    if not terms: raise RuntimeError('No univariate eliminant')
    p=terms[0]
    for f in terms[1:]: p=p.gcd(f)
    p=p.quo_rem(p.gcd(p.derivative()))[0].monic()
    if not 1<=p.degree()<=n**(2*n-4): raise RuntimeError('Invalid degree')
    return p
if __name__=='__main__':
    import sys
    n=int(sys.argv[1]) if len(sys.argv)>1 else 3
    print(critical_value_polynomial(n))
