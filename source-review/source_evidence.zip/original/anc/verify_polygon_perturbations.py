#!/usr/bin/env python3
"""Exact Fourier perturbation checks, including the degenerate ten-point case.

Standard library only. Analytic local/global statements are proved in main.tex.
These arithmetic checks are not an unrestricted global-optimality certificate.
"""
from fractions import Fraction as Q
from pathlib import Path
import json

def require(ok, message):
    if not ok:
        raise ValueError(message)

class K:
    """Q(w), w a primitive ninth root, w^6+w^3+1=0."""
    def __init__(self, value=0):
        if isinstance(value, K):
            self.c = value.c
        elif isinstance(value, (list, tuple)):
            self.c = tuple(Q(x) for x in value) + (Q(0),)*(6-len(value))
        else:
            self.c = (Q(value),)+(Q(0),)*5

    def __add__(self, other):
        other = K(other)
        return K([a+b for a,b in zip(self.c, other.c)])
    __radd__ = __add__

    def __neg__(self):
        return K([-a for a in self.c])

    def __sub__(self, other):
        return self+(-K(other))

    def __rsub__(self, other):
        return K(other)+(-self)

    def __mul__(self, other):
        other = K(other)
        a = [Q(0)]*11
        for i,x in enumerate(self.c):
            for j,y in enumerate(other.c):
                a[i+j] += x*y
        for d in range(10,5,-1):
            a[d-6] -= a[d]
            a[d-3] -= a[d]
            a[d] = 0
        return K(a[:6])
    __rmul__ = __mul__

    def __eq__(self, other):
        return self.c == K(other).c

    def inverse(self):
        require(self != 0, 'Field division by zero')
        columns = [(self*K([0]*j+[1])).c for j in range(6)]
        a = [[columns[j][i] for j in range(6)]+[Q(i == 0)] for i in range(6)]
        for j in range(6):
            pivot = next(i for i in range(j,6) if a[i][j])
            a[j],a[pivot] = a[pivot],a[j]
            scale = a[j][j]
            a[j] = [x/scale for x in a[j]]
            for i in range(6):
                if i != j:
                    scale = a[i][j]
                    a[i] = [x-scale*y for x,y in zip(a[i],a[j])]
        result = K([a[i][-1] for i in range(6)])
        require(self*result == 1, 'Field inverse check')
        return result

    def __truediv__(self, other):
        return self*K(other).inverse()

    def __pow__(self, exponent):
        if exponent < 0:
            return self.inverse()**(-exponent)
        value, base = K(1),self
        while exponent:
            if exponent & 1:
                value = value*base
            base = base*base
            exponent //= 2
        return value

    def conjugate(self):
        w = K([0,1])
        return sum((c*w**((-i)%9) for i,c in enumerate(self.c)), K(0))

    def rational(self):
        require(all(x == 0 for x in self.c[1:]), 'Expected rational field value')
        return self.c[0]

def multiply_poly(p, q):
    result = {}
    for (a,b),x in p.items():
        for (c,d),y in q.items():
            key = a+c,b+d
            result[key] = result.get(key,0)+x*y
    return result

def pair_power_sum(m, modes, degree):
    """Sum u_ij^degree via exact root-of-unity orthogonality, no field inverses."""
    divided = {}
    center = {}
    for k in modes:
        center[k-1] = center.get(k-1,0)+1
        for j in range(k):
            key = k-1-j,j
            divided[key] = divided.get(key,0)+1
    power = {(0,0): 1}
    for _ in range(degree):
        power = multiply_poly(power,divided)
    answer = sum(Q(c)*(m*m*(a%m == 0 and b%m == 0)-m*((a+b)%m == 0))/2
                 for (a,b),c in power.items())
    cp = {0:1}
    for _ in range(degree):
        nxt = {}
        for a,x in cp.items():
            for b,y in center.items():
                nxt[a+b] = nxt.get(a+b,0)+x*y
        cp = nxt
    return answer + m*sum(c for a,c in cp.items() if a%m == 0)

def ten_point_audit():
    m,n = 9,10
    w = K([0,1])
    require(w**9 == 1 and w**3 != 1, 'Primitive ninth root')
    z = [K(0)]+[w**j for j in range(m)]
    h = [K(0)]+[w**(5*j)+w**(6*j) for j in range(m)]
    k = [K(-12)]+[K(Q(4,3))-Q(17,3)*w**(2*j) for j in range(m)]
    B = [[K(0) for _ in range(n)] for _ in range(n)]
    a = [K(0) for _ in range(n)]
    powers = {d:K(0) for d in range(1,5)}
    for i in range(n):
        stationary = K(0)
        for j in range(n):
            if i != j:
                stationary += (z[i]-z[j]).inverse()
        require(stationary == 5*z[i].conjugate(), 'Ten-point stationarity')
        for j in range(i):
            inverse = (z[i]-z[j]).inverse()
            u = (h[i]-h[j])*inverse
            B[i][j] = B[j][i] = -(inverse**2)
            a[i] += u*u*inverse
            a[j] -= u*u*inverse
            for d in powers:
                powers[d] += u**d
    for i in range(n):
        B[i][i] = -sum(B[i], K(0))
    expected = [K(-9)]+[1-15*w**(7*j)-10*w**(8*j) for j in range(m)]
    require(a == expected, 'Exact cubic-gradient formula')
    require(sum(h,K(0)) == sum(k,K(0)) == 0, 'Zero centroid directions')
    require(sum((x.conjugate()*y for x,y in zip(z,k)),K(0)) == 0, 'Gauge tangent')
    Bk = [sum((B[i][j]*k[j] for j in range(n)),K(0)) for i in range(n)]
    for i in range(n):
        require(5*k[i]+Bk[i].conjugate() == a[i].conjugate()+10*z[i],
                'Optimal transverse correction equation')
    sums = {d:value.rational() for d,value in powers.items()}
    for d in sums:
        require(sums[d] == pair_power_sum(m,[5,6],d), 'Independent power-sum check')
    require(sums == {1:Q(0),2:Q(-90),3:Q(0),4:Q(2970)}, 'Ten-point power sums')
    norm_k = sum((x.conjugate()*x for x in k),K(0)).rational()
    bilinear = sum((x*y for x,y in zip(k,Bk)),K(0)).rational()
    cubic_linear = 2*sum((x*y for x,y in zip(a,k)),K(0)).rational()
    require(norm_k == 449 and bilinear == -1360 and cubic_linear == 1770,
            'Ten-point transverse constants')
    quadratic_k = -bilinear-5*norm_k
    straight_quartic = -sums[4]/2+Q(45)*4/2
    effective_quartic = straight_quartic+quadratic_k+cubic_linear
    require(quadratic_k == -885 and straight_quartic == -1395
            and effective_quartic == -510, 'Effective quartic coefficient')
    return {'status':'passed','field':'Q(w), w^6+w^3+1=0',
            'pair_ratio_power_sums':{str(d):str(v) for d,v in sums.items()},
            'straight_null_quartic':str(straight_quartic),
            'optimal_transverse_gain':str(quadratic_k+cubic_linear),
            'effective_null_quartic':str(effective_quartic),
            'scope':'Exact constants for the analytic local-maximality proof, not global optimality'}

def general_audit():
    rows = []
    for m in range(5,41):
        n,N = m+1,m*(m+1)//2
        k = (m+2)//2
        modes = [k] if m%2 == 0 else [k,m+2-k]
        b = len(modes)
        q = (m-2)**2//4
        A = Q(m,2)*(q-m-3) if m%2 == 0 else Q(m)*(q-m-3)
        require(-pair_power_sum(m,modes,2)-N*b == A, 'General quadratic coefficient')
        gamma_sq = Q(m*m,n)
        lam_sq = Q(m*m,4)
        spectral_squares = [gamma_sq,gamma_sq,lam_sq]
        spectral_squares += [(Q(1)-Q((j-2)*(m-j),2))**2*Q(m,n)**2 for j in range(3,m)]
        row = {'n':n,'largest_mode_quadratic_coefficient':str(A),
               'spectrum_condition':max(spectral_squares)<=lam_sq}
        if m <= 8:
            require(gamma_sq<lam_sq and all(x<lam_sq for x in spectral_squares[3:]),
                    'Strict nontrivial spectral gap')
        if m == 9:
            require(A == 0 and sum(x==lam_sq for x in spectral_squares)==3,
                    'Ten-point degeneracy')
        if m >= 10:
            require(A>0 and max(spectral_squares)>lam_sq, 'Higher-point instability')
            H = m+2
            t = min(Q(1,2*H),A/(4*N*H**3))
            require(t>0 and H*t<=Q(1,2), 'Taylor step range')
            remainder = Q(2*N*H**3)*t**3/(3*(1-H*t))
            require(A*t*t-remainder >= Q(2,3)*A*t*t>0, 'Positive certified log gain')
            row.update({'explicit_step':str(t),'certified_log_gain_lower':str(Q(2,3)*A*t*t)})
        rows.append(row)
    return rows

def six_point_basin_audit():
    # gamma=5/sqrt(6)<41/20, hence lambda-gamma>9/20.
    require(Q(25,6)<Q(41,20)**2, 'Six-point strict spectral gap')
    radius = Q(1,25)
    ratio_cap = Q(4,3)*radius
    require(Q(5,3)<Q(4,3)**2, 'Pair-ratio norm bound')
    remainder = Q(10,3)*ratio_cap/(1-ratio_cap)+Q(5,24)*radius**2
    require(remainder == Q(40,213)+Q(1,3000), 'Six-point remainder constants')
    require(remainder<Q(1,5), 'Six-point Taylor loss')
    require(Q(9,20)-Q(1,5)==Q(1,4), 'Six-point certified quadratic loss')
    return {'status':'passed','chart_radius':'1/25',
            'log_product_loss_at_least':'||h||^2/4',
            'chart':'sqrt(6)*(z_star+h)/sqrt(6+||h||^2), sum(h)=<z_star,h>=0',
            'scope':'Explicit local basin around the central pentagon; not a global six-point proof'}

if __name__ == '__main__':
    data = {'status':'passed','arithmetic':'Exact rational and cyclotomic field arithmetic',
            'six_point_local_basin':six_point_basin_audit(),
            'ten_point_degenerate_case':ten_point_audit(),
            'general_fourier_checks':general_audit()}
    Path(__file__).with_name('polygon_perturbation_result.json').write_text(
        json.dumps(data,indent=2)+'\n',encoding='utf-8')
    print('Passed exact ten-point effective quartic: -510.')
    print('Passed Fourier and certified perturbation checks for n=6,...,41.')
