# 一般 n 构型与上下界：相位分解、有理上升和有效径向人口

研究资料与项目发起：**蒋丰灿（Fengcan Jiang）**；推导、程序及交叉审阅包含 OpenAI Codex 协作。2026-10-28。

本专题继续联合已有完整原稿、严格子集方法与库仑分解。已直接更新[一般n审核](../earlier-results/general_n_proof.md)及相关首页的过期状态，并同步当前字节索引。原稿已有的严格递推、网格及十点四阶证明不登记为本轮首次成果；原始论文和历史ZIP保持原字节。

[统一证明状态表](PROOF_STATUS.md) · [有限n合并包络与构型比较](FINITE_N_RESULTS.md) · [返回仓库总览](../README.md)

**一般 n 的简洁全局锐值公式、八点完整无条件锐界仍未解决。** 本次提高可达下界，并给条件构型类上界和全局最优者的有效分布约束，没有宣布新的未知点数锐值。

```math
M_n=\max_{\sum_i|z_i|^2=n}\Delta_n(z),\quad
\Delta_n(z)=\prod_{i\lt j}|z_i-z_j|^2,\quad N=\frac{n(n-1)}2,
\quad U_n=n^{n/2}\left(\frac{2n}{n-1}\right)^N e^{-N/2}.
```

## 1. 全部正负相位可以精确分解

对既有多环数据(mᵢ,bᵢ)，按人口的二进赋值ν₂(mᵢ)分组。不同组之间的交叉resultant只产生单个符号的一元项；同组内则是正权割项。因此全部正负相位的最大乘积等于各组独立有限最大值的乘积，直接用有理数比较即可认证。

[完整证明](phase_graph.md) · [实现](phase_graph.py) · [精确比较](phase_graph_comparison.json)。三十点人口6、12、12，平方半径1/5、4/5、8/5，最佳符号(+1,−1,+1)给

```math
\frac{P_{30}^{\rm graph}}{P_{30}^{\rm two\ signs}}
=\left(\frac{90155}{84693}\right)^{12}\gt2.
```

2≤n≤100的99个相位家族均已独立穷尽符号核对，相对此前完整包络提高13项。这里优化的只是规定半径、人口下的正负相位家族；不等于全部连续相位、半径或原问题的全局最优。最大的组仍可能很大，超过预算会拒绝计算。

## 2. 无需寻找步长的严格有理构型改善

对中心化的无碰撞有理坐标 v，设 Q=Σ|v|²，F(v)=(n/Q)ᴺΔ(v)。用力方程的切向残差

```math
f_i=\sum_{j\ne i}(v_i-v_j)^{-1},\qquad
r_i=\overline{f_i}-\frac NQ v_i,
\quad R=\sum_i|r_i|^2,
\quad A=\sum_{i\lt j}\left|\frac{r_i-r_j}{v_i-v_j}\right|^2.
```

取有理 C≥max| (rᵢ−rⱼ)/(vᵢ−vⱼ) |、H=2A+NR/Q。若R>0，明确取

```math
t=\frac R{H+2CR},\qquad
\boxed{\displaystyle
\log\frac{F(v+tr)}{F(v)}\ge\frac{R^2}{H+2CR}\gt0.}
```

[完整证明](ascent_audit.md)控制碰撞、中心化、归一化和对数尾项。实现支持Q(i)及Q(i√3)，所以可同时用于方格、三角格和旧保存整数构型。每条改进都给出精确整数坐标见证，不依赖浮点优化或步长搜索。

对n≤30每个指定种子仅做一次明确步骤，并与完整旧包络和本轮最优相位取最大；上升在相位之外另提高13项，其中n=26至少提高98.30%。n=10、11、12的保存构型本已接近驻点，这三项只有微小严格增益，不能混称大幅改善。[完整见证及精确万分比](ascent_envelope_comparison.json)。

残差为零仍可能次优：三点共线和五点中心正方形都是明确反例。有限残差停止保证不是全局目标误差保证。当前下界取旧包络、相位及上述实际新构型的最大者；无条件上界仍为Uₙ等已有界。

## 3. 从库仑缺额得到任意环带的人口限制

令δ(z)=log(Uₙ/Δₙ(z))。对任意总二阶矩n的无碰撞构型，无需驻点或预设重心，有

```math
\boxed{\displaystyle
\sup_{s\ge0}\left|
\frac{\#\{i:|z_i|^2\le s\}}n-\min\{s/2,1\}
\right|
\le\left(\frac{6\delta(z)}{n^2}\right)^{1/3}
+\frac2{\sqrt n}+\frac1n.}
```

对全局最优者，输入已有下界即可把δ从上方有效控制，得到O(n⁻¹ᐟ³)的径向CDF误差和O(n²ᐟ³)的人口误差。原尺度转换中的1/n不可遗漏。另有

```math
\min_i|z_i|\le\sqrt{\frac n{n-1}}
\left[\sqrt{\frac2n}+2\left(\frac{\delta(z)}{n^2}\right)^{1/4}\right],
```

故全局最优者至少一个点距重心O(n⁻¹ᐟ⁴)，但不声称存在精确原点。

[完整证明与条件](radial_audit.md)也将精确半径计数推广到K个有宽度平方半径带。库仑尺度x=√((n−1)/n)z的半径平方在[0,2]内，覆盖总宽为W时，

```math
\delta(z)\ge\frac{n^2}{192(K+1)^2}
\left(2-W-\frac{8K}{\sqrt n}\right)_+^3.
```

还可用纯有理积分单元认证整类径向构型上界Δ≤Uₙexp(−d)。例：n=100时，所有库仑尺度平方半径在[49/50,1]的角度任意构型均有δ≥1225/6，而全局最优δ≤1657/12，因此整个有厚度环域都不含全局最大者。它是条件构型类的上界，不是对无条件Uₙ常数的刷新。小CDF偏差也不能反推最优性。

## 4. 当前状态、复核和范围

旧页的四项状态已直接更新：十点四阶局部最大、完整网格、十点>121/100整数构型、六点特定Hermite上界方法障碍。六七点外部物理分类覆盖及七点356次枝未独立重建的限制保留。[状态更新记录](STATUS_UPDATE.md)。

只需Python标准库：

```bash
python -B -S -O verify_all.py
python -B -S phase_graph.py 30
python -B -S radial_distribution.py 1000000 --s 1
```

核验包含全部99个相位家族、38个上升形状、14个独立非驻点上升对照、径向分布及根包围、旧Hermite入口和完整下界比较。相位计算覆盖n≤100，一步上升比较覆盖n≤30；没有冒充执行更大点数的上升或大网格。

[源哈希](source_manifest.json) · [核验报告](verification_report.json) · [完整离线包](mordell-configuration-bounds-2026-10-28.zip)。旧包络依赖按原字节随包保存；网页状态更新的快照另见status_updates.zip。程序及AI交叉审阅不等于外部同行评审或整篇形式化证明，不作全球优先权声明，未指定许可证。
