# 八点 Mordell：真实驻点稳定性的三阶联合角向—径向代数证书

**日期：**2026-11-01。基于仓库 `harrykane8816627373-cell/mordell-research` 的提交 `22a6de864a47ddf1c50e1fd0480dd607a52e2968` 和本次会话中先前已推导的四模式 Gram 子式。

**证明状态：**本文证明一个新的**全局必要条件**，不需要预设局部小幂矩、候选目标值或旧椭圆。该条件不是整个八点问题的无解证书，不能推出八点全局锐界。代码使用有理数复核基准和代数独立性实例，不构成所有复系数情形的形式化证明。

## 1. 假设与五个变量

取八个互异复数 `q_i`，满足

\[
 \sum q_i=0,\quad\sum|q_i|^2=7,\quad
 \sum_{j\ne i}\frac{1}{q_i-q_j}=4\overline{q_i},
\]

并假设完整稳定性 `\|B(q)/4\|\le1`，其中

\[
 (B(q)h)_i=\sum_{j\ne i}\frac{h_i-h_j}{(q_i-q_j)^2}.
\]

记 `t_i=|q_i|^2`，`s_k=\sum q_i^k`，并设

\[
 x=\sum t_i^2>0,\quad y=\sum t_i^3,\quad
 a=s_2,\quad b=s_4.
\]

下述结论只用 `x,y,a,b`，即四个标量变量、其中 `a,b` 各为复数（共六个实分量）；在非零 `a` 分支将其旋转成正实数，便只有**五个实分量**。

定义四个实/复多项式：

\[
 \begin{split}
 A&=196-24x-|a|^2,\\
 f&=-120y^2+288xy-162x^2+x(4|a|^2-|b|^2),\\
 g&=(145x-91y)a-x\overline a\,b,\\
 h&=(11x-8y)b+xa^2.
 \end{split}
\]

## 2. 定理：一个整数系数 3×3 Hermitian 多项式矩阵必半正定

**定理。** 对以上所有真实、完全稳定的八点驻点，有

\[
 \boxed{
 \mathcal M(x,y,a,b)=
 \begin{pmatrix}
  120f&120g&15h\\
  120\bar g&120xA+3136x^2-8281|a|^2&91(xa-\bar a b)\\
  15\bar h&91(x\bar a-a\bar b)&x^2-|b|^2
 \end{pmatrix}\succeq0.}
 \tag{J}
\]

矩阵的每个条目都是实变量 `x,y,Re(a),Im(a),Re(b),Im(b)` 上的多项式，**系数为整数**。因此可直接转化为全部七个非空主子式非负的实多项式约束，无须显式求出复根，也无须保留径向八阶矩或混合矩 `W`。

### 证明

**第 1 步：驻点 Ward 关系。** 对任意正整数 `k`，逐对对称化驻点方程得到

\[
 \sum_i t_iq_i^k=\frac{15-k}{8}s_k
 +\frac18\sum_{j=1}^{k-1}s_js_{k-j}.
\]

特别地

\[
 \sum t_iq_i^2=\frac{13}{8}a,\qquad
 \sum t_iq_i^4=\frac{11}{8}b+\frac18a^2.
 \tag{W}
\]

**第 2 步：完整稳定性的四模式 Schur 子式。** 在函数 `1,q^2,q^4` 上，取

\[
 K(f,g)=\langle f,g\rangle-
 \left\langle\tfrac14Bf,\tfrac14Bg\right\rangle\succeq0.
\]

对常数模式做 Schur 补（参见前阶段 `PROJECTED_FOURTH_MODE_CUT.md`），得到

\[
 \begin{pmatrix}A&D\\\overline D&C\end{pmatrix}\succeq0,
\]

其中

\[
 \begin{aligned}
 C&=-120R_8+288y-162x+4|a|^2-|b|^2,\\
 D&=145a-56W-\bar a b,\\
 R_8&=\sum_i t_i^4,\qquad W=\sum_i t_i^2q_i^2.
 \end{aligned}
\]

令 `V=xR_8-y^2=\sum_{i<j}t_i^2t_j^2(t_i-t_j)^2\ge0`，则

\[
 C=\frac fx-\frac{120V}{x}.
 \tag{1}
\]

**第 3 步：同一径向方差中的两个角向模式。** 对 `t_i>0` 定义 `u_i=q_i^2/t_i`，所以 `|u_i|=1`；对 `t_i=0` 任取 `u_i=0`（其权重为0）。使用权重 `w_i=t_i^2`，在加权复 Hilbert 空间里令

\[
 m_1=\sum_i w_iu_i=\frac{13}{8}a,
 \qquad m_2=\sum_i w_iu_i^2=b,\qquad \mu=y/x.
\]

定义中心化角向向量

\[
 \phi_1=u-m_1/x,\qquad \phi_2=u^2-m_2/x,
\]

及实径向向量 `v_i=t_i-\mu`。于是

\[
 \begin{aligned}
 \|v\|_w^2&=V/x,\\
 \|\phi_1\|_w^2&=x-|m_1|^2/x,\\
 \|\phi_2\|_w^2&=x-|m_2|^2/x,\\
 \langle\phi_1,\phi_2\rangle_w&=m_1-\bar m_1m_2/x.
 \end{aligned}
 \tag{2}
\]

并且由 (W) 得到两个协方差：

\[
 \begin{aligned}
 E_1&=\langle v,\phi_1\rangle_w=W-\mu m_1,\\
 E_2&=\langle v,\phi_2\rangle_w
 =\left(\frac{11}{8}-\mu\right)b+\frac18a^2.
 \end{aligned}
 \tag{3}
\]

注意 `D+56E_1=(145-91\mu)a-\bar a b=g/x`。后者的 `x` 因子必须保留。

**第 4 步：构造三向量 Gram。** 由于 `A,C≥0`、`|D|^2≤AC`，存在辅助 Hilbert 空间的向量 `\eta,\xi` 满足

\[
 \|\eta\|^2=C,\quad\|\xi\|^2=A,
 \quad\langle\eta,\xi\rangle=D.
\]

在该辅助空间与加权径向空间的直和上，定义

\[
 \begin{aligned}
 U&=(\eta,\sqrt{120}\,v),\\
 V_1&=(\xi,56\phi_1/\sqrt{120}),\\
 V_2&=(0,\phi_2/\sqrt{120}).
 \end{aligned}
\]

它们的 Gram 矩阵必半正定。由 (1)–(3)，可直接计算

\[
 \begin{aligned}
 \langle U,U\rangle&=f/x,\\
 \langle U,V_1\rangle&=g/x,\\
 \langle U,V_2\rangle&=h/(8x),\\
 \langle V_1,V_1\rangle&=A+\frac{392}{15}\left(x-\frac{|m_1|^2}{x}\right),\\
 \langle V_1,V_2\rangle&=\frac7{15}\left(m_1-\frac{\bar m_1b}{x}\right),\\
 \langle V_2,V_2\rangle&=\frac1{120}\left(x-\frac{|b|^2}{x}\right).
 \end{aligned}
\]

乘以 `120x>0`，并代入 `m_1=13a/8`，恰得到整数系数矩阵 (J)。定理证毕。

## 3. 两个显式、无高阶辅助变量的推论

取 (J) 的 `(1,2)` 与 `(1,3)` 主子式，分别得到

\[
 \boxed{
 15|g|^2\le xf(15A+392x)-\frac{8281}{8}f|a|^2.}
 \tag{P1}
\]

以及

\[
 \boxed{15|h|^2\le8f(x^2-|b|^2).}
 \tag{P2}
\]

(P1) 比上一轮的 `15|g|²≤xf(15A+392x)` 严格更紧（在 `f>0,a\ne0` 时）；(P2) 是新得到的四阶角向—径向耦合约束。**完整 (J) 还要求其行列式非负**，该条件不由独立检查 (P1)、(P2) 自动推出。

另有全部实际点集都满足的加权角向 Toeplitz 约束

\[
 \boxed{\left|xb-\frac{169}{64}a^2\right|\le
 x^2-\frac{169}{64}|a|^2.}
 \tag{T}
\]

证明：对单位复数 `u_i` 的加权矩 `m_0=x,m_1=13a/8,m_2=b`，其 `3×3` Toeplitz Gram 半正定；取 Schur 补即可。

## 4. 严格性：三阶行列式不是冗余条件

考虑仅用于**代数松弛比较**的如下有理矩数据：

\[
 x=\frac{67}{10},\quad
 y=\frac{3283}{500},\quad
 a=-\frac9{10},\quad
 b=-\frac94,\quad s_3=0.
\]

精确验算表明它满足旧椭圆、`x≥49/8`、`y≥x²/7`、旧标量稳定性 `A,B,f>0`、(P1)、(P2)、(T)，甚至 **(J) 的所有 1 阶和 2 阶主子式都严格为正**，但

\[
 \boxed{\det\mathcal M=-\frac{150328589710961619}{6250000}<0.}
\]

因此新的三阶行列式确实删除了旧松弛系统允许的一部分数据。**此数据没有被证明对应真实八点或驻点；它不是新驻点、不是极大值反例，也不证明某个实际非零矩驻点已经被排除。**

同时，另一组松弛数据 `x=y=7,a=1/10,b=s_3=0` 满足 (J) 的全部主子式严格为正。因此，单凭 (J)+旧椭圆不能证明整个非零矩系统无解。仍须与真实驻点根多项式、其共轭配对、判别式阈值、其他已有全域约束联合认证。

## 5. 可复现入口与尚缺的一步

在本文件及以下三个 Python 文件位于同一目录时：

```bash
python -B -S -O verify_angular_radial_projection.py
python -B -S -O verify_joint_angular_radial_matrix.py
```

依赖 `unified_stability_matrix.py` 提供既有的精确代数驻点基准。全部验收为 `Fraction` 精确比较，没有用浮点容差决定通过；对一般复变量成立的解析推导在上文，程序仅精确测试选定的有理实例。

在真正的全域消元中，可以把 `a=s_2>0` 设成实数（整体旋转规范），写 `b=u+iv`，加入 `\mathcal M\succeq0` 的全部主子式作为 **五实变量**（`x,y,a,u,v`）的投影必要条件，再接入已经建立的真实驻点多项式配对和 `Δ_q≥7^7`，求出可重放的 CAD/SOS/区间无解证书。

**目前还没有得到此无解证书，完整八点锐界仍未证明。**

## 6. 消去相位符号的一个额外结构（精确四次项）

在 `a=s₂>0` 的旋转规范下，令 `b=u+iv`，其中 `u,v∈R`。矩阵 (J) 的行列式是一个**只依赖 `v²` 的二次多项式**：

\[
 \boxed{
 \det\mathcal M
 =c_0(x,y,a,u)+c_1(x,y,a,u)v^2
 +3840x^2(8x+735)v^4.}
 \tag{Q}
\]

`c₀,c₁` 为相应的实多项式系数（可直接从 (J) 取得，无须展开所有项）。该表示没有 `v⁶` 或奇次幂，且在 `x>0` 时 `v⁴` 的系数**严格为正**。证明：在 (J) 的记号下，写 `p=M11,d=M22,r=M33,q=M12,e=M23,h=M13`，则

\[
 \det\mathcal M=p(dr-|e|^2)-|q|^2r-d|h|^2
 +2\Re(qe\bar h).
\]

其中 `p`、`r` 在 `v` 上至多二次，`q,e,h` 至多一次。共轭反射 `v→−v` 保持行列式不变，故只出现偶次幂。收集 `v⁴` 项，并代入 `d=120xA+3136x²-8281a²`，得到

\[
 120x(d+8281a^2)+14400a^2x^2
 =3840x^2(8x+735).
\]

因此令 `\nu=v²≥0`，则行列式在 `\nu` 上严格凸。对于固定 `x,y,a,u` 及有理区间 `\nu∈[L,U]`，若精确核验 `\det\mathcal M(L)<0` 且 `\det\mathcal M(U)<0`，便可**一次性严格排除该整段相位平方区间**，无须逐点扫描。这只是一个有条件的区间排除规则，并未找到覆盖整个剩余物理系统的区间族。
