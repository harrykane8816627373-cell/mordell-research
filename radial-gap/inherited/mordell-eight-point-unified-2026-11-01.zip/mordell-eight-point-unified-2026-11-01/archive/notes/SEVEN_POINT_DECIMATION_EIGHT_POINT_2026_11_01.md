# Eight-point Mordell discriminant: sharp-seven-point decimation certificate

**Status:** A fully quantified *conditional-on-the-established-seven-point-theorem* necessary inequality for eight points. **This is not** a proof that the remaining eight-point semialgebraic system is empty. Date: 2026-11-01.

## Normalization and exact prior input

Let \(q_1,\dots,q_8\in\mathbb C\) be distinct, centered, and satisfy
\[
\sum_iq_i=0,\qquad \sum_i|q_i|^2=7,\qquad
\Delta_8=\prod_{i<j}|q_i-q_j|^2\ge 7^7.
\]
Use the previously established seven-point sharp bound, including its externally sourced classification dependency as disclosed in the repository:
\[
\max_{\sum_{j=1}^7 |u_j|^2=7}\Delta_7(u)
= M_7=\frac{7^{21}}{6^{15}}.
\]
Translation is harmless and scaling a seven-point set with centered squared mass \(m\) multiplies its squared-distance product by \((m/7)^{21}\), hence \(\Delta_7\le m^{21}/6^{15}\).

## Theorem A (a sharp-seven-point decimation bound for each edge)

For any \(i\ne j\), write \(d=|q_i-q_j|^2\). Then
\[
\boxed{\Delta_8\le\frac{d(56-d)^{27}}{2^{15}3^{75}}.}\tag{A}
\]
In particular, on the target superlevel set \(\Delta_8\ge7^7\),
\[
\boxed{|q_i-q_j|^2>\frac{27}{250}\quad \text{for all }i\ne j.}\tag{B}
\]

**Proof.** Fix \(i\), put \(t=|q_i|^2\). The remaining seven points have sum \(-q_i\), raw second moment \(7-t\), and centered second moment
\[
m=7-t-\frac t7=7-\frac87t\ge0.
\]
Thus their internal 21-edge product satisfies
\[
\Delta_{-i}\le\frac{(7-\frac87t)^{21}}{6^{15}}.
\]
For the six distances from \(q_i\) excluding the edge \((i,j)\), the exact sum of their squares is \(7+8t-d\). AM--GM bounds their product by \(((7+8t-d)/6)^6\). Therefore
\[
\Delta_8\le \frac{d}{6^{21}}
(7+8t-d)^6(7-\tfrac87t)^{21}.
\]
The admissible parameters satisfy \(0\le d\le56\), \(0\le t\le49/8\), and both factors inside the last powers are nonnegative. For fixed \(d\), define \(A=7+8t-d\) and \(B=7-8t/7\). In the positive interior, the derivative of \(A^6B^{21}\) has the sign of \(2B-A=7+d-(72/7)t\). Its maximum occurs at
\[
t_* =\frac{7(7+d)}{72},\qquad A_*=\frac{2(56-d)}9,\qquad B_*=\frac{56-d}{9}.
\]
The same inequality holds at endpoints by continuity. Substitution gives (A), since \(2^6/(6^{21}9^{27})=1/(2^{15}3^{75})\).

For \(0\le d\le27/250<2\), the function \(d(56-d)^{27}\) is increasing because its derivative is \((56-d)^{26}(56-28d)>0\). An exact integer comparison (reproduced in `verify_seven_point_decimation.py`) gives
\[
\frac{(27/250)(56-27/250)^{27}}{2^{15}3^{75}}<7^7.
\]
Consequently \(d\le27/250\) is impossible when \(\Delta_8\ge7^7\), proving (B). Numerical root of the equality in (A) is approximately \(0.1088869516\), supplied only for orientation; its numerical computation is **not** an unsatisfiability certificate.

## Theorem B (global root-derivative control)

Let \(P(X)=\prod_{i=1}^8(X-q_i)\). For each root \(q_i\),
\[
\boxed{|P'(q_i)|^2\left(7-\tfrac87|q_i|^2\right)^{21}\ge7^7 6^{15}.}\tag{C}
\]
As \(7-8|q_i|^2/7\le7\), this implies the convenient absolute bound
\[
\boxed{|P'(q_i)|^2\ge\frac{6^{15}}{7^{14}}>\frac23.}\tag{D}
\]
Indeed, the exact factorization \(\Delta_8=|P'(q_i)|^2\Delta_{-i}\) and the seven-point upper bound for \(\Delta_{-i}\) give (C); (D) follows immediately. All comparisons are exact integers.

### Consequence for the degree-16 stationarity polynomial

For \(D_i=P''(q_i)-8\overline{q_i}P'(q_i)\) and \(\mathscr S_{16}=\sum_i|D_i|^2\), the actual force residuals
\[
r_i=\sum_{j\ne i}\frac1{q_i-q_j}-4\overline{q_i}=\frac{D_i}{2P'(q_i)}
\]
satisfy the **stronger certified conversion**
\[
\boxed{\sum_i|r_i|^2\le\frac{7^{14}}{4\,6^{15}}\mathscr S_{16}<\frac38\mathscr S_{16}.}\tag{E}
\]
This replaces the earlier bound \((65/4)\mathscr S_{16}\) by a factor more than 43 smaller. In any exact interval branch, the derivative bound (C) is even more informative than the uniform (D).

Also, on the target superlevel region, every inverse-square pair coefficient satisfies
\[
\left|\frac1{(q_i-q_j)^2}\right|=\frac1{|q_i-q_j|^2}<\frac{250}{27}.
\]
Consequently the complex weighted Laplacian \(B\) has operator norm bounded by \(8\cdot250/27=2000/27\) (using \(\sum_{i<j}|h_i-h_j|^2\le8\|h\|^2\)). This is a global *coarse* interval bound, not a stability classification.

## Incorporation into the eight-point feasibility problem

On the candidate-target superlevel set, one can replace the earlier \(1/436\) collision cutoff by \(27/250\) for **all 28 edges**, and impose either (C) for each root or simply (D). These rigorously help certify polynomial division, interval Hessians, and conversion from \(\mathscr S_{16}\) to actual force residuals.

They **do not** show that the global system containing stationarity, PSD stability, the moment ellipse, \(E_{\mathrm{rad}}>1/40000\), and \(\Delta_8\ge7^7\) is empty. No CAD, SOS or complete branch-and-bound certificate was produced. The dependence on the exact seven-point theorem, and its previously disclosed external classification input, must remain visible.

## Independent exact arithmetic checks

Run from the directory containing this file:

```bash
python -B -O verify_seven_point_decimation.py
```

Only the standard library is needed. This checks integer comparisons, the optimized parameter identities, the stronger derivative constant, and the claimed rational cutoff. The maximization and application of the seven-point theorem are mathematical arguments above, not consequences of finite sample verification.

## Practical symmetry gauge for a complete interval certificate

For any non-colliding centered eight-point configuration of total squared mass 7, at least one point obeys \(|q_i|^2\ge7/8\). Permute labels so that this point is \(q_1\), choose it of maximal modulus, and rotate globally so that \(q_1\) is positive real. Consequently a complete *real-coordinate* search may impose, without excluding a configuration,
\[
\Im q_1=0,\qquad (\Re q_1)^2\ge7/8,\qquad |q_j|^2\le(\Re q_1)^2\quad(j=2,\ldots,8).
\]
The centering conditions remove the real and imaginary coordinates of one additional point, while normalization supplies one equation. This gauge fixes the continuous rotational symmetry without dividing by a small low-order moment such as \(s_2\) (whose vanishing can otherwise create singular gauge charts). It does *not* itself show that the remaining polynomial system has no solutions.
