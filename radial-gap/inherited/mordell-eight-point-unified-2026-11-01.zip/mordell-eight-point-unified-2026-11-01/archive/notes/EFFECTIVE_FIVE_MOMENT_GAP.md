# 八点 Mordell：真实驻点的系数二择一与可计算五矩排除半径

**研究笔记，2026-11-01。** 在 `harrykane8816627373-cell/mordell-research` 主分支 `22a6de864a47ddf1c50e1fd0480dd607a52e2968` 基础上继续推导。保留现有 `eight-point/ENERGY_BASIN.md` 的六矩管域定理为一个明确的已证明输入。**尚未证明八点完整无条件锐界，也没有排空六个远端分支。** 附带 `verify_effective_five_moment_gap.py` 使用标准库有理数核验全部显式常数；解析恒等式和逻辑桥梁由本文证明。

## 1. 记号及待研究对象

工作在 `q=w/2=\sqrt{7/8}\,z` 尺度。一个无碰撞真实驻点满足

\[
\sum_{i=1}^8q_i=0,\quad\sum_{i=1}^8|q_i|^2=7,\quad
\sum_{j\ne i}\frac1{q_i-q_j}=4\bar q_i.
\]

第一个等式由驻点力方程求和给出，第二个由逐点乘 `q_i` 后求和给出。令 `s_k=\sum q_i^k`，根多项式为

\[
P(X)=\prod_i(X-q_i)=X^8+\sum_{k=2}^6c_kX^{8-k}+aX+b,
\quad a=c_7,\quad b=c_8.
\]

目标值 `T=7^7`，并记 `\Delta_q=\prod_{i<j}|q_i-q_j|^2=|\operatorname{Disc}P|`。

## 2. 定理 A：显式全域系数二择一

**定理 A。** 任意上述真实驻点，若

\[
\varepsilon=\max_{2\le k\le6}|s_k|\le\frac18,
\]

则

\[
\boxed{\min\{|c_7|,|c_8|\}\le82000\varepsilon.}
\]

不需要稳定性、目标值下界、旧低阶矩椭圆，也不要求预先靠近候选轨道。

**证明。** Newton 恒等式及 `s_1=c_1=0` 给

\[
k c_k=-s_k-\sum_{j=2}^{k-2}c_j s_{k-j},\quad 2\le k\le6.
\]

从 `\varepsilon\le1/8` 归纳可得 `|c_k|\le\varepsilon`（`k=2,\dots,6`）。写 `t_i=|q_i|^2`。利用根恒等式 `P(q_i)=0` 和**真实驻点**等式

\[
q_iP''(q_i)=8t_iP'(q_i),
\]

直接整理，得到**逐根精确代数式**

\[
\boxed{7a q_i(t_i-1)+b(8t_i-7)
=-\frac18\sum_{k=2}^6 k(k-15+8t_i)c_k q_i^{8-k}.}\tag{1}
\]

若需不借助根的检验，可在多项式环 `\mathbb Z[a,b,c_2,\ldots,c_6,X,t]` 中展开准确恒等式

\[
X(XP''-8tP')-8(7-8t)P
=8\{7aX(t-1)+b(8t-7)\}
+\sum_{k=2}^6k(k-15+8t)c_kX^{8-k}.
\]

每个根的 `t_i\in[0,7]`，且 `|q_i|\le\sqrt7<8/3`。于是式 (1) 右边的模长至多

\[
M\varepsilon,
\quad M=\sum_{k=2}^6\frac{k(k+41)}8\left(\frac83\right)^{8-k}
=\frac{5849680}{729}<8025.\tag{2}
\]

若 `a=0` 或 `b=0`，结论显然。其余情况，选择角度 `\theta=\arg a-\arg b`，使 `e^{-i\arg b}a q_i=|a|e^{i\theta}q_i`，而 `e^{-i\arg b}b=|b|`。记 `y_i=\Im(e^{i\theta}q_i)`。由于

\[
\sum_{i=1}^8 y_i^2
=\frac{7-\Re(e^{2i\theta}s_2)}2
\ge\frac{7-\varepsilon}2,
\]

必有至少一个 `i` 满足

\[
|y_i|\ge\sqrt{\frac{7-\varepsilon}{16}}>
\frac{13}{20}\qquad(\varepsilon\le1/8).
\]

固定这个根，取式 (1) 两边旋转后的虚部，得

\[
7|a|\,|t_i-1|\,|y_i|\le M\varepsilon.\tag{3}
\]

若 `|t_i-1|>1/16`，则

\[
|a|<\frac{320}{91}M\varepsilon<82000\varepsilon.
\]

若 `|t_i-1|\le1/16`，则 `|8t_i-7|=|1+8(t_i-1)|\ge1/2`；回到式 (1)，利用 (3) 得

\[
|b|\le2M\varepsilon\left(1+\frac{|q_i|}{|y_i|}\right)
<\frac{398}{39}M\varepsilon<82000\varepsilon.
\]

两种情形必居其一，证毕。注意本证明使用 `|s_2|` 保证在每个方向都存在一个明显离开该直线的根，而非假设所有根接近某种先验构型。

## 3. 引理：第七系数与径向四阶矩的联合约束

令 `R_4=\sum_i|q_i|^4`。驻点力方程乘 `q_i^2` 后求和，给出

\[
\sum_i|q_i|^2q_i=0.
\]

将式 (1) 逐项乘 `\bar q_i` 后求和，利用 `\sum\bar q_i=\sum t_i\bar q_i=0`，可消去 `b` 项，得到**精确恒等式**

\[
7a(R_4-7)
=-\frac18\sum_{k=2}^6 k c_k
 \sum_i (k-15+8t_i)q_i^{8-k}\bar q_i.
\]

再由式 (2)、`\sum|q_i|\le\sqrt{56}<8` 得

\[
\boxed{|c_7|\left|\sum_i|q_i|^4-7\right|<10^4\varepsilon.}\tag{4}
\]

式 (4) 说明在 `c_7` 不小的挑战者中，第四径向矩必须接近候选的准确值 `7`。它本身不排除高矩分支。

## 4. 定理 B：显式五矩隔离半径（无需先控 `s_8`）

**定理 B。** 任意互异真实驻点，若

\[
\boxed{\Delta_q\ge7^7,\qquad\max_{2\le k\le6}|s_k|\le10^{-7},}
\]

则必为旋转、重排意义下的 `\{0,1,\zeta,\dots,\zeta^6\}`, `\zeta^7=1`。

**证明第一支：`|b|\le82000\varepsilon`。** Newton 的 `k=8` 恒等式为

\[
s_8=-8b-\sum_{k=2}^6 c_k s_{8-k},
\]

其中 `c_7s_1=c_1s_7=0`。所以

\[
|s_8|\le8(82000)\varepsilon+5\varepsilon^2
\le\frac{1312000000001}{20000000000000}<\frac18
\quad(\varepsilon\le10^{-7}).
\]

同时 `|s_2|,\ldots,|s_6|\le1/8`。因此六个矩 `s_k`（`k\in\{2,3,4,5,6,8\}`）都落进仓库 `eight-point/ENERGY_BASIN.md` 已严格证明的六矩目标值排除管域。该定理说明满足 `\Delta_q\ge7^7` 的构型在管域内必须是中心正七边形候选。

**证明第二支：`|a|\le82000\varepsilon`。** 令 `P_0(X)=X^8+b`，考虑

\[
P_\lambda=P_0+\lambda E,\qquad
E(X)=\sum_{k=2}^6c_kX^{8-k}+aX,\quad0\le\lambda\le1.
\]

由 AM–GM 和质量约束，对原始 `P` 有

\[
|b|=\prod_i|q_i|\le(7/8)^4.
\]

故

\[
|\operatorname{Disc}(P_0)|=8^8|b|^7
\le\frac{7^{28}}{8^{20}}<\frac{7^7}2.\tag{5}
\]

后一严格比较等价于整数不等式 `2\cdot7^{21}<8^{20}`。

现在关键是利用 `P_0` 的旋转对称性把判别式**一阶扰动完全消掉**。首一八次多项式的判别式是系数 `c_k` 的权重 `k` 的齐次多项式，权重总数为 `8\cdot7=56`。在 `P_0=X^8+b` 处，只有权重 `8` 的 `b` 非零；若对任何 `c_k`（`2\le k\le7`）出现一次项，则必有 `k+8m=56`，但这是不可能的。因此

\[
\frac{d}{d\lambda}\operatorname{Disc}(P_\lambda)\Big|_{\lambda=0}=0.\tag{6}
\]

写 `f(\lambda)=\operatorname{Disc}(P_\lambda)`，即十五阶 Sylvester 行列式。它包含 `7` 行 `P_\lambda`、`8` 行 `P_\lambda'`，每行对 `\lambda` 仿射。注意 `|a|\le82000\varepsilon`，`|c_k|\le\varepsilon`。当 `\varepsilon\le10^{-7}`，所有 `\lambda\in[0,1]` 的系数行欧氏范数分别严格小于

\[
A=\frac76,\qquad B=\frac{81}{10},
\]

对应行导数范数至多 `(82000+5)\varepsilon` 和 `(82000+20)\varepsilon`。对 `f''` 展开所有**有序**的两个不同替换行，再用 Hadamard 不等式，并利用 (6) 及 Taylor 积分余项，得到

\[
|\operatorname{Disc}(P)-\operatorname{Disc}(P_0)|\le L_2\varepsilon^2,
\]

其中精确的有理常数是

\[
\begin{aligned}
L_2={}&21(82005)^2 A^5B^8\\
&+28(82020)^2A^7B^6\\
&+56(82005)(82020)A^6B^7
\end{aligned}
\]

并且精确有理比较保证

\[
L_2(10^{-7})^2<\frac{7^7}{2}.\tag{7}
\]

综合 (5)、(7)，得到 `\Delta_q=|\operatorname{Disc}(P)|<7^7`，与目标值门槛矛盾。于是第二支不存在，定理 B 证毕。

## 5. 与当前未覆盖集合的关系

本轮增加了两条必要关系：

\[
\boxed{\text{非候选真实驻点且 }\Delta_q\ge7^7
\quad\Longrightarrow\quad\max_{2\le k\le6}|s_k|>10^{-7},}
\]

以及在 `\varepsilon\le1/8` 时的系数二择一及径向四阶矩控制。第一条在五个低阶幂矩很小而 `s_8` 任意的情况下有用：无需给 `s_8` 设条件，就能排除此种挑战者。

但在全域上，先前六矩管域只保证非候选挑战者至少有一个 `|s_k|>1/8`，而本轮五矩下界只达到 `10^{-7}`。这些必要条件不能推出所有 `B_2,B_3,B_4,B_5,B_6,B_8` 交集为空。现有低阶椭圆、真正的二阶稳定矩阵以及目标值约束仍须联合研究。

## 6. 可重放的数值论证边界

```
python -B -S -O verify_effective_five_moment_gap.py
```

程序用 `fractions.Fraction` 检查 (2) 的精确值、二择一常数、所有 Sylvester 行范数上界、一阶零项的权重条件、二阶行列式扰动的有理不等式、径向四阶系数和对不安全较大 `\varepsilon` 的拒绝。证明中使用的 Newton 恒等式、真实驻点逐根关系、Hadamard 不等式、判别式权重及旧六矩目标值排除由正文承担。它**不是**对所有复构型做过有限枚举，不提供自动形式化的完整证明，也未完成八点全局锐界。
