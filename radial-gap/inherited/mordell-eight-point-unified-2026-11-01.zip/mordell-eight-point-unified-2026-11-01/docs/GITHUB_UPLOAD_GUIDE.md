# 上传 GitHub 的建议

本包推荐作为原仓库下的**新研究目录**，不要覆盖已有阶段证明或历史归档，以免丢失版本来源。

例如在克隆的 `mordell-research` 仓库根目录下创建 `eight-point/unified-2026-11-01/`，把此 ZIP 解压后的目录内容复制进去。然后：

```bash
git add eight-point/unified-2026-11-01
git commit -m "Add reviewed eight-point consolidation and radial Schur envelope"
git push origin main
```

若要先经同伴审核，推荐创建单独分支并提交 PR，而不是直接推送 `main`。

请先运行 `python -B -O verification/verify_all.py`（在新目录内），确认代码通过。若准备正式在公开仓库中宣传新定理，建议独立逐行检查 `docs/NEW_COMBINED_RESULTS.md`，尤其是它对半径界、管域定理和七点锐界的依赖。

由于原项目未指定许可证，这个研究包也未替你决定 LICENSE。源文件和旧证明的署名、外部证明归属应沿用原仓库，不应将有限脚本的 `PASS` 写成问题已解。
