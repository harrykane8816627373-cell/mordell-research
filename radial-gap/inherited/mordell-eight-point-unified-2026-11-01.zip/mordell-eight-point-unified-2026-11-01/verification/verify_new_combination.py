"""Exact checks for the 2026-11-01 combined eight-point necessary conditions.

Arithmetic checks only; this does not prove the inherited global lemmas or the
full eight-point Mordell conjecture. Python 3 standard library, -O safe.
"""
from fractions import Fraction as F
from math import prod

U = F(25, 16)
T = F(7**7)
ZERO = F(0)


def need(ok, msg):
    if not ok:
        raise ArithmeticError(msg)


def hm(m, x=U):
    return sum(((m-2-j)*x**j for j in range(m-2)), ZERO)


def check_identity(m):
    # Verify for every rational t in a fixed deterministic test set.
    # The full identity follows by the explicit symbolic telescoping proof
    # recorded in docs/NEW_COMBINED_RESULTS.md.
    for t in (F(0), F(1, 7), F(1), F(4, 3), U):
        lhs = t**m
        rhs = (m-1)*t*t-(m-2)*t+t*(t-1)**2*hm(m,t)
        need(lhs == rhs, f'H_{m} identity at t={t}')


def new_radial_threshold():
    eps = F(1, 35000)
    # From |x-7| <= sqrt(7 eps) < 1/70.
    need(7*eps < F(1, 70**2), 'new x-minus-7 threshold')
    rmax = 7 + F(6, 70) + hm(7)*eps
    need(rmax < F(64,9), 'radial powers through R14 bounded by 64/9')
    # Uniform Ward--Cauchy error |Q_k-s_k| < c=1/70.
    c = F(1,70)
    need(F(64,9)*eps < c*c, 'new uniform CS error')
    b = {}
    b[2] = F(8,5)*c
    b[3] = 2*c
    b[4] = (8*c+b[2]**2)/3
    b[5] = 4*c+b[2]*b[3]
    b[6] = 8*c+2*b[2]*b[4]+b[3]**2
    b[8] = 8*c+2*b[2]*b[6]+2*b[3]*b[5]+b[4]**2
    for k, v in b.items():
        need(v < F(1,8), f's{k} envelope below tube threshold')
    print('CERTIFIED: epsilon = 1/35000, all six moment moduli < 1/8')
    for k in (2,3,4,5,6,8):
        print(f'  |s{k}| <= {b[k]} = {float(b[k]):.12f}')
    print('  upper power moment uniform:',rmax)


def disc_envelope(x, y, ss):
    """New unconditional algebraic *majorant*, provided actual roots obey t<=25/16.

    To obtain the Ward-specialized Schur factors, the points must also be
    genuine force-4 stationary points. Here ss[k] are REAL rational moments
    for exact arithmetic benchmark configurations. Complex versions in proof.
    """
    e = y-2*x+7
    need(e >= 0, 'radial deficit nonnegative')
    L = {m:(m-1)*x-7*(m-2)+hm(m)*e for m in range(4,8)}
    s2,s3,s4,s5,s6 = (ss[k] for k in (2,3,4,5,6))
    V = [
       x-s2*s2/8,
       y-s3*s3/8-F(169,448)*s2*s2,
       L[4]-s4*s4/8-F(9,28)*s3*s3,
       L[5]-s5*s5/8-(11*s4+s2*s2)**2/448,
       L[6]-s6*s6/8-(10*s5+2*s2*s3)**2/448,
       L[7]-(9*s6+2*s2*s4+s3*s3)**2/448,
    ]
    need(all(z > 0 for z in V), 'Schur radial envelope factors positive')
    return L, V, F(56)*prod(V)


def benchmark():
    # Imported only in this benchmark.  The production theorem and the
    # standalone constants above need no earlier scripts.
    from unified_stability_matrix import certificate, det
    polys = {
      'candidate': [F(0), F(-1)]+[F(0)]*6+[F(1)],
      'regular_octagon': [-(F(7,8)**4)]+[F(0)]*7+[F(1)],
    }
    for name,p in polys.items():
        _C,H,_K,s=certificate(p)
        x,y=H[2][2], H[3][3]
        L,V,Ubound=disc_envelope(x,y,s)
        D=[]
        for k in range(2,8):
            # All quantities are rational for these models.
            d=H[k][k]-s[k]*s[k]/8-H[1][k]*H[1][k]/7
            D.append(d)
        need(all(V[k-2] >= D[k-2] for k in range(2,8)), 'majorant dominates true Schur diagonals')
        actual=det(H)
        need(actual<=F(56)*prod(D)<=Ubound, 'Hadamard-Schur radial majorant')
        if name=='candidate':
            need(actual==T and x==7 and y==7 and x*0==0,'candidate exact target')
        print(name, 'actual/T =',actual/T, 'new_majorant/T =',Ubound/T)


def projected_relaxation_is_nonempty():
    # Exact abstract moments from the earlier root-pairing counterexample.
    # These do NOT come from one eight-point stationary configuration.
    x,y=F(57,8),F(59,8)
    ss={2:F(1,10),3:F(1,10),4:ZERO,5:ZERO,6:ZERO}
    _L,V,upper=disc_envelope(x,y,ss)
    e=y-2*x+7
    a=ss[2]; b=ss[3]
    A=196-24*x-a*a
    B=312*x-128*y-1183-2*b*b
    P=F(56)*prod(V[2:])
    N=P*V[0]*V[1]-T
    C=P*F(9,400)*(a*b)**2
    Y=P*A*B/3200
    need(e>F(1,35000) and a*b!=0,'abstract example lies in residual region')
    need(a*a+F(54,175)*b*b<1,'abstract example obeys ellipse')
    need(A>0 and B>0 and N>0 and Y>0,'abstract example scalar cuts')
    need(C<=N+Y or (C-N-Y)**2<=4*N*Y,'abstract example two-disc cut')
    need(upper>T,'abstract example satisfies new moment discriminant majorant')
    print('CHECKED: the new 11-variable outer relaxation remains NONEMPTY;')
    print('  abstract example is NOT a physical root configuration or stationary point.')


def decimation_and_radius():
    d=F(27,250)
    bound=d*(56-d)**27/(2**15*3**75)
    need(bound<T,'seven-point decimation minimum separation')
    need(F(6**15,7**14)>F(2,3),'root derivative modulus lower bound')
    print('CERTIFIED: |q_i-q_j|^2 > 27/250 and |P\'(q_i)|^2 > 2/3 conditional on M7')


if __name__ == '__main__':
    for m in range(3,8):
        check_identity(m)
    new_radial_threshold()
    decimation_and_radius()
    benchmark()
    projected_relaxation_is_nonempty()
    print('PASS: new combined exact checks; NO global 8-point unsatisfiability certificate.')
