"""Exact rational check of projected fourth-mode stationary stability constraint.

Requires companion unified_stability_matrix.py for exact real-polynomial stationary
examples and verify_fourth_mode_cut.py for independent four-mode identities.
Complex-case algebra is proved in PROJECTED_FOURTH_MODE_CUT.md; this script
checks exact rational samples and a rational pseudo-moment strictness witness.
"""
from fractions import Fraction as F
from unified_stability_matrix import certificate
from verify_fourth_mode_cut import derived_submatrix


def need(ok, text):
    if not ok:
        raise ArithmeticError(text)


def reduced_cut(x,y,s2,s4):
    # Complex (Python Fraction is real for these audits); formula uses conjugation.
    A=F(196)-24*x-s2*s2
    f=-120*y*y+288*x*y-162*x*x+x*(4*s2*s2-s4*s4)
    G=(145*x-91*y)*s2-x*s2*s4
    return A,f,G,F(15)*G*G, x*f*(15*A+392*x)


def stationary_test(label,p):
    _,H,K,s=certificate(p)
    ids=[0,2,4]
    need([[K[i][j] for j in ids] for i in ids]==
         [[derived_submatrix(H,s)[i][j] for j in [0,1,3]] for i in [0,1,3]],label+': submatrix')
    x,y=H[2][2],H[3][3]
    A,f,G,left,right=reduced_cut(x,y,s[2],s[4])
    # If stable, projected cut is necessary. Candidate is stable.
    if label=='central heptagon':
        need(A>=0 and f>=0 and left<=right,'candidate must satisfy projected cut')
    if label=='regular octagon':
        need(f<0, 'octagon should be excluded by q4 diagonal already')
    print(label, 'A=',A,'f=',f,'projected LHS=',left,'RHS=',right)


def witness():
    # Formal rational moment data, NOT alleged to arise from eight points/stationarity.
    x=F(31,5)
    y=F(279,50)
    s2=F(1,2)
    s3=F(0)
    s4=F(0)
    A,f,G,left,right=reduced_cut(x,y,s2,s4)
    B=312*x-128*y-1183-2*s3*s3
    need(s2*s2+F(54,175)*s3*s3<1,'ellipse witness')
    need(x>=F(49,8) and y>=x*x/7,'basic radial moment constraints')
    need(A>0 and B>0 and f>0,'weaker scalar cuts must pass')
    need(left>right,'projected fourth-mode cut should fail')
    print('Rational abstract pseudo-moment data: x=31/5, y=279/50, s2=1/2, s3=s4=0')
    print('  weaker ellipse, A>=0, B>=0, f>=0, basic radial constraints: PASS')
    print('  projected polynomial LHS=',left,'RHS=',right,'=> FAIL (strict)')
    print('  This is algebraic independence, NOT an eight-point configuration.')


def run():
    z=F(0);o=F(1)
    stationary_test('central heptagon',[z,-o]+[z]*6+[o])
    stationary_test('regular octagon',[-F(7,8)**4]+[z]*7+[o])
    witness()
    print('All exact rational tests passed; no full six-branch exclusion.')

if __name__=='__main__':
    run()

# The main barrier is proved symbolically in the companion note. These exact
# constant checks certify its quantitative numerical comparison.
from fractions import Fraction as _Q
MAX_A_PLUS = _Q(196) + _Q(32,15)*_Q(49,6)
LEFT_COEFF = (_Q(631,10)-_Q(2))**2
RIGHT_COEFF = _Q(4)*MAX_A_PLUS
need(MAX_A_PLUS==_Q(9604,45),'barrier A bound')
need(LEFT_COEFF==_Q(373321,100),'barrier left coefficient')
need(RIGHT_COEFF==_Q(38416,45),'barrier right coefficient')
need(LEFT_COEFF>RIGHT_COEFF,'barrier contradiction exact')
print('Barrier certificate: 373321/100 > 38416/45; therefore s2!=0 and the old ellipse force R6/R4>9/10.')
