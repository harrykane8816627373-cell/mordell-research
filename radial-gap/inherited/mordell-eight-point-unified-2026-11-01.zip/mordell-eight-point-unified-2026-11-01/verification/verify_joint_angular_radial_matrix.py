"""Reproducible Fraction audit of a 3x3 Hermitian polynomial necessary cut.

The source note gives the mathematical proof for arbitrary complex s2,s4.
The exact finite examples here use real coefficients (the 3x3 is symmetric).
All tests are explicit; run python -B -S -O verify_joint_angular_radial_matrix.py.
No exhaustive branch elimination or n=8 maximum is certified.
"""
from fractions import Fraction as F
from unified_stability_matrix import certificate, is_psd


def check(b, label):
    if not b:
        raise ArithmeticError(label)


def det3(M):
    a,b,c=M[0]; d,e,f=M[1];g,h,i=M[2]
    return a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g)


def build(x,y,s2,s4):
    # Real inputs only for the exact audit. All conjugations are explicit in the note.
    A=F(196)-24*x-s2*s2
    f=-120*y*y+288*x*y-162*x*x+x*(4*s2*s2-s4*s4)
    g=(145*x-91*y)*s2-x*s2*s4
    h=(11*x-8*y)*s4+x*s2*s2
    diag=120*x*A+3136*x*x-8281*s2*s2
    off=91*s2*(x-s4)
    M=[[120*f,120*g,15*h],
       [120*g,diag,off],
       [15*h,off,x*x-s4*s4]]
    return A,f,g,h,M


def principal_minors(M):
    return [M[i][i] for i in range(3)]+[
        M[i][i]*M[j][j]-M[i][j]*M[j][i]
        for i,j in [(0,1),(0,2),(1,2)]]+[det3(M)]


def stationary_test(label,p):
    _,H,K,s=certificate(p)
    x,y,s2,s4=H[2][2],H[3][3],s[2],s[4]
    check(H[1][3]==F(13,8)*s2,label+': Ward k2')
    check(H[1][5]==F(11,8)*s4+s2*s2/8,label+': Ward k4')
    A,f,g,h,M=build(x,y,s2,s4)
    stable,_=is_psd(K)
    matrix_ok=all(v>=0 for v in principal_minors(M))
    if stable:
        check(matrix_ok,label+': full stable stationary violates projected matrix')
    print(label,'stable=',stable,'new_matrix_PSD=',matrix_ok,
          'det=',det3(M))


def strict_separation_witness():
    # Formal abstract rational moments, NOT an eight-point configuration.
    x=F(67,10);y=x*F(49,50);s2=F(-9,10);s3=F(0);s4=F(-9,4)
    A,f,g,h,M=build(x,y,s2,s4)
    B=312*x-128*y-1183-2*s3*s3
    pm=principal_minors(M)
    angular_toeplitz=((x*x-F(169,64)*s2*s2)**2-
                      (x*s4-F(169,64)*s2*s2)**2)
    check(s2*s2+F(54,175)*s3*s3<1,'ellipse')
    check(x>=F(49,8) and y>=x*x/7,'radial Cauchy lower bounds')
    check(A>0 and B>0 and f>0,'scalar cuts')
    check(angular_toeplitz>=0,'weighted angular Toeplitz')
    check(all(v>0 for v in pm[:6]),'all 1x1 and 2x2 principal minors')
    check(pm[6]<0,'the 3x3 determinant must be negative')
    print('formal pseudo-moments x=67/10, y=3283/500, s2=-9/10, s3=0, s4=-9/4:')
    print('  scalar A=',A,'B=',B,'f=',f)
    print('  all 1x1 and 2x2 principal minors positive; Toeplitz margin positive')
    print('  new determinant=',pm[6], ' (strictly negative)')
    print('  illustrates strictness of the JOINT cut only, not existence of a stationary point')


def run():
    z=F(0);o=F(1)
    stationary_test('central heptagon',[z,-o]+[z]*6+[o])
    stationary_test('regular octagon',[-F(7,8)**4]+[z]*7+[o])
    stationary_test('real Hermite stationary',[F(105,4096),z,-F(105,128),z,F(105,32),z,-F(7,2),z,o])
    strict_separation_witness()
    A,f,g,h,M=build(F(7),F(7),F(1,10),F(0))
    check(all(t>0 for t in principal_minors(M)),'the projected relaxation must remain nonempty')
    print('formal projected feasible data x=y=7,s2=1/10,s4=0: all principal minors strictly positive')
    print('ALL EXACT CHECKS PASSED; NO GLOBAL IMPOSSIBILITY CERTIFICATE')

if __name__=='__main__':
    run()
