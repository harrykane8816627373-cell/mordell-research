"""Exact check of phase-quartic leading coefficient with rational Gaussian pairs.

No CAS or floating-point calculations. Mathematical identity is proved in
EIGHT_POINT_JOINT_ANGULAR_RADIAL_CERTIFICATE.md. Verification uses several
independent rational substitutions and finite difference interpolation.
"""
from fractions import Fraction as F

def need(test, message):
    if not test: raise ArithmeticError(message)

def mul(z,w): return (z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0])
def conj(z): return (z[0],-z[1])
def norm(z):return z[0]*z[0]+z[1]*z[1]

def determinant(x,y,a,u,v):
    A=196-24*x-a*a
    f=-120*y*y+288*x*y-162*x*x+x*(4*a*a-u*u-v*v)
    p=120*f
    d=120*x*A+3136*x*x-8281*a*a
    r=x*x-u*u-v*v
    q=(120*a*((145*x-91*y)-x*u), -120*a*x*v)
    e=(91*a*(x-u),-91*a*v)
    h=(15*((11*x-8*y)*u+x*a*a),15*(11*x-8*y)*v)
    return p*(d*r-norm(e))-norm(q)*r-d*norm(h)+2*mul(mul(q,e),conj(h))[0]

def check_case(x,y,a,u):
    vals=[determinant(x,y,a,u,F(i)) for i in (0,1,2,3)]
    c0=vals[0]
    c2=(vals[2]-4*vals[1]+3*vals[0])/F(12) # 12*c4: f(2)-4*f(1)+3*f(0)
    leading=3840*x*x*(8*x+735)
    need(c2==leading,'quartic coefficient does not match exact identity')
    for v in (F(-3),F(-2),F(-1),F(1,2)):
        need(determinant(x,y,a,u,v)==determinant(x,y,a,u,-v),'evenness in Im(s4)')
        c1=vals[1]-c0-leading
        need(determinant(x,y,a,u,v)==c0+c1*v*v+leading*v**4,'quartic interpolation')
    need(leading>0,'quartic coefficient should be positive when x>0')
    print('x,y,a,Re(s4)=',x,y,a,u,'leading v^4 coefficient=',leading)

if __name__=='__main__':
    check_case(F(7),F(7),F(1,10),F(0))
    check_case(F(67,10),F(3283,500),F(9,10),F(-9,4))
    check_case(F(31,5),F(2263,400),F(3,10),F(-2))
    print('EXACT rational phase tests passed. No full exclusion proved.')
