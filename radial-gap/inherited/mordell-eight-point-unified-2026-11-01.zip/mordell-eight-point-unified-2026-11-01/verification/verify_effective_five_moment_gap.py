"""Exact arithmetic audit of the effective five-moment exclusion lemma.

This is a rational-inequality verifier, not a full formal proof and not an
exhaustive search for all eight-point stationary configurations.

Run: python -B -S -O verify_effective_five_moment_gap.py
"""
from fractions import Fraction as Q


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    eps = Q(1, 10**7)
    C = Q(82000)
    radius = Q(8, 3)
    y_min = Q(13, 20)
    T = Q(7**7)

    # Polynomial identity behind the stationary on-root formula:
    # for c_k*x^(8-k), coefficient of
    # x*(x*P'' - 8*t*P') - 8*(7-8*t)*P
    # is k*(k-15+8*t)*c_k*x^(8-k).  Check both t coefficients.
    for k in range(9):
        const = (8-k)*(7-k)-56
        tcoef = -8*(8-k)+64
        require(const == k*(k-15) and tcoef == 8*k,
                f'formal Euler-polynomial identity at k={k}')

    # Every root has |q_i| <= sqrt(7) < 8/3. If |s_2| <= 1/8,
    # for every angle there is a root with |Im(e^{i theta} q_i)| > 13/20.
    require(radius**2 > 7, 'root radius comparison')
    require((7-Q(1, 8))/16 > y_min**2, 'angular-moment comparison')

    # Newton's identities give |c_j| <= epsilon, 2 <= j <= 6,
    # whenever |s_2|,...,|s_6| <= epsilon <= 1/8.
    for k in range(2, 7):
        upper = (eps + max(0, k-3)*eps**2) / k
        require(upper <= eps, f'Newton induction k={k}')

    # From the exact on-root stationarity identity, the remainder is
    # bounded in modulus by M*epsilon at every root.
    M = sum((Q(k*(k+41), 8)*radius**(8-k)
             for k in range(2, 7)), Q(0))
    require(M == Q(5849680, 729), 'on-root remainder coefficient')
    near_t1_branch = 2*(1 + radius/y_min)*M
    far_t1_branch = Q(16, 7)/y_min*M
    require(C > near_t1_branch and C > far_t1_branch,
            'uniform linear dichotomy')

    # If |c_8| <= C epsilon, Newton at k=8 gives
    # |s_8| <= 8*C*epsilon + 5*epsilon^2, so all six moments fit
    # inside the repository's certified |s_k|<=1/8 energy tube.
    s8_bound = 8*C*eps + 5*eps**2
    require(s8_bound < Q(1, 8), 's8 moment-tube bound')

    # If |c_7| <= C epsilon, the Sylvester rows of P and P' along
    # P_0=x^8+c_8 -> P have these uniform Euclidean row norms.
    b_max = Q(7, 8)**4   # AM-GM: |c_8| = prod |q_i|
    A = Q(7, 6)
    B = Q(81, 10)
    p_row_squared = 1 + b_max**2 + 5*eps**2 + (C*eps)**2
    dp_row_squared = 64 + (6**2+5**2+4**2+3**2+2**2)*eps**2 + (C*eps)**2
    require(p_row_squared < A**2, 'Sylvester P row norm')
    require(dp_row_squared < B**2, 'Sylvester P prime row norm')

    # The discriminant is weighted-homogeneous of weight 8*7=56.
    # All c_2,...,c_7 have weights 2,...,7 (not 0 mod 8), so the
    # derivative of Disc(x^8+b+lambda*E) at lambda=0 vanishes.
    require(all((56-k) % 8 != 0 for k in range(2, 8)),
            'absence of first-order discriminant terms')

    # The 15x15 Sylvester determinant has 7 rows coming from P,
    # 8 rows from P'. For lambda in [0,1], each row is affine in
    # lambda. Hadamard + two-row replacement gives |Disc''|/2 <= L2 eps^2.
    L2 = (21*(C+5)**2*A**5*B**8
          +28*(C+20)**2*A**7*B**6
          +56*(C+5)*(C+20)*A**6*B**7)
    require(2*7**21 < 8**20, 'regular octagon strict objective gap')
    require(L2*eps**2 < T/2, 'quadratic discriminant perturbation bound')

    # A related radial fourth-moment identity gives
    # |c_7|*|sum |q_i|^4 - 7| <= (8/7) M epsilon < 10000 epsilon.
    require(Q(8, 7)*M < 10000, 'radial-fourth moment gap')

    # Intentionally invalid variants must be rejected with Python -O.
    for unsafe in (Q(1, 100), Q(1, 1000), Q(1, 10000)):
        require(not (8*C*unsafe + 5*unsafe**2 < Q(1,8)),
                'unsafe epsilon incorrectly accepted')

    print('All exact Fraction inequalities PASSED.')
    print('M:', M)
    print('Uniform coefficient dichotomy: min(|c7|,|c8|) <= 82000 epsilon')
    print('Certified epsilon: 1/10000000')
    print('Tube upper bound on |s8| in small-c8 branch:', s8_bound)
    print('Quadratic Sylvester derivative majorant L2:', L2)
    print('L2*epsilon^2:', L2*eps**2)
    print('Half of candidate discriminant 7^7/2:', T/2)
    print('No claim that all six global branches have been excluded.')


if __name__ == '__main__':
    main()
