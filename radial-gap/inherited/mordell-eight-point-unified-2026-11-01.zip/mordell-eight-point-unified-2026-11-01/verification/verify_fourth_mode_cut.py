"""Exact independent audit of the four-mode stationary stability restriction.

Uses the exact rational polynomial-quotient checker from the preceding research
stage, unified_stability_matrix.py, in the same folder. Python standard library.
The printed inequalities are NECESSARY conditions only, not an n=8 sharp proof.
"""
from fractions import Fraction as Q
from unified_stability_matrix import certificate, is_psd


def check(test, label):
    if not test:
        raise ArithmeticError(label)


def derived_submatrix(H, s):
    s2, s3, s4 = s[2], s[3], s[4]
    r4, r6, r8 = H[2][2], H[3][3], H[4][4]
    M, W, N = H[2][3], H[2][4], H[3][4]
    return [
        [Q(8), s2, s3, s4],
        [s2, Q(49,2)-3*r4, -5*M, Q(145,8)*s2-7*W],
        [s3, -5*M, Q(39,2)*r4-8*r6-Q(1183,16), Q(53,2)*M-11*N],
        [s4, Q(145,8)*s2-7*W, Q(53,2)*M-11*N,
         -15*r8+36*r6-Q(81,4)*r4+Q(1,2)*s2*s2]
    ]


def schur_cuts(H, s):
    r4,r6,r8=H[2][2],H[3][3],H[4][4]
    s2,s3,s4=s[2],s[3],s[4]
    W=H[2][4]
    A=196-24*r4-s2*s2
    B=312*r4-128*r6-1183-2*s3*s3
    C=-120*r8+288*r6-162*r4+4*s2*s2-s4*s4
    D=145*s2-56*W-s2*s4
    variance=r4*r8-r6*r6
    check(variance>=0, 'radial Cauchy variance negative')
    rad_sos=r4*variance
    # Check exact factorization of the radial low-moment relaxation
    low=C+Q(120)*variance/r4
    projected=-Q(120)*r6*r6/r4+288*r6-162*r4+4*s2*s2-s4*s4
    check(low==projected, 'radial elimination polynomial incorrect')
    return A,B,C,D,variance, projected


def run():
    zero=Q(0);one=Q(1)
    cases={
      'central heptagon':[zero,-one]+[zero]*6+[one],
      'regular octagon':[-Q(7,8)**4]+[zero]*7+[one],
      'real Hermite stationary':[Q(105,4096),zero,-Q(105,128),zero,Q(105,32),zero,-Q(7,2),zero,one],
    }
    for name,p in cases.items():
        Cpoly,H,K,s=certificate(p)
        ids=[0,2,3,4]
        actual=[[K[a][b] for b in ids] for a in ids]
        predicted=derived_submatrix(H,s)
        check(actual==predicted,name+': 4x4 exact moment formula differs from polynomial quotient K')
        A,B,C,D,var,proj=schur_cuts(H,s)
        check(A==8*K[2][2]-s[2]**2,name+': 2-Schur mismatch')
        check(B==16*K[3][3]-2*s[3]**2,name+': 3-Schur mismatch')
        check(C==8*K[4][4]-s[4]**2,name+': 4-Schur mismatch')
        check(D==8*K[2][4]-s[2]*s[4],name+': 2x4-Schur mismatch')
        stable,_=is_psd(K)
        cut3,_=is_psd([[K[i][j] for j in [0,2,3]] for i in [0,2,3]])
        cut4,_=is_psd(actual)
        if name=='central heptagon':
            check(stable and cut3 and cut4, 'candidate expected stable')
            check(H[2][2]==7 and H[3][3]==7 and H[4][4]==7, 'candidate radial moments')
            check(A==28 and B==105 and C==42 and var==0, 'candidate exact Schur data')
        if name=='regular octagon':
            check(not stable and cut3 and not cut4,'octagon must pass 3-mode but fail 4-mode')
            check(K[4][4]==-Q(735,512),'octagon fourth-mode negative fraction')
            check(var==0,'octagon equal radial squares')
        print(name+': K3 PSD='+str(cut3)+', K4 PSD='+str(cut4)+', full K PSD='+str(stable))
        print('  A,B,C,D,variance =', A,B,C,D,var)
        print('  weighted radius mu=R6/R4:',H[3][3]/H[2][2])
    low=Q(9,10)-Q(4,441)
    upper=Q(585,448)
    check(low==Q(3929,4410),'lower fraction')
    check(upper==(Q(312)-Q(1183)/Q(49,6))/Q(128),'upper fraction')
    print('For a fully stable stationary global maximizer in the inherited ellipse:')
    print('  3929/4410 < R6/R4 <= 585/448.')
    print('All exact verification tests passed. No full-branch exclusion is proved.')

if __name__=='__main__':
    run()
