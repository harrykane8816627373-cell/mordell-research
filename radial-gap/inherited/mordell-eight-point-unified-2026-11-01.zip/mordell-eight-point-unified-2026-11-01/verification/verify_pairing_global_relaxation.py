"""Exact audit of root-pairing trace criterion and a feasible projected pseudo-moment point.

Requires SymPy only for symbolic quotient-ring arithmetic and discriminants.
All accept/reject decisions are exact (Integer/Rational), not floating point.
Run: python -B -O verify_pairing_global_relaxation.py
This DOES NOT certify unsatisfiability of the eight-point stationary system.
"""
from fractions import Fraction as F
from functools import reduce
from operator import mul
import sympy as S
from verify_joint_angular_radial_matrix import build, principal_minors

X = S.Symbol('X')
Z = F(0)
ONE = F(1)

def require(v, name):
    if not v:
        raise ArithmeticError('FAILED: ' + name)

def newton_poly(powers):
    """p_1,...,p_8 -> coefficients c_1,...,c_8 (centered)."""
    c = [S.Integer(1)]
    for k in range(1,9):
        c.append(S.factor(-sum(c[k-j]*powers[j] for j in range(1,k+1))/k))
    return S.Poly(sum(c[k]*X**(8-k) for k in range(9)), X, domain=S.QQ)

def traces_of_force_conjugate(P):
    """Compute traces of (P''/(8P') mod P)^k for k=1..8 exactly."""
    expr = P.as_expr()
    inv = S.invert(S.diff(expr,X), expr, X)
    C = S.Poly(S.rem(S.diff(expr,X,2)*inv/8,expr,X),X,domain=S.QQ)
    co = P.all_coeffs()
    s = [S.Integer(8)]
    for k in range(1,9):
        if k < 8:
            s.append(S.expand(-sum(co[j]*s[k-j] for j in range(1,k))-k*co[k]))
        else:
            s.append(S.expand(-sum(co[j]*s[k-j] for j in range(1,8))-8*co[8]))
    power = S.Poly(1,X,domain=S.QQ)
    traces=[]
    for k in range(1,9):
        power = (power*C).rem(P)
        traces.append(S.factor(sum(power.nth(j)*s[j] for j in range(8))))
    return C,traces,s

def true_examples():
    candidates={
        'origin_plus_heptagon':S.Poly(X**8-X,X,domain=S.QQ),
        'regular_octagon':S.Poly(X**8-S.Rational(7,8)**4,X,domain=S.QQ),
        'real_Hermite':S.Poly(X**8-S.Rational(7,2)*X**6+S.Rational(105,32)*X**4-S.Rational(105,128)*X**2+S.Rational(105,4096),X,domain=S.QQ),
    }
    for name,P in candidates.items():
        C,traces,powers=traces_of_force_conjugate(P)
        require(all(traces[k-1]==powers[k] for k in range(1,9)), name+' pairing traces')
        print(name,'trace identities k=1..8 EXACT PASS; C degree',C.degree())
    real_points=[S.Rational(v,6)*sign for v in (4,5,6,7) for sign in (-1,1)]
    P=S.Poly(S.prod(X-r for r in real_points),X,domain=S.QQ)
    require(sum(r*r for r in real_points)==7 and sum(real_points)==0,'real example centered normalized')
    C,traces,powers=traces_of_force_conjugate(P)
    require(traces[1]>powers[2],'nonstationary real example strictly fails trace k2')
    print('normalized nonstationary REAL roots: trace(C^2)-s2=',traces[1]-powers[2],'>0 EXACT')

def projected_ghost():
    # These are synthetic combined *moments*, not moments of P's actual roots.
    # Their inconsistency is certified by the trace pairing test below.
    t=[Z]+[ONE]*5+[F(3,4),F(5,4)]
    R=lambda k:sum((v**k for v in t),Z)
    x,y=R(2),R(3)
    E=y-2*x+7
    p={1:S.Integer(0),2:S.Rational(1,10),3:S.Rational(1,10),
       4:S.Integer(0),5:S.Integer(0),6:S.Integer(0),
       7:S.Rational(15,2),8:S.Rational(1,4)}
    s={k:F(p[k].p,p[k].q) for k in p}
    require(E>F(1,40000),'positive radial defect beyond gap')
    require(max(t)<=F(25,16),'all radial support')
    # Even the elementary triangle inequality for s7 can be respected:
    # 5+(3/4)^(7/2)+(5/4)^(7/2) > 5+(27*1.73+125*2.23)/128 > 15/2.
    require(F(173,100)**2 < 3 and F(223,100)**2 < 5, 'rational radical lower bounds')
    require(F(5)+F(27,128)*F(173,100)+F(125,128)*F(223,100) >= F(15,2),
            'trivial seventh moment radial triangle bound')
    require(s[2]*s[2]+F(54,175)*s[3]*s[3]<ONE,'old ellipse')
    require(s[2]>=F(1,10**36)*s[3],'old small wedge')
    require(max(abs(s[k]) for k in [2,3,4,5,6,8])>F(1,8),'outside energy moment tube')
    for k in range(2,9):
        require(s[k]*s[k] <= 8*R(k), f'elementary power Cauchy-Schwarz moment k={k}')
    require(max(abs(s[k]) for k in range(2,7))>F(1,570),'outside five-moment gap')
    # CS bounds before majorizing the higher radial moments. Six exact inequalities.
    for k in (2,3,4,5,6,8):
        Q=F(15-k,8)*s[k]+sum((s[j]*s[k-j] for j in range(1,k)),Z)/8
        require((Q-s[k])**2<=E*R(k-1),f'Ward-CS k={k}')
    A,f,g,h,M=build(x,y,s[2],s[4])
    B=312*x-128*y-1183-2*s[3]**2
    require(A>0 and B>0 and f>0,'scalar stability')
    require(all(v>0 for v in principal_minors(M)),'joint stability 3x3 PSD')
    require((x*x-F(169,64)*s[2]**2)**2>=(x*s[4]-F(169,64)*s[2]**2)**2,'Toeplitz projection')
    # Full radial Hankel PSD and [0,25/16] localizers hold automatically because t is a list of real supported atoms.
    # Schur--Ward bound with Q_1..Q_6 substituted from synthetic Ward data.
    Q={k:F(15-k,8)*s[k]+sum((s[j]*s[k-j] for j in range(1,k)),Z)/8 for k in range(1,7)}
    Ds={k:R(k)-s[k]*s[k]/8-Q[k-1]*Q[k-1]/7 for k in range(2,8)}
    require(all(v>0 for v in Ds.values()),'positive Schur diagonal Dk')
    Pstar=56*Ds[4]*Ds[5]*Ds[6]*Ds[7]
    N=Pstar*Ds[2]*Ds[3]-F(7**7)
    Cstar=Pstar*F(9,400)*s[2]**2*s[3]**2
    Ystar=Pstar*A*B/F(3200)
    require(N>=0 and Ystar>=0 and (Cstar<=N+Ystar or (Cstar-N-Ystar)**2<=4*N*Ystar),'Schur-Ward two-disc cut')
    P=newton_poly(p)
    disc=S.discriminant(P.as_expr(),X)
    require(abs(disc)>=7**7,'EXACT pure-polynomial discriminant threshold')
    U_bound=F(56)*reduce(mul,Ds.values(),ONE)
    require(F(abs(disc))<=U_bound,'Schur--Ward bound for actual polynomial discriminant')
    N_actual=Pstar*Ds[2]*Ds[3]-F(abs(disc))
    require(N_actual>=0 and (Cstar<=N_actual+Ystar or
        (Cstar-N_actual-Ystar)**2<=4*N_actual*Ystar),
        'two-disc necessary condition with ACTUAL polynomial discriminant')
    C,tt,ss=traces_of_force_conjugate(P)
    require(tt[1]!=ss[2],'ghost MUST fail root-pairing trace at k=2')
    require(ss[2]==p[2], 'Newton consistency of pure power sums')
    print('GHOST radial atoms:',t)
    print('x=',x,'y=',y,'E=',E,'|s8|=',s[8])
    print('three-mode+joint stability PSD: ALL SEVEN PRINCIPAL MINORS STRICTLY POSITIVE')
    print('all six Ward-CS, radial support/Hankel, old ellipse, gap, Schur--Ward threshold: EXACT PASS')
    print('P=',P.as_expr())
    print('exact |Disc(P)|/7^7 =',abs(disc)/7**7)
    print('Schur--Ward upper bound /7^7 =', U_bound/F(7**7))
    print('exact discriminant <= Schur--Ward bound and two-disc upper constraint: PASS')
    print('root-pairing FAILURE trace(C^2)-s2 =',tt[1]-ss[2])
    print('Hence projected constraints are NONEMPTY, not a physical stationary solution.')

if __name__=='__main__':
    true_examples()
    projected_ghost()
    print('EXACT TESTS PASSED. FULL n=8 UNSAT CERTIFICATE: NOT OBTAINED.')
