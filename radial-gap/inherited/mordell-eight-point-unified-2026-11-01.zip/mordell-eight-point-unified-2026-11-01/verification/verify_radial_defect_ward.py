"""Exact rational checks for a candidate-sharp radial Ward projection.

No approximate floating-point inequality decides acceptance.  Finite examples
are sanity checks; the universal result uses the elementary polynomial identity,
Cauchy--Schwarz, and Ward's stationary equations written in the companion note.
This is NOT a proof that the full eight-point problem is solved.
"""
from fractions import Fraction as F
from unified_stability_matrix import certificate, rem

ZERO, ONE = F(0), F(1)
U = F(25, 16)
E_LIMIT = F(1, 40000)
TARGET = F(1, 8)


def check(cond, msg):
    if not cond:
        raise ValueError(msg)


def pol_add(a, b):
    c = [ZERO] * max(len(a), len(b))
    for j, x in enumerate(a): c[j] += x
    for j, x in enumerate(b): c[j] += x
    return c


def pol_mul(a,b):
    c = [ZERO] * (len(a) + len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): c[i+j] += x*y
    return c


def H(m, t):
    return sum((F(m-2-j)*t**j for j in range(m-2)), ZERO)


def polynomial_identity_checks():
    for m in range(3, 8):
        lhs = [ZERO]*(m+1)
        lhs[m] += ONE
        lhs[2] -= (m-1)
        lhs[1] += (m-2)
        h = [F(m-2-j) for j in range(m-2)]
        rhs = pol_mul([ZERO, ONE, -2*ONE, ONE], h)
        check(lhs == rhs, f'polynomial Hermite majorant at m={m}')
        check(H(m,U) <= H(7,U), 'H_m <= H_7')
    print('Algebraic identities for m=3,...,7: EXACT PASS')


def radius_and_moment_bounds():
    check(U == F(25,16), 'radial square cap')
    check(F(1,8) < F(3,8)**2, 'global radius: 1/sqrt(8)<3/8')
    # Use sqrt(7)<8/3 and sqrt(E)<=1/200 to show |R4-7|<=1/75.
    check(F(7) < F(8,3)**2, 'sqrt 7 cap')
    h7 = H(7,U)
    max_radial = F(7) + F(6,75) + h7*E_LIMIT
    check(max_radial < F(64,9), 'radial moments k=1..7 bounded by (8/3)^2')
    print('H7(25/16)=',h7)
    print('uniform radial moment upper bound=',max_radial,' < 64/9')

    # From Cauchy--Schwarz and |Q_k-s_k| <= (8/3) sqrt(E) <= 1/75.
    c = F(1,75)
    b2 = F(8,5)*c
    b3 = 2*c
    b4 = (8*c + b2*b2)/3
    b5 = 4*c + b2*b3
    b6 = 8*c + 2*b2*b4 + b3*b3
    b8 = 8*c + 2*b2*b6 + 2*b3*b5 + b4*b4
    bounds = {2:b2,3:b3,4:b4,5:b5,6:b6,8:b8}
    for k,v in bounds.items():
        check(v<TARGET,f'failure of six-moment tube for k={k}')
        print(f'|s{k}| <=',v,'~',f'{float(v):.10f}', '<1/8:',v<TARGET)
    print('E<=1/40000 implies full six-moment tube: EXACT PASS')
    return bounds


def s_of_order(p, s, k):
    # Exact Newton recurrence for k>=8; first eight power sums s0..s7.
    a = list(s)
    n = len(p)-1
    while len(a) <= k:
        j = len(a)
        a.append(-sum((p[t]*a[j-n+t] for t in range(n)), ZERO))
    return a[k]


def test_stationary_models():
    examples = [
        ('center+regular heptagon', [ZERO,-ONE]+[ZERO]*6+[ONE]),
        ('regular octagon',[-F(7,8)**4]+[ZERO]*7+[ONE]),
        ('real Hermite', [F(105,4096),ZERO,-F(105,128),ZERO,F(105,32),ZERO,-F(7,2),ZERO,ONE]),
    ]
    for name,p in examples:
        _,G,_,ss = certificate(p)
        s = {k:s_of_order(p,ss,k) for k in range(9)}
        moments = {m:G[m][m] for m in range(1,8)}
        x,y = moments[2],moments[3]
        e = y-2*x+7
        check(e>=0,name+': radial defect nonnegative')
        for k in [2,3,4,5,6,8]:
            # Q_k=<q,q^{k+1}>, reduce X^{k+1} modulo P if degree>=8.
            basis = rem([ZERO]*(k+1)+[ONE],p)
            qk=sum((basis[j]*G[1][j] for j in range(len(basis))),ZERO)
            conv=sum((s[j]*s[k-j] for j in range(1,k)), ZERO)
            ward=(F(15-k,8)*s[k]+conv/8)
            check(qk==ward,name+f': Ward k={k}')
            residual=qk-s[k]
            check(residual*residual <= e*moments[k-1],name+f': CS k={k}')
        if name=='center+regular heptagon':
            check(e==0 and s[8]==0, 'sharpness at candidate')
        print(name, ': E=',e, ', Ward+CS for k=2,3,4,5,6,8 EXACT PASS')


def main():
    polynomial_identity_checks()
    radius_and_moment_bounds()
    test_stationary_models()
    print('VERIFIED: New radial Ward necessary conditions and E<=1/40000 tube implication.')
    print('NOT VERIFIED/NOT CLAIMED: Global eight-point exclusion.')

if __name__=='__main__':
    main()
