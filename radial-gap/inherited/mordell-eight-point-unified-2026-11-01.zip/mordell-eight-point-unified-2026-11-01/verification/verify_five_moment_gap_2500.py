"""Reproducible exact rational certificate for the eight-point 1/2500 gap.

Assumptions: the real stationary force equations, sum |q_i|^2=7,
max |q_i|<=5/4, product discriminant>=7^7 and inherited certified
moment tube |s_k|<=1/8 (k=2,3,4,5,6,8).

Uses rational grid intervals for t=|q_i|^2. This script certifies
inequalities and not the inherited analytic six-moment tube theorem.
Run: python -B -S -O verify_five_moment_gap_2500.py
"""
from fractions import Fraction as Q
from math import isqrt


def require(test, why):
    if not test:
        raise RuntimeError(why)


def rational_sqrt_strict_upper(x, denom=10**6):
    require(x >= 0, "sqrt input nonnegative")
    integer = (x.numerator * denom**2) // x.denominator
    z = Q(isqrt(integer) + 1, denom)
    require(z*z > x, "strict upper square check")
    return z


def grid_coefficient_bound(count=20):
    """Certify min(|c7|,|c8|) < 33*epsilon, for radius <=5/4."""
    qradius_squared = Q(25,16)
    y = Q(13,20)
    worst = (Q(0), -1, None, None)
    checked = 0
    for j in range(1 + (25*count)//16):
        lo = Q(j, count)
        hi = min(Q(j+1,count), qradius_squared)
        if lo >= hi:
            continue
        R = rational_sqrt_strict_upper(hi)
        M = sum((Q(k,8)*max(abs(Q(k-15)+8*lo),
                                 abs(Q(k-15)+8*hi))*R**(8-k)
                 for k in range(2,7)), Q(0))
        # 'A' uses the imaginary part; is invalid only if interval includes t=1.
        if not (lo <= 1 <= hi):
            dist = min(abs(lo-1),abs(hi-1))
            A = M/(7*y*dist)
        else:
            A = None
        # 'B' uses the real part and the imaginary-part estimate for c7.
        # It is invalid only if the interval includes t=7/8.
        if not (lo <= Q(7,8) <= hi):
            dist = min(abs(8*lo-7),abs(8*hi-7))
            B = M*(1+R/y)/dist
        else:
            B = None
        require(A is not None or B is not None, f"uncovered interval {j}")
        c = min(x for x in (A,B) if x is not None)
        require(c < 33, f"dichotomy coefficient not certified: interval {j}")
        checked += 1
        if c>worst[0]:
            worst=(c,j,lo,hi)
    require(checked == 32, "unexpected number of intervals")
    return worst,checked


def main():
    eps=Q(1,2500)
    C=Q(33)
    A=Q(7,6)
    B=Q(81,10)
    T=Q(7**7)
    bmax=Q(7,8)**4
    # Strengthened radial cap: for a global maximum in the repository,
    # |q_i| <= 7/8+1/sqrt(8) <5/4.
    require(Q(3,8)**2 > Q(1,8), 'inherited radius 7/8+1/sqrt8 < 5/4')
    require(2*7**21 < 8**20, 'regular octagon objective < T/2')
    # Small-moment Newton recursion bound for k=2,...,6.
    for k in range(2,7):
        require((eps + max(0,k-3)*eps**2)/k <= eps, "Newton recursion")
    require((Q(7)-Q(1,8))/16 > Q(13,20)**2, 'imaginary-root lower bound')
    worst,checked=grid_coefficient_bound()
    # If |c8|<=33*eps, automatic sixth moment enters inherited tube.
    eighth=8*C*eps+5*eps**2
    require(eighth < Q(1,8), 'tube threshold for s8')
    # If |c7|<=33*eps: compare discriminant of P with X^8+c8.
    # All first variation terms vanish by discriminant weighted homogeneity.
    require(all((56-k)%8 !=0 for k in range(2,8)),
            'no linear discriminant terms')
    # Upper row norms of Sylvester resultant Res(P,P').
    # |c8| <= (7/8)^4 via AM-GM and fixed total mass.
    pnorm2 = 1+bmax**2+5*eps**2+(C*eps)**2
    dpnorm2 = 64+(6**2+5**2+4**2+3**2+2**2)*eps**2+(C*eps)**2
    require(pnorm2<A**2,'P-row bound')
    require(dpnorm2<B**2,'Pprime-row bound')
    L2=(21*(C+5)**2*A**5*B**8
        +28*(C+20)**2*A**7*B**6
        +56*(C+5)*(C+20)*A**6*B**7)
    require(L2*eps**2 < T/2,'discriminant quadratic Taylor remainder')
    # Check the formal stationary on-root identity term-by-term.
    for k in range(9):
        require((8-k)*(7-k)-56 == k*(k-15),f'formal constant k={k}')
        require(-8*(8-k)+64==8*k,f'formal t coefficient k={k}')
    # Deliberately reject the next larger round radius on these majorants.
    unsafe=Q(1,2000)
    require(not (L2*unsafe**2 < T/2),
            'unsafe radius 1/2000 should fail quadratic discriminant check')
    print('PASSED: exact rational 1/2500 five-moment global-max gap.')
    print('Number of t-intervals:',checked)
    print('Largest branch coefficient majorant:',str(worst[0]),'~',float(worst[0]))
    print('Worst interval:',str(worst[2]),str(worst[3]))
    print('Certified uniform coefficient C:',C)
    print('Small-c8 s8 ceiling:',eighth, '~',float(eighth))
    print('Sylvester second-order discriminant budget:',L2*eps**2,
          '~',float(L2*eps**2))
    print('Half candidate threshold:',T/2,'~',float(T/2))
    print('Result needs the inherited global-max radius bound and moment-tube theorem.')
    print('No complete n=8 global sharp upper bound established.')


if __name__=='__main__':
    main()
