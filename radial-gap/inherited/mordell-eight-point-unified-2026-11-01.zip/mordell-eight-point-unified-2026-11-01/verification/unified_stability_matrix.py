"""Exact rational audit of the eight-point unified stability matrix.

Two rational-coefficient examples: P=X^8-X (stable candidate), and
P=X^8-(7/8)^4 (unstable regular octagon). No third-party dependencies.
General complex-coefficient theorem is in UNIFIED_MATRIX.md.
"""
from fractions import Fraction as F
from itertools import combinations

N = 8
Z = F(0)
ONE = F(1)

def require(condition, message):
    if not condition:
        raise AssertionError(message)


def trim(a):
    a = list(a)
    while len(a) > 1 and a[-1] == 0:
        a.pop()
    return a


def add(a, b):
    z = [Z] * max(len(a), len(b))
    for i, v in enumerate(a):
        z[i] += v
    for i, v in enumerate(b):
        z[i] += v
    return trim(z)


def neg(a):
    return [-v for v in a]


def sub(a, b):
    return add(a, neg(b))


def mul(a, b):
    z = [Z] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            z[i + j] += x*y
    return trim(z)


def scale(a, c):
    return trim([c*v for v in a])


def divmodpoly(a, b):
    a, b = trim(a), trim(b)
    if b == [Z]:
        raise ZeroDivisionError
    q = [Z] * max(1, len(a)-len(b)+1)
    while len(a) >= len(b) and a != [Z]:
        k = len(a)-len(b)
        c = a[-1]/b[-1]
        q[k] += c
        a = sub(a, [Z]*k + scale(b, c))
    return trim(q), a


def rem(a, p):
    return divmodpoly(a, p)[1]


def derivative(a):
    return trim([F(i)*a[i] for i in range(1, len(a))] or [Z])


def inverse_mod(a, p):
    r0, r1 = p, rem(a,p)
    t0, t1 = [Z], [ONE]
    while r1 != [Z]:
        q, r2 = divmodpoly(r0, r1)
        r0, r1 = r1, r2
        t0, t1 = t1, sub(t0, mul(q,t1))
    if len(r0) != 1:
        raise ValueError('P has multiple roots')
    v = rem(scale(t0, ONE/r0[0]), p)
    if rem(mul(a, v), p) != [ONE]:
        raise AssertionError('bad inverse')
    return v


def powmod(a, k, p):
    out = [ONE]
    while k:
        if k & 1:
            out = rem(mul(out,a), p)
        a = rem(mul(a,a),p)
        k //= 2
    return out


def power_sums(p):
    n = len(p)-1
    require(p[-1] == ONE, 'exact verification failed')
    s = [F(n)]
    for k in range(1,n):
        v = -k*p[n-k]
        for j in range(1,k):
            v -= p[n-j]*s[k-j]
        s.append(v)
    return s


def det(A):
    a = [list(row) for row in A]
    n = len(a)
    sign, value = ONE, ONE
    for j in range(n):
        h = next((k for k in range(j,n) if a[k][j]),None)
        if h is None:
            return Z
        if h != j:
            a[j],a[h]=a[h],a[j]
            sign = -sign
        pivot=a[j][j]
        value*=pivot
        for i in range(j+1,n):
            factor=a[i][j]/pivot
            for k in range(j+1,n):
                a[i][k]-=factor*a[j][k]
            a[i][j]=Z
    return sign*value


def transpose(A):
    return [list(row) for row in zip(*A)]


def matmul(A,B):
    Bt=transpose(B)
    return [[sum((u*v for u,v in zip(row,col)),Z) for col in Bt] for row in A]


def certificate(p):
    require(len(p)==N+1 and p[-1]==ONE and p[7]==0, 'exact verification failed')
    pp=derivative(p)
    C=rem(scale(mul(derivative(pp), inverse_mod(pp,p)),F(1,8)),p)
    s=power_sums(p)
    def trace(poly):
        return sum((v*s[k] for k,v in enumerate(rem(poly,p))),Z)
    Cpowers=[powmod(C,k,p) for k in range(N)]
    H=[[trace(mul(Cpowers[a],[Z]*b+[ONE])) for b in range(N)] for a in range(N)]
    require(H==transpose(H), 'exact verification failed')
    require(rem(substitute(p,C,p),p)==[Z], 'exact verification failed')
    require(trace(mul([Z,ONE],C))==7, 'exact verification failed')
    Fcols=[[Z],C]
    for k in range(2,N):
        poly=scale(mul([Z]*(k-1)+[ONE],C),F(k))
        for r in range(k-1):
            term=[Z]*(k-2-r)+[ONE]
            poly=sub(poly,scale(term,F(k-1-r,4)*s[r]))
        poly=add(poly,[Z]*(k-2)+[F(k*(k-1),8)])
        Fcols.append(rem(poly,p))
    T=[[Fcols[j][i] if i<len(Fcols[j]) else Z for j in range(N)] for i in range(N)]
    ht=matmul(H,T)
    ttht=matmul(transpose(T),ht)
    K=[[H[i][j]-ttht[i][j] for j in range(N)] for i in range(N)]
    require(K==transpose(K), 'exact verification failed')
    require(all(det([row[:k] for row in H[:k]])>0 for k in range(1,N+1)), 'exact verification failed')
    return C,H,K,s


def substitute(poly, xpoly, modulus):
    acc=[Z]
    for a in reversed(poly):
        acc=rem(add(mul(acc,xpoly),[a]),modulus)
    return acc


def is_psd(A):
    for k in range(1,len(A)+1):
        for ix in combinations(range(len(A)),k):
            m=[[A[i][j] for j in ix] for i in ix]
            if det(m)<0:
                return False,(ix,det(m))
    return True,None


def audit():
    cand=[Z,-ONE]+[Z]*6+[ONE]
    C,H,K,s=certificate(cand)
    ok, bad=is_psd(K)
    require(C==[Z]*6+[ONE], 'exact verification failed')
    require(ok and bad is None, 'exact verification failed')
    require(det(H)==7**7, 'exact verification failed')
    require(all(s[k]==0 for k in range(2,7)), 'exact verification failed')
    require(s[7]==7, 'exact verification failed')
    print('candidate: conjugacy & positive H verified; det(H)=7^7; K PSD by all 255 principal minors')

    b=F(7,8)**4
    octagon=[-b]+[Z]*7+[ONE]
    C,H,K,s=certificate(octagon)
    require(C==[Z]*7+[F(512,343)], 'exact verification failed')
    require(K[4][4]==-F(735,512), 'exact verification failed')
    require(det(H)==8**8*b**7, 'exact verification failed')
    require(det(H)<7**7, 'exact verification failed')
    ok,bad=is_psd(K)
    require(not ok, 'exact verification failed')
    print('octagon: conjugacy & positive H verified; K[4,4]=-735/512; det(H)/7^7=7^21/8^20<1')
    bad_cases = [
        [Z]*7 + [ONE, ONE],             # non-centered P
        [Z]*8 + [ONE],                  # multiple zero root
        [Z, -2*ONE] + [Z]*6 + [ONE],    # wrong candidate scale
    ]
    for bad_p in bad_cases:
        try:
            certificate(bad_p)
        except (AssertionError, ValueError, ZeroDivisionError):
            continue
        raise AssertionError('unsafe input unexpectedly accepted')
    print('Three invalid inputs rejected even with Python -O.')
    print('All exact checks passed; full six-branch exclusion NOT proved.')


if __name__=='__main__':
    audit()
