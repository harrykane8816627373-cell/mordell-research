"""Exact checks for seven-point decimation bounds in the eight-point Mordell problem.

Only Python's standard library is used. This code checks algebraic and rational
constants; the use of the previously established M_7 sharp bound is an explicit
mathematical input, not proved by this script.
"""
from fractions import Fraction as F


def check(condition, message):
    if not condition:
        raise ArithmeticError(message)
    print('PASS:', message)


T = 7 ** 7
N = 2 ** 15 * 3 ** 75
c = F(27, 250)

# Conditional on M_7 = 7^21 / 6^15, the decimation bound is
# Delta_8 <= d*(56-d)^27 / N.

def decimation_upper(d):
    return d * (F(56) - d) ** 27 / N


# At d = 27/250 the upper bound is strictly below the target.
check(decimation_upper(c) < T,
      'at d=27/250 the decimation upper bound is below 7^7')
check(c < 2, 'monotonic interval 0 <= d <= 27/250 lies below d=2')
check(F(6 ** 15, 7 ** 14) > F(2, 3),
      'all root-derivative modulus squares exceed 2/3')
check(F(6 ** 15, 7 ** 14) > F(1, 65),
      'new derivative bound strengthens the old 1/65')
check(F(7**7 * 27**27, 56**27) < c,
      'new separation cutoff strictly exceeds old AM-GM-only bound')

# Exact optimization t* = 7(7+d)/72 for any 0 <= d <= 56.
for d in [F(0), F(1, 10), F(27, 250), F(1), F(2), F(13), F(56)]:
    tstar = 7 * (7 + d) / 72
    a = 7 + 8 * tstar - d
    b = 7 - F(8, 7) * tstar
    check(F(0) <= tstar <= F(49, 8), f'optimal radial parameter in range for d={d}')
    check(a == 2*b and b == (56-d)/9, f'exact A=2B at optimum for d={d}')
    check(F(2**6, 6**21 * 9**27) == F(1, N),
          f'decimation coefficient matches 1/(2^15*3^75) for d={d}')

# At the displayed cutoff the ratio is strictly below 1, hence any
# configuration with Delta_8 >= T must have every d > 27/250.
ratio = decimation_upper(c) / T
print('EXACT rejection ratio at d=27/250:', ratio)
print('Decimal ratio (display only):', float(ratio))
print('Derived per-edge inequality: Delta_8 <= d(56-d)^27/(2^15*3^75)')
print('Derived derivative lower bound: |P\'(q_i)|^2 >= 6^15/7^14 > 2/3')
print('VERIFIED algebra/constants; no 8-point global sharp bound proved.')
