"""Exact rational audit of two new stationary angular-radial polynomial cuts.

This is not an exhaustive eight-point optimizer, and does not establish the
unconditional sharp upper bound. Run with:
    python -B -S -O verify_angular_radial_projection.py
All acceptance conditions use explicit checks, not Python assert statements.
"""
from fractions import Fraction as F
from unified_stability_matrix import certificate, is_psd


def need(condition, message):
    if not condition:
        raise ArithmeticError(message)


def cuts(x, y, a, b):
    """Real-valued test data: x=R4, y=R6, a=s2, b=s4.

    The markdown proof supplies the general complex-modulus formulas.
    """
    A=F(196)-24*x-a*a
    B=312*x-128*y-1183
    f=-120*y*y+288*x*y-162*x*x+x*(4*a*a-b*b)
    g=(145*x-91*y)*a-x*a*b
    old_margin=x*f*(15*A+392*x)-15*g*g
    refined_margin=old_margin-F(8281,8)*f*a*a
    angular_margin=8*f*(x*x-b*b)-15*((11*x-8*y)*b+x*a*a)**2
    toeplitz_margin=(x*x-F(169,64)*a*a)**2-(x*b-F(169,64)*a*a)**2
    return A,B,f,old_margin,refined_margin,angular_margin,toeplitz_margin


def check_stationary(label, p):
    C,H,K,s=certificate(p)
    x,y,r8=H[2][2],H[3][3],H[4][4]
    a,b=s[2],s[4]
    need(H[1][3]==F(13,8)*a,label+': k=2 Ward relation')
    need(H[1][5]==F(11,8)*b+a*a/F(8),label+': k=4 Ward relation')
    V=x*r8-y*y
    need(V>=0,label+': radial variance')
    E2=H[1][5]-(y/x)*b
    need(E2*E2*x*x<=V*(x*x-b*b),label+': angular covariance CS')
    A,B,f,om,rm,am,tm=cuts(x,y,a,b)
    need(tm>=0,label+': unit-circle Toeplitz inequality')
    stable,_=is_psd(K)
    if stable:
        need(A>=0 and f>=0 and om>=0 and rm>=0 and am>=0,label+': stable configuration violated cut')
    print(label,'full_stability=',stable,'x=',x,'y=',y,'s2=',a,'s4=',b)
    print('  projected refined margin:',rm,'angular-radial margin:',am)


def independent_witness():
    # Formal rational moment data, not alleged to come from any eight points.
    x=F(31,5); y=x*F(73,80); a=F(3,10); b=F(-2)
    A,B,f,om,rm,am,tm=cuts(x,y,a,b)
    need(x>=F(49,8) and y>=x*x/7,'basic radial constraints')
    need(a*a<1,'ellipse')
    need(A>0 and B>0 and f>0,'weaker diagonal constraints')
    need(om>0 and rm>0 and tm>0,'older and refined necessary cuts should pass')
    need(am<0,'new angular-radial cut must fail')
    print('formal rational pseudo-moments:', 'x=',x,'y=',y,'s2=',a,'s4=',b)
    print('  old projected margin:',om,'refined projected margin:',rm)
    print('  angular Toeplitz margin:',tm)
    print('  NEW angular-radial margin:',am, '(strictly negative)')


def main():
    z=F(0);o=F(1)
    check_stationary('central heptagon',[z,-o]+[z]*6+[o])
    check_stationary('regular octagon',[-F(7,8)**4]+[z]*7+[o])
    check_stationary('real Hermite stationary',[F(105,4096),z,-F(105,128),z,F(105,32),z,-F(7,2),z,o])
    independent_witness()
    print('PASSED: exact arithmetic checks. No global impossibility certificate obtained.')

if __name__=='__main__':
    main()
