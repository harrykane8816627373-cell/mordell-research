"""Exact audit: centered Vandermonde Schur/Hadamard and Ward constraints.

Runs without sympy/numpy, or assert. This verifies three exact physical
stationary examples (not completeness), one nonstationary rational point set,
and polynomial disk-elimination arithmetic. General theorem in accompanying MD.
"""
from fractions import Fraction as Q
from functools import reduce
from operator import mul
from unified_stability_matrix import certificate, det

Z = Q(0)
ONE = Q(1)
T = Q(7**7)


def need(cond, message):
    if not cond:
        raise ArithmeticError(message)


def norm(z):
    return z[0]*z[0] + z[1]*z[1]


def add(z,w):
    return z[0]+w[0], z[1]+w[1]


def mult(z,w):
    return z[0]*w[0]-z[1]*w[1], z[0]*w[1]+z[1]*w[0]


def power(z,k):
    v=(ONE,Z)
    for _ in range(k):
        v=mult(v,z)
    return v


def sumz(values):
    return reduce(add, values, (Z,Z))


def moment_diag(H,s):
    # Gram matrix for basis 1,q,..,q^7, for normalized centered set.
    need(H[0][0]==8 and H[1][1]==7 and H[0][1]==0,'normalization')
    Ds=[]
    for k in range(2,8):
        q=H[1][k]
        D=H[k][k]-s[k]*s[k]/8-q*q/7
        need(D>=0,'Schur diagonal nonnegative')
        Ds.append(D)
    U=56*reduce(mul,Ds,ONE)
    D2,D3=Ds[:2]
    m=H[2][3]-s[2]*s[3]/8
    # For all our exact stationary models, s_j and H entries are real.
    U23=56*(D2*D3-m*m)*reduce(mul,Ds[2:],ONE)
    return Ds,U,U23


def stationary_examples():
    examples=[
      ('central_heptagon',[Z,-ONE]+[Z]*6+[ONE]),
      ('regular_octagon',[-Q(7,8)**4]+[Z]*7+[ONE]),
      ('real_Hermite',[Q(105,4096),Z,-Q(105,128),Z,Q(105,32),Z,-Q(7,2),Z,ONE]),
    ]
    for label,p in examples:
        C,H,K,s=certificate(p)
        # Exact Ward recurrence, verified independently from this matrix.
        for j in range(1,7):
            conv=sum((s[l]*s[j-l] for l in range(1,j)),Z)
            rhs=((15-j)*s[j]+conv)/8
            need(H[1][j+1]==rhs,f'{label}: Ward Q{j}')
        Ds,U,U23=moment_diag(H,s)
        actual=det(H)
        need(actual<=U23<=U,f'{label}: majorant chain')
        if label in ('central_heptagon','regular_octagon'):
            need(U23==U==actual,f'{label}: equality')
        if label=='central_heptagon':
            need(actual==T,'candidate target')
        print(label,'actual/T=',float(actual/T),'U/T=',float(U/T),'U23/T=',float(U23/T))
        print('  D2..D7=', [str(x) for x in Ds])


def rational_complex_sample():
    p=[(ONE,Z),(Z,ONE),(Q(3,5),Q(4,5)),(Q(1,2),Q(1,2))]
    p=p+[(-u,-v) for u,v in p]
    # Rational Householder reflection of three points, preserving their
    # total sum and squared norms, breaks the +/- symmetry.
    v=(Q(1),Q(2),Q(-3))
    dot=sumz((v[j]*p[j][0],v[j]*p[j][1]) for j in range(3))
    for j in range(3):
        p[j]=(p[j][0]-v[j]*dot[0]/7, p[j][1]-v[j]*dot[1]/7)
    need(len(set(p))==8,'eight pairwise distinct rational points')
    need(sumz(p)==(Z,Z) and sum(norm(z) for z in p)==7,'rational set normalization')
    ss={k:sumz(power(z,k) for z in p) for k in range(8)}
    q={k:sumz((norm(z)*power(z,k)[0],norm(z)*power(z,k)[1]) for z in p) for k in range(7)}
    radial={k:sum((norm(z)**k for z in p),Z) for k in range(8)}
    D=[]
    for k in range(2,8):
        D.append(radial[k]-norm(ss[k])/8-norm(q[k-1])/7)
    need(all(d>=0 for d in D),'sample Schur diagonals')
    U=56*reduce(mul,D,ONE)
    # Full two-column off-diagonal S23 from the original Hermitian Gram.
    m=sumz(mult((power(z,2)[0],-power(z,2)[1]),power(z,3)) for z in p)
    c=mult((ss[2][0],-ss[2][1]),ss[3]); c=(c[0]/8,c[1]/8)
    t=(m[0]-c[0],m[1]-c[1])
    U23=56*(D[0]*D[1]-norm(t))*reduce(mul,D[2:],ONE)
    product=ONE
    for i,z in enumerate(p):
        for w in p[:i]:
            product*=norm((z[0]-w[0],z[1]-w[1]))
    need(Z<product<=U23<U,'rational complex sample inequalities and strict 2-column improvement')
    print('nonstationary rational complex 8-point set: actual/T=',float(product/T),
          'U23/T=',float(U23/T),'U/T=',float(U/T))


def disk_poly(V,Y,C):
    # Exact equivalent of sqrt(C) <= sqrt(V)+sqrt(Y).
    need(V>=0 and Y>=0 and C>=0,'nonnegative inputs')
    return C<=V+Y or (C-V-Y)**2<=4*V*Y


def check_disk():
    need(disk_poly(Q(1,100),Q(1,400),Q(9,400)),'tangent disks must intersect')
    need(not disk_poly(Q(1,400),Q(1,400),Q(9,400)),'disjoint disks must fail')
    need(disk_poly(Q(1,10),Q(1,400),Q(9,400)),'large feasible disk')
    need(not disk_poly(Z,Z,Q(1,100)),'disjoint zero radius disks')
    print('disk-elimination rational tests PASSED')

if __name__=='__main__':
    stationary_examples()
    rational_complex_sample()
    check_disk()
    print('ALL EXACT CHECKS PASSED. No full 8-point exclusion established.')
