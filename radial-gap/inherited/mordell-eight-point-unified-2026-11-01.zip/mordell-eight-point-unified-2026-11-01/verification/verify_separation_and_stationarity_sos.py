"""Exact eight-point discriminant superlevel and stationary SOS verification.

Independent of external repository helpers. Python + SymPy only.
All acceptance decisions use exact integer / rational arithmetic.
Run: python -B -O verify_separation_and_stationarity_sos.py
Does not certify global impossibility of competing stationary configurations.
"""
from fractions import Fraction
import sympy as sp

X = sp.Symbol('X')

def check(value, description):
    if not bool(value):
        raise ArithmeticError('FAILED: ' + description)
    print('PASS:', description)


def verify_global_rational_constants():
    pair_lb = Fraction(7**7 * 27**27, 56**27)
    prime_lb = Fraction(3**21, 7**14)
    old_pair_lb = Fraction(7**7 * 4**27, 25**27)
    check(pair_lb > Fraction(1, 436), 'squared-pair-distance > 1/436')
    check(prime_lb > Fraction(1, 65), 'squared-polynomial-derivative > 1/65')
    check(pair_lb > old_pair_lb * (10**12), 'strict improvement over old radius bound')
    print('exact squared-distance bound:', pair_lb)
    print('exact squared-derivative bound:', prime_lb)
    print('improvement over radius-based pair bound:', float(pair_lb / old_pair_lb))


def verify_stationary_polynomial_congruences():
    # The algebraic conjugate of each actual root is represented modulo P
    # by J(X) for the specified symmetric test configurations.
    P7 = sp.Poly(X**8 - X, X, domain='QQ')
    J7 = X**6  # qbar = q^6 for q=0 or a seventh root of unity.
    check(sp.rem(P7.diff().diff().as_expr() - 8*J7*P7.diff().as_expr(),
                 P7.as_expr(), X) == 0,
          'central plus regular heptagon: stationary SOS zero')

    P8 = sp.Poly(X**8 - sp.Rational(7, 8)**4, X, domain='QQ')
    J8 = (sp.Rational(8, 7)**3)*X**7  # qbar = (|q|^2)^(-3)q^7
    check(sp.rem(P8.diff().diff().as_expr() - 8*J8*P8.diff().as_expr(),
                 P8.as_expr(), X) == 0,
          'regular octagon: stationary SOS zero')

    PH = sp.Poly(X**8-sp.Rational(7, 2)*X**6+
                 sp.Rational(105, 32)*X**4-
                 sp.Rational(105, 128)*X**2+sp.Rational(105, 4096),
                 X,domain='QQ')
    check(sp.expand(PH.diff().diff().as_expr()-8*X*PH.diff().as_expr()+
                    64*PH.as_expr()) == 0,
          'real Hermite stationary polynomial differential equation')


def verify_direct_complex_bridge():
    # Eight distinct, centered rational Gaussian roots with mass 7.
    q = [sp.Rational(4, 6), -sp.Rational(4, 6),
         sp.I*sp.Rational(5, 6), -sp.I*sp.Rational(5, 6),
         sp.Rational(6, 6), -sp.Rational(6, 6),
         sp.I*sp.Rational(7, 6), -sp.I*sp.Rational(7, 6)]
    check(sp.simplify(sum(q)) == 0, 'complex test points centered')
    check(sp.simplify(sum(z*sp.conjugate(z) for z in q)) == 7,
          'complex test points mass 7')
    check(len(set(q)) == 8, 'complex test points distinct')
    pair_squares = []
    Dlist = []
    residual_norm = sp.Integer(0)
    for i, qi in enumerate(q):
        diffs = [qi-qj for j, qj in enumerate(q) if j != i]
        distances_sq = [sp.expand(d*sp.conjugate(d)) for d in diffs]
        Pprime = sp.prod(diffs)
        Pdouble = 2*sum((sp.prod(diffs[:j]+diffs[j+1:]) for j in range(7)),sp.Integer(0))
        D = sp.expand(Pdouble-8*sp.conjugate(qi)*Pprime)
        Ai = sp.prod(distances_sq)
        Z = sum((sp.conjugate(diffs[j])*sp.prod(distances_sq[:j]+distances_sq[j+1:])
                 for j in range(7)),sp.Integer(0))-4*sp.conjugate(qi)*Ai
        check(sp.simplify(2*Z-sp.conjugate(Pprime)*D)==0,
              f'direct degree-16 SOS vs degree-30 denominator clearing, root {i}')
        force_residual = sum((1/d for d in diffs),sp.Integer(0))-4*sp.conjugate(qi)
        check(sp.simplify(D-2*Pprime*force_residual)==0,
              f'force-gradient identity, root {i}')
        residual_norm += sp.expand(D*sp.conjugate(D))
        Dlist.append(D)
        pair_squares.extend(distances_sq)
    check(sp.simplify(residual_norm) > 0,'nonstationary rational complex witness SOS strictly positive')
    check(sum(pair_squares)==112, 'ordered edge squared distances =112 (56 unordered)')
    delta = sp.prod((q[i]-q[j])*sp.conjugate(q[i]-q[j])
                    for i in range(8) for j in range(i+1,8))
    check(sp.simplify(delta)>0, 'nonstationary witness discriminant positive')
    # Exact identity between the full 16x16 real stability Hessian and
    # its edge-by-edge complex second variation, on arbitrary noncolliding points.
    H = sp.eye(16)*4
    for i in range(8):
        for j in range(i+1,8):
            lam = sp.expand(1/(q[i]-q[j])**2)
            alpha, beta = sp.expand(sp.re(lam)), sp.expand(sp.im(lam))
            block = ((alpha, -beta), (-beta, -alpha))
            for sgn_i, idx_i in ((1,i),(-1,j)):
                for sgn_j, idx_j in ((1,i),(-1,j)):
                    for a in range(2):
                        for b in range(2):
                            H[2*idx_i+a,2*idx_j+b] += sgn_i*sgn_j*block[a][b]
    hh = [sp.Rational(i-5, 9) + sp.I*sp.Rational(2*i-7, 11) for i in range(8)]
    hh_real = sp.Matrix([v for z in hh for v in (sp.re(z),sp.im(z))])
    lhs = sp.expand((hh_real.T * H * hh_real)[0])
    rhs = 4*sum((sp.expand(z*sp.conjugate(z)) for z in hh),sp.Integer(0)) + \
        sp.re(sum((((hh[i]-hh[j])/(q[i]-q[j]))**2
                   for i in range(8) for j in range(i+1,8)),sp.Integer(0)))
    check(sp.simplify(lhs-rhs)==0,
          'full 16x16 real Hessian agrees with complex edge quadratic form')
    check(H == H.T, 'full real stability Hessian exactly symmetric')
    print('nonstationary test SOS exact value:', residual_norm)
    print('nonstationary test Δ / 7^7 ≈', float(sp.simplify(sp.expand(delta)) / 7**7))
    print('physical-force ≤ (65/4) polynomial-SOS identity: follows from derivative bound only on Δ≥7^7')


if __name__ == '__main__':
    verify_global_rational_constants()
    verify_stationary_polynomial_congruences()
    verify_direct_complex_bridge()
    print('ALL EXACT CHECKS PASSED. NO GLOBAL N=8 UNSAT CERTIFICATE OBTAINED.')
