"""Unified exact reproducibility entry. No unsatisfiability / global sharp proof claimed."""
import argparse
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
CORE=[
 'verify_new_combination.py',
 'verify_radial_defect_ward.py',
 'verify_seven_point_decimation.py',
 'verify_discriminant_schur_ward.py',
 'verify_joint_angular_radial_matrix.py',
]
LEGACY=[
 'verify_joint_stability_cut.py',
 'verify_angular_radial_projection.py',
 'verify_projected_fourth_mode_cut.py',
 'verify_fourth_mode_cut.py',
 'verify_five_moment_gap_570.py',
 'verify_global_five_moment_gap_2000.py',
 'verify_five_moment_gap_2500.py',
 'verify_effective_five_moment_gap.py',
 'verify_phase_quartic.py',
]
SYMPY=[
 'verify_pairing_global_relaxation.py',
 'verify_separation_and_stationarity_sos.py',
]

def main():
    a=argparse.ArgumentParser()
    a.add_argument('--with-sympy', action='store_true',help='also run two optional SymPy tests')
    a.add_argument('--legacy', action='store_true',help='also run prior finite exact checks')
    args=a.parse_args()
    tasks=CORE + (LEGACY if args.legacy else []) + (SYMPY if args.with_sympy else [])
    failures=[]
    lines=[]
    for filename in tasks:
        command=[sys.executable,'-B','-O',str(ROOT/filename)]
        try:
            result=subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=50)
            state='PASS' if result.returncode==0 else 'FAIL'
            stdout, stderr=result.stdout,result.stderr
        except subprocess.TimeoutExpired:
            state='FAIL'
            stdout,stderr='', 'TIMEOUT after 50 s'
        
        print(f'{state:<4}  {filename}', flush=True)
        lines.append(f'[{state}] {filename}\n{stdout}\n{stderr}\n')
        if state!='PASS':
            failures.append(filename)
    (ROOT/'current_verification_log.txt').write_text('\n'.join(lines),encoding='utf-8')
    print(f'\nExact scripted checks: {len(tasks)-len(failures)}/{len(tasks)} passed')
    print('NO global eight-point CAD/SOS/interval unsatisfiability certificate was produced.')
    if failures:
        print('Failed:',', '.join(failures))
        raise SystemExit(1)

if __name__=='__main__': main()
