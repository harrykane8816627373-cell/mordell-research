"""Exact rational audit of an 8-point joint stationary/stability moment cut.

Only the Python standard library is required. The standalone arithmetic witness
is a centered/normalized *nonstationary* point set: it demonstrates that the
joint cut is stricter than its diagonal consequences on actual point sets,
NOT that it excludes a stationary maximizing configuration.

The optional checks of full K and the radius localizer use the companion file
unified_stability_matrix.py from the previous research stage.
"""
from fractions import Fraction as Q


def need(condition, why):
    if not condition:
        raise ArithmeticError(why)


def pair_add(a,b):
    return (a[0]+b[0], a[1]+b[1])


def pair_mul(a,b):
    return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])


def pair_conj(a):
    return (a[0],-a[1])


def pair_sqabs(a):
    return a[0]*a[0]+a[1]*a[1]


def pair_pow(a,n):
    out=(Q(1),Q(0))
    for _ in range(n):
        out=pair_mul(out,a)
    return out


def pair_sum(xs):
    out=(Q(0),Q(0))
    for x in xs:
        out=pair_add(out,x)
    return out


def moment_cut_for_raw_coordinates(raw):
    """Normalize by q_i=sqrt(7/S)*(raw_i-mean(raw)), without square roots.

    Returns exact rational normalizations of the needed invariants.
    """
    need(len(raw)==8,'eight points required')
    mean=tuple(x/Q(8) for x in pair_sum(raw))
    x=[(a-mean[0],b-mean[1]) for a,b in raw]
    S=sum((pair_sqabs(v) for v in x),Q(0))
    need(S>0,'nonzero normalization required')
    L=Q(7)/S # square of the positive normalization
    s2=pair_sum(pair_pow(z,2) for z in x)
    s3=pair_sum(pair_pow(z,3) for z in x)
    rad4=sum((pair_sqabs(z)**2 for z in x),Q(0))*L**2
    rad6=sum((pair_sqabs(z)**3 for z in x),Q(0))*L**3
    ss2=pair_sqabs(s2)*L**2
    ss3=pair_sqabs(s3)*L**3
    mx=pair_sum((pair_sqabs((a,b))**2*a,pair_sqabs((a,b))**2*b) for a,b in x)
    coupled=pair_add((Q(40)*mx[0],Q(40)*mx[1]),pair_mul(pair_conj(s2),s3))
    cross2=pair_sqabs(coupled)*L**5
    A=Q(196)-Q(24)*rad4-ss2
    B=Q(312)*rad4-Q(128)*rad6-Q(1183)-Q(2)*ss3
    ellipse=ss2+Q(54,175)*ss3
    return {'R4':rad4,'R6':rad6,'s2_abs2':ss2,'s3_abs2':ss3,
            'ellipse':ellipse,'A':A,'B':B,'left':A*B,'right':Q(2)*cross2}


def witness():
    pts=[(34,-41),(951,25),(605,709),(-200,1013),(-1030,334),
         (-969,-581),(-129,-931),(738,-528)]
    pts=[(Q(a,1000),Q(b,1000)) for a,b in pts]
    r=moment_cut_for_raw_coordinates(pts)
    need(r['ellipse']<1,'rational witness must satisfy ellipse')
    need(r['A']>0 and r['B']>0,'both diagonal cuts must pass')
    need(r['right']>r['left'],'joint cut should exclude this tuple')
    print('Rational 8-point nonstationary witness: ellipse and A,B >= 0 pass; joint determinant FAILS')
    for k in ('ellipse','R4','R6','A','B','left','right'):
        print('  ',k,'=',format(float(r[k]),'.12g'))
    print('  exact comparison: RIGHT > LEFT:',r['right']>r['left'])


def polynomial_examples():
    from unified_stability_matrix import certificate, is_psd, matmul, transpose, rem, Z, ONE
    n=8
    cases={
        'central-heptagon':[Z,-ONE]+[Z]*6+[ONE],
        'regular-octagon':[-Q(7,8)**4]+[Z]*7+[ONE],
        'real-Hermite-stationary':[Q(105,4096),Z,-Q(105,128),Z,Q(105,32),Z,-Q(7,2),Z,ONE]
    }
    for name,p in cases.items():
        C,H,K,s=certificate(p)
        rad4=H[2][2]
        rad6=H[3][3]
        M=H[2][3]
        need(K[0][2]==s[2] and K[0][3]==s[3],name+': incorrect constant cross terms')
        need(K[2][2]==Q(49,2)-3*rad4,name+': incorrect K22')
        need(K[3][3]==Q(39,2)*rad4-8*rad6-Q(1183,16),name+': incorrect K33')
        need(K[2][3]==-5*M,name+': incorrect K23')
        # Multiplication-by-X companion in basis 1,X,...,X^7.
        cols=[]
        for j in range(n):
            cj=rem([Z]*(j+1)+[ONE],p)
            cols.append(cj+[Z]*(n-len(cj)))
        T=[list(row) for row in zip(*cols)]
        radiusGram=matmul(transpose(T),matmul(H,T))
        L=[[Q(25,16)*H[i][j]-radiusGram[i][j] for j in range(n)] for i in range(n)]
        isRadiusOK,_=is_psd(L)
        isStable,_=is_psd(K)
        if name=='central-heptagon':
            need(isRadiusOK and isStable,'candidate audit must pass')
        if name=='regular-octagon':
            need(isRadiusOK and not isStable,'octagon is unstable')
        if name=='real-Hermite-stationary':
            need(not isRadiusOK and not isStable,'Hermite violates radius and stability')
        print(name,': full K PSD =',isStable,'; localizer radius <= 5/4 PSD =',isRadiusOK)
    print('All exact matrix equality and radius-localizer tests passed.')


if __name__=='__main__':
    witness()
    polynomial_examples()
    print('No complete eight-point exclusion is claimed.')
