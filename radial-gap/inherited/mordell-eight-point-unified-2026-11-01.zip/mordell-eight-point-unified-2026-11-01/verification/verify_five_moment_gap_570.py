"""Exact rational certificate for an eight-point Mordell five-moment gap.

Scope: true stationary points q with sum(q)=0, sum |q|^2 = 7,
max |q_i| <= 5/4, and Delta(q) >= 7^7; relies on the
previously proved global energy basin d_w <= 1/5.

Checks all new rational constants, the second discriminant jet by
an independent 15x15 Sylvester-matrix computation, and the root disks.
Run: python -B -S -O verify_five_moment_gap_570.py
"""
from fractions import Fraction as Q
from math import isqrt, comb


def require(cond, reason):
    if not cond:
        raise RuntimeError(reason)


def sqrt_upper(x, scale=10**6):
    require(x >= 0, "nonnegative square root")
    j = isqrt((x.numerator*scale*scale)//x.denominator)
    ans = Q(j+1, scale)
    require(ans*ans>x, "strict rational sqrt enclosure")
    return ans


def coefficient_branch_certificate():
    """Cover every possible t=|q_i|^2 with exact rational intervals."""
    y = Q(661,1000)
    cap = Q(25,16)
    n = 1000
    eps = Q(1,570)
    C = Q(251,10)
    require((7-eps)/16>y*y,"some rotated imaginary coordinate exceeds y")
    maximum = (Q(0),None,None)
    count=0
    for j in range(1563):
        lo=Q(j,n)
        hi=min(Q(j+1,n),cap)
        require(lo<hi,"nonempty t interval")
        R=sqrt_upper(hi)
        X=sqrt_upper(max(Q(0),hi-y*y))
        M=sum((Q(k,8)*max(abs(Q(k-15)+8*lo),
                                  abs(Q(k-15)+8*hi))*R**(8-k)
               for k in range(2,7)),Q(0))
        A=None if lo<=1<=hi else M/(7*y*min(abs(lo-1),abs(hi-1)))
        B=None if lo<=Q(7,8)<=hi else M*(1+X/y)/min(abs(8*lo-7),abs(8*hi-7))
        require(A is not None or B is not None,"uncovered t")
        val=min(x for x in (A,B) if x is not None)
        require(val<C,f"uniform coefficient bound fails on box {j}: {val}")
        if val>maximum[0]:maximum=(val,lo,hi)
        count+=1
    require(count==1563,"entire radius interval covered")
    return maximum,count


def matrices():
    """Sylvester matrix for degree-8 P and degree-7 P' in descending powers."""
    def S(poly, dpoly):
        rows=[]
        for shift in range(6,-1,-1):
            rows.append([Q(poly.get(14-col-shift,0)) for col in range(15)])
        for shift in range(7,-1,-1):
            rows.append([Q(dpoly.get(14-col-shift,0)) for col in range(15)])
        return rows
    base=S({8:1,0:1},{7:8})
    perturb={k:S({8-k:1},{7-k:8-k}) for k in range(2,8)}
    return base,perturb


def det_and_inverse(A):
    n=len(A)
    B=[list(row)+[Q(i==j) for j in range(n)] for i,row in enumerate(A)]
    d=Q(1)
    for k in range(n):
        pivot=next((i for i in range(k,n) if B[i][k]), None)
        require(pivot is not None,"singular Sylvester base")
        if pivot != k:
            B[k],B[pivot]=B[pivot],B[k]
            d=-d
        f=B[k][k]
        d*=f
        B[k]=[v/f for v in B[k]]
        for i in range(n):
            if i==k:continue
            factor=B[i][k]
            if factor:
                B[i]=[u-factor*v for u,v in zip(B[i],B[k])]
    return d,[row[n:] for row in B]


def matmul(A,B):
    return [[sum(a*b for a,b in zip(row,col)) for col in zip(*B)]
            for row in A]


def discriminant_jet_certificate():
    A0,perturb=matrices()
    disc0,inv=det_and_inverse(A0)
    require(disc0==8**8, "discriminant of X^8+1")
    X={k:matmul(inv,perturb[k]) for k in perturb}
    for k in X:
        require(sum(X[k][i][i] for i in range(15))==0,
                f"first discriminant derivative k={k} must vanish")
    coeff={}
    for k in range(2,8):
        for l in range(k,8):
            tr=sum(X[k][i][j]*X[l][j][i]
                   for i in range(15) for j in range(15))
            value= -disc0*tr/(2 if k==l else 1)
            if value:coeff[(k,l)]=value
    require(coeff=={(2,6): -25165824,(3,5): -31457280,
                    (4,4): -16777216},
            f"unanticipated degree-two discriminant monomials: {coeff}")
    return coeff


def root_and_discriminant_certificates():
    eps=Q(1,570);C=Q(251,10); T=Q(7**7)
    cap=Q(5,4);bmax=Q(7,8)**4
    require(Q(187,200)**2<Q(7,8),"max root R exceeds 187/200")
    require(Q(7,8)+sqrt_upper(Q(1,8))<cap,"inherited global-max radius < 5/4")
    require(2*7**21<8**20,"octagon has discriminant < T/2")
    for k in range(2,7):
        require((eps+max(0,k-3)*eps*eps)/k <= eps,
                "Newton coefficient induction")
    # Branch |b| <= C epsilon: isolate roots of Y^8-Y by Rouche.
    root_min=Q(187,200)
    a_lower=root_min**7*(1-eps*sum(root_min**(-k) for k in range(2,7))
                          -C*eps*root_min**(-8))
    t_lower=Q(23,25)
    require(a_lower>t_lower**7,"scale t=|a|^(1/7)>23/25")
    D={k:eps/t_lower**k for k in range(2,7)}
    D[8]=C*eps/t_lower**8
    r0=Q(1,10);r1=Q(1,25)
    inner_err=sum(D[k]*r0**(8-k) for k in D)
    inner_base=r0*(1-r0**7)
    outer_err=sum(D[k]*(1+r1)**(8-k) for k in D)
    external_factor=7-sum(comb(7,j)*r1**(j-1) for j in range(2,8))
    outer_base=r1*(1-r1)*external_factor
    require(inner_err<inner_base,"inner Rouche disk")
    require(outer_err<outer_base,"7 outer Rouche disks")
    hc=inner_err/(1-r0**7)
    ho=outer_err/((1-r1)*external_factor)
    S2=hc*hc+7*ho*ho
    require(S2<Q(1,105),"sum of squared root displacement upper bound")
    # ||q-tv||^2 = t ||q-v||^2 + 7(t-1)^2, ||q||^2=||v||^2=7.
    # S<1/10 and sqrt 7>5/2 imply t<25/24<21/20.
    require(Q(1,105)<Q(1,100) and Q(5,2)**2<7,
            "scale upper bound assumptions")
    require(Q(25,24)<Q(21,20),"t <21/20")
    require(Q(21,20)/105==Q(1,100),"q orbit squared distance <1/100 by two strict inequalities")
    # Branch |a|<=C epsilon: sparse quadratic jet plus cubic bound.
    A=Q(29,25);B=Q(801,100)
    pnormsq=1+bmax**2+5*eps**2+(C*eps)**2
    dpnormsq=64+(6**2+5**2+4**2+3**2+2**2)*eps**2+(C*eps)**2
    require(pnormsq < A*A,"P row norm")
    require(dpnormsq < B*B,"P' row norm")
    u=C+5;v=C+20
    L3=6*(comb(7,3)*u**3*A**4*B**8
          +comb(8,3)*v**3*A**7*B**5
          +comb(7,2)*8*u**2*v*A**5*B**7
          +7*comb(8,2)*u*v**2*A**6*B**6)
    quadratic=(25165824+31457280+16777216)*bmax**6*eps**2
    cubic=L3*eps**3/6
    require(quadratic+cubic<T/2,"disc near X^8+b below 7^7")
    require(8**8*bmax**7<T/2,"octagon base discriminant")
    # A neighboring, larger epsilon fails at least one prescribed inequality;
    # its failure is NOT a counterexample to the underlying theorem.
    unsafe=Q(1,400)
    Du={k:unsafe/t_lower**k for k in range(2,7)}
    Du[8]=C*unsafe/t_lower**8
    unsafe_center=sum(Du[k]*r0**(8-k) for k in Du)
    require(not(unsafe_center<inner_base),"must reject unsafe larger center-disk input")
    return dict(a_scale_lower=float(a_lower),root_inner_error=float(inner_err),
                root_inner_base=float(inner_base),root_outer_error=float(outer_err),
                root_outer_base=float(outer_base),root_l2_sq=float(S2),
                disc_quadratic_budget=float(quadratic),disc_cubic_budget=float(cubic),
                disc_half_margin=float(T/2),P_row_norm_sq=float(pnormsq))


def main():
    maximum,boxes=coefficient_branch_certificate()
    coeff=discriminant_jet_certificate()
    stats=root_and_discriminant_certificates()
    print("PASS exact-rational five-moment global-exclusion gap epsilon=1/570")
    print("radius boxes",boxes,"coefficient majorant",str(maximum[0]),float(maximum[0]))
    print("worst interval",str(maximum[1]),str(maximum[2]),"certified C=251/10")
    print("discriminant quadratic jet",coeff)
    for k,v in stats.items():print(k,v)
    print("Reliance: inherited full orbit-distance energy basin and global-max radius theorem")
    print("No claim of complete n=8 sharp bound or full six-branch exhaustion")

if __name__=='__main__':main()
